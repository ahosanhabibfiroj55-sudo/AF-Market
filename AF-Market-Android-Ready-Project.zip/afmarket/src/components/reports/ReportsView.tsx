/**
 * AF Market - Accounting, Reports & Profit/Loss Calculation
 * Strictly enforces accounting principles:
 * Gross Profit = Net Sales - COGS
 * Net Profit = Gross Profit - Operating Expenses
 * Unsold inventory remains an asset and is not deducted from sales.
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  TrendingUp,
  Download,
  Printer,
  Calendar,
  DollarSign,
  PieChart,
  BarChart,
  FileSpreadsheet,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { sales, purchases, expenses, products, customers, suppliers, formatBDT, lang, t } = useApp();

  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');

  // Filter dates
  const filteredSales = useMemo(() => {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    return sales.filter(s => {
      const sDate = s.createdAt.split('T')[0];
      if (dateFilter === 'today') return sDate === todayStr;
      if (dateFilter === 'week') {
        const diffDays = (now.getTime() - new Date(s.createdAt).getTime()) / (1000 * 3600 * 24);
        return diffDays <= 7;
      }
      if (dateFilter === 'month') {
        const diffDays = (now.getTime() - new Date(s.createdAt).getTime()) / (1000 * 3600 * 24);
        return diffDays <= 30;
      }
      return true;
    });
  }, [sales, dateFilter]);

  const filteredExpenses = useMemo(() => {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    return expenses.filter(e => {
      if (dateFilter === 'today') return e.date === todayStr;
      if (dateFilter === 'week') {
        const diffDays = (now.getTime() - new Date(e.date).getTime()) / (1000 * 3600 * 24);
        return diffDays <= 7;
      }
      if (dateFilter === 'month') {
        const diffDays = (now.getTime() - new Date(e.date).getTime()) / (1000 * 3600 * 24);
        return diffDays <= 30;
      }
      return true;
    });
  }, [expenses, dateFilter]);

  // Calculations
  const netSales = filteredSales.reduce((acc, s) => acc + s.finalAmount, 0);
  const costOfGoodsSold = filteredSales.reduce((acc, s) => acc + s.costOfGoodsSold, 0);
  const grossProfit = netSales - costOfGoodsSold;
  const grossProfitMargin = netSales > 0 ? (grossProfit / netSales) * 100 : 0;

  const totalOperatingExpenses = filteredExpenses.reduce((acc, e) => acc + e.amount, 0);
  const netProfit = grossProfit - totalOperatingExpenses;
  const netProfitMargin = netSales > 0 ? (netProfit / netSales) * 100 : 0;

  const totalCustomerDues = customers.reduce((acc, c) => acc + c.remainingDue, 0);
  const totalSupplierPayables = suppliers.reduce((acc, s) => acc + s.remainingPayable, 0);
  const totalInventoryAsset = products.reduce((acc, p) => acc + Math.max(0, p.currentStock) * p.purchasePrice, 0);

  // Product-wise profit ranking
  const productProfitRanking = useMemo(() => {
    const map: Record<string, { name: string; nameBn: string; qtySold: number; revenue: number; profit: number }> = {};

    filteredSales.forEach(sale => {
      sale.items.forEach(item => {
        if (!map[item.productId]) {
          map[item.productId] = {
            name: item.productName,
            nameBn: item.productNameBn,
            qtySold: 0,
            revenue: 0,
            profit: 0,
          };
        }
        const itemRevenue = item.subtotal;
        const itemCost = item.quantity * item.purchaseUnitCost;
        map[item.productId].qtySold += item.quantity;
        map[item.productId].revenue += itemRevenue;
        map[item.productId].profit += itemRevenue - itemCost;
      });
    });

    return Object.values(map).sort((a, b) => b.profit - a.profit);
  }, [filteredSales]);

  // Export to CSV
  const handleExportCSV = () => {
    let csv = `AF Market Business Report (${dateFilter.toUpperCase()})\n`;
    csv += `Date,${new Date().toLocaleDateString()}\n\n`;
    csv += `Financial Statement,Amount (BDT)\n`;
    csv += `Net Sales Revenue,${netSales}\n`;
    csv += `Cost of Goods Sold (COGS),${costOfGoodsSold}\n`;
    csv += `Gross Profit,${grossProfit}\n`;
    csv += `Operating Expenses,${totalOperatingExpenses}\n`;
    csv += `Net Profit,${netProfit}\n`;
    csv += `Total Outstanding Customer Due,${totalCustomerDues}\n`;
    csv += `Total Supplier Payable,${totalSupplierPayables}\n`;
    csv += `Inventory Asset Value,${totalInventoryAsset}\n\n`;

    csv += `Product Name,Quantity Sold,Revenue,Profit\n`;
    productProfitRanking.forEach(p => {
      csv += `"${p.nameBn}",${p.qtySold},${p.revenue},${p.profit}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `AF_Market_Report_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header & Export Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-[#0B2B50]" />
            {t.navReports}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'bn'
              ? 'আন্তর্জাতিক অ্যাকাউন্টিং নীতিমালা অনুসারে প্রকৃত লাভ-ক্ষতি ও আর্থিক বিবরণী'
              : 'Accurate profit & loss statements complying with standard retail accounting'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Date Segmented Control */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
            {[
              { id: 'all', label: lang === 'bn' ? 'সব' : 'All' },
              { id: 'today', label: lang === 'bn' ? 'আজ' : 'Today' },
              { id: 'week', label: lang === 'bn' ? '৭ দিন' : '7 Days' },
              { id: 'month', label: lang === 'bn' ? '৩০ দিন' : '30 Days' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setDateFilter(tab.id as any)}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  dateFilter === tab.id ? 'bg-[#0B2B50] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Excel/CSV</span>
          </button>

          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">প্রিন্ট</span>
          </button>
        </div>
      </div>

      {/* Accounting Formula Notice */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-xs text-blue-900 flex items-start gap-2.5">
        <HelpCircle className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">সঠিক আর্থিক হিসাবের নিয়মাবলী:</span>
          <p className="text-[11px] text-blue-800 mt-0.5">
            মোট পাইকারি কেনাকাটা সরাসরি বিক্রয় থেকে বিয়োগ করা হয় না। অবিক্রীত মাল দোকানের সম্পদ (Asset) হিসেবে সংরক্ষিত থাকে। শুধুমাত্র বিক্রিত মালের ক্রয়মূল্য (COGS) বিক্রয় থেকে বাদ দিয়ে প্রকৃত লাভ বের করা হয়।
          </p>
        </div>
      </div>

      {/* Primary Profit & Loss Statement Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 space-y-4">
        <h3 className="font-bold text-sm text-slate-900 pb-2 border-b border-slate-100 flex items-center justify-between">
          <span>আর্থিক লাভ-ক্ষতি বিবরণী (Profit & Loss Statement)</span>
          <span className="text-xs font-semibold px-2 py-0.5 rounded bg-blue-100 text-[#0B2B50]">
            {filteredSales.length} {lang === 'bn' ? 'টি মেমো বিশ্লেষণ' : 'sales analyzed'}
          </span>
        </h3>

        <div className="space-y-3 text-xs">
          {/* 1. Net Sales */}
          <div className="flex justify-between items-center p-3 rounded-xl bg-slate-50 border border-slate-100">
            <div>
              <span className="font-bold text-slate-900 text-sm block">১. নিট বিক্রয় আয় (Net Sales)</span>
              <span className="text-[11px] text-slate-500">গ্রাহকদের কাছে পণ্য বিক্রয়ের সর্বমোট বিল</span>
            </div>
            <span className="text-base font-bold text-slate-900 tabular-nums font-mono">
              {formatBDT(netSales)}
            </span>
          </div>

          {/* 2. COGS */}
          <div className="flex justify-between items-center p-3 rounded-xl bg-rose-50/50 border border-rose-100">
            <div>
              <span className="font-bold text-rose-900 text-sm block">২. বিক্রিত পণ্যের ক্রয়মূল্য (COGS)</span>
              <span className="text-[11px] text-rose-700">যে পণ্যগুলো বিক্রি হয়েছে সেগুলোর প্রকৃত পাইকারি খরচ</span>
            </div>
            <span className="text-base font-bold text-rose-700 tabular-nums font-mono">
              -{formatBDT(costOfGoodsSold)}
            </span>
          </div>

          {/* 3. Gross Profit */}
          <div className="flex justify-between items-center p-3 rounded-xl bg-emerald-50 border border-emerald-200">
            <div>
              <span className="font-bold text-emerald-900 text-sm block">
                ৩. মোট লাভ (Gross Profit = বিক্রয় - COGS)
              </span>
              <span className="text-[11px] text-emerald-700">
                মার্জিন: <span className="font-bold">{grossProfitMargin.toFixed(1)}%</span>
              </span>
            </div>
            <span className="text-lg font-bold text-emerald-800 tabular-nums font-mono">
              {formatBDT(grossProfit)}
            </span>
          </div>

          {/* 4. Operating Expenses */}
          <div className="flex justify-between items-center p-3 rounded-xl bg-rose-50/50 border border-rose-100">
            <div>
              <span className="font-bold text-rose-900 text-sm block">৪. দোকানের পরিচালন খরচ (Operating Expenses)</span>
              <span className="text-[11px] text-rose-700">দোকান ভাড়া, বিদ্যুৎ, কর্মচারীদের নাস্তা, বিল ইত্যাদি</span>
            </div>
            <span className="text-base font-bold text-rose-700 tabular-nums font-mono">
              -{formatBDT(totalOperatingExpenses)}
            </span>
          </div>

          {/* 5. Net Profit */}
          <div className="flex justify-between items-center p-4 rounded-xl bg-[#0B2B50] text-white">
            <div>
              <span className="font-bold text-base block text-amber-300">
                ৫. প্রকৃত নিট লাভ (Net Accounting Profit)
              </span>
              <span className="text-[11px] text-blue-200">
                সব খরচ বাদ দিয়ে মালিকের আসল লাভ (মার্জিন: {netProfitMargin.toFixed(1)}%)
              </span>
            </div>
            <span className="text-2xl font-bold tabular-nums font-mono text-amber-400">
              {formatBDT(netProfit)}
            </span>
          </div>
        </div>
      </div>

      {/* Asset & Liability Snapshot Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-medium">বর্তমান অবিক্রীত পণ্যের মূল্য (Asset)</span>
          <p className="text-base font-bold text-blue-900 tabular-nums font-mono mt-0.5">
            {formatBDT(totalInventoryAsset)}
          </p>
          <span className="text-[10px] text-slate-400">{products.length} আইটেমের বর্তমান স্টক মান</span>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-medium">কাস্টমারদের কাছে মোট বাকি (Receivable)</span>
          <p className="text-base font-bold text-rose-600 tabular-nums font-mono mt-0.5">
            {formatBDT(totalCustomerDues)}
          </p>
          <span className="text-[10px] text-slate-400">দোকানের পাওনা টাকা</span>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-medium">মহাজনদের বকেয়া দেনা (Payable)</span>
          <p className="text-base font-bold text-orange-600 tabular-nums font-mono mt-0.5">
            {formatBDT(totalSupplierPayables)}
          </p>
          <span className="text-[10px] text-slate-400">কোম্পানিদের প্রদেয় টাকা</span>
        </div>
      </div>

      {/* Product-wise Profit Ranking Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-4">
        <h4 className="font-bold text-sm text-slate-900 mb-3 flex items-center gap-2">
          <BarChart className="w-4 h-4 text-slate-500" />
          পণ্যভিত্তিক লাভ ও বিক্রয় বিশ্লেষণ (Top Profitable Items)
        </h4>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
              <tr>
                <th className="py-2.5 px-3">পণ্যের নাম</th>
                <th className="py-2.5 px-3 text-center">বিক্রিত পরিমাণ</th>
                <th className="py-2.5 px-3 text-right">মোট বিক্রয় আয়</th>
                <th className="py-2.5 px-3 text-right">অর্জিত লাভ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {productProfitRanking.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-50 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-slate-800">
                    {lang === 'bn' ? item.nameBn : item.name}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono">{item.qtySold}</td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-slate-700">
                    {formatBDT(item.revenue)}
                  </td>
                  <td className="py-2.5 px-3 text-right tabular-nums font-bold text-emerald-700">
                    {formatBDT(item.profit)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {productProfitRanking.length === 0 && (
          <div className="py-8 text-center text-slate-400 text-xs">কোনো পণ্যের বিক্রয় তথ্য নেই</div>
        )}
      </div>
    </div>
  );
};
