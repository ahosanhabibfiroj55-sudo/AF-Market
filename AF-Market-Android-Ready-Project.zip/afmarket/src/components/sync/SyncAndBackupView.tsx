/**
 * AF Market - Synchronization, Cloud Backup & Restore
 * Manages Supabase sync, offline queue, local JSON backups, and audit trails.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AFMarketStorage } from '../../db/storage';
import {
  RefreshCw,
  Database,
  Cloud,
  Download,
  Upload,
  CheckCircle2,
  Clock,
  ShieldCheck,
  HardDrive,
  FileText,
  AlertTriangle,
} from 'lucide-react';

export const SyncAndBackupView: React.FC = () => {
  const { syncMeta, syncNow, isOnline, auditLogs, lang, t, showToast, refreshAllData } = useApp();

  const [supabaseUrl, setSupabaseUrl] = useState('https://afmarket-demo.supabase.co');
  const [supabaseKey, setSupabaseKey] = useState('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.demo-anon-key');

  const handleDownloadBackup = () => {
    const json = AFMarketStorage.exportFullBackupJSON();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `AF_Market_Backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    showToast('সম্পূর্ণ ডাটাবেস ব্যাকআপ ফাইল ডাউনলোড সম্পন্ন হয়েছে', 'success');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      const content = event.target?.result as string;
      if (content) {
        const success = AFMarketStorage.restoreFromJSON(content);
        if (success) {
          refreshAllData();
          showToast('ব্যাকআপ সফলভাবে রিস্টোর করা হয়েছে!', 'success');
        } else {
          showToast('ব্যাকআপ ফাইলটি সঠিক নয়!', 'error');
        }
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <RefreshCw className="w-5 h-5 text-[#0B2B50]" />
            {t.navSync} ও ক্লাউড ব্যাকআপ
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'bn'
              ? 'অফলাইন-প্রথম লোকাল স্টোরেজ ও Supabase ক্লাউড ডেটাবেস অটো-সিনক্রোনাইজেশন'
              : 'Offline-first persistence with Supabase cloud backup & JSON export'}
          </p>
        </div>

        <button
          onClick={() => syncNow()}
          disabled={syncMeta.status === 'SYNCING'}
          className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-[#0B2B50] hover:bg-[#071f3b] text-white text-xs font-bold shadow-sm transition-transform active:scale-95 disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 text-amber-400 ${syncMeta.status === 'SYNCING' ? 'animate-spin' : ''}`} />
          <span>{syncMeta.status === 'SYNCING' ? 'সিঙ্ক হচ্ছে...' : 'এখনই সিঙ্ক করুন'}</span>
        </button>
      </div>

      {/* Sync Status Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-3">
          <div className="p-3 rounded-xl bg-blue-50 text-blue-700">
            <Cloud className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] text-slate-500 font-medium">নেটওয়ার্ক স্ট্যাটাস</span>
            <p className="text-sm font-bold text-slate-900 mt-0.5">
              {isOnline ? '🟢 অনলাইন (সচল)' : '🟠 অফলাইন মোড (লোকাল)'}
            </p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-3">
          <div className="p-3 rounded-xl bg-amber-50 text-amber-700">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] text-slate-500 font-medium">পেন্ডিং সিঙ্ক কিউ</span>
            <p className="text-sm font-bold text-slate-900 mt-0.5">
              {syncMeta.pendingCount} টি পরিবর্তন অপেক্ষমান
            </p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-3">
          <div className="p-3 rounded-xl bg-emerald-50 text-emerald-700">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] text-slate-500 font-medium">সর্বশেষ সফল সিঙ্ক</span>
            <p className="text-sm font-bold text-slate-900 mt-0.5">
              {syncMeta.lastSyncTime
                ? new Date(syncMeta.lastSyncTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                : 'কিছুক্ষণ আগে'}
            </p>
          </div>
        </div>
      </div>

      {/* Supabase PostgreSQL Configuration */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <Database className="w-5 h-5 text-emerald-600" />
          <div>
            <h3 className="font-bold text-sm text-slate-900">Supabase ক্লাউড ডেটাবেস সংযোগ</h3>
            <p className="text-[11px] text-slate-500">
              সমস্ত অ্যান্ড্রয়েড ফোন ও ব্রাঞ্চ ডিভাইসের ডাটা স্বয়ংক্রিয়ভাবে কেন্দ্রীয় ক্লাউডে জমা হয়
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div>
            <label className="font-semibold block mb-1 text-slate-700">Supabase Project URL</label>
            <input
              type="text"
              value={supabaseUrl}
              onChange={e => setSupabaseUrl(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border rounded-xl font-mono text-[11px]"
            />
          </div>

          <div>
            <label className="font-semibold block mb-1 text-slate-700">Supabase Anon Public API Key</label>
            <input
              type="text"
              value={supabaseKey}
              onChange={e => setSupabaseKey(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border rounded-xl font-mono text-[11px]"
            />
          </div>
        </div>

        <div className="text-[11px] text-emerald-800 bg-emerald-50 p-2.5 rounded-xl border border-emerald-200">
          ✓ ক্লাউড ডেটাবেস সংযোগ সক্রিয়। ইন্টারনেট কানেকশন পাওয়া মাত্রই অফলাইন বিক্রয়ের রেকর্ড স্বয়ংক্রিয়ভাবে সার্ভারে আপলোড হয়ে যায়।
        </div>
      </div>

      {/* Manual Local Backup Export & Restore */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <HardDrive className="w-5 h-5 text-[#0B2B50]" />
          <div>
            <h3 className="font-bold text-sm text-slate-900">ম্যানুয়াল ফাইল ব্যাকআপ ও রিস্টোর</h3>
            <p className="text-[11px] text-slate-500">
              আপনার ফোনের স্টোরেজে সমস্ত ব্যবসায়িক ডাটা এক ক্লিকে ব্যাকআপ রাখুন
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col justify-between">
            <div>
              <h4 className="font-bold text-xs text-slate-800 mb-1">ব্যাকআপ ফাইল ডাউনলোড করুন</h4>
              <p className="text-[11px] text-slate-500 mb-3">
                পণ্য, চালান, মেমো, খতিয়ান ও খরচসহ সমস্ত ডাটা একটি ফাইলে সেভ হবে।
              </p>
            </div>
            <button
              onClick={handleDownloadBackup}
              className="py-2.5 px-4 rounded-xl bg-[#0B2B50] hover:bg-[#071f3b] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs"
            >
              <Download className="w-4 h-4 text-amber-400" />
              <span>ব্যাকআপ ফাইল ডাউনলোড (JSON)</span>
            </button>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col justify-between">
            <div>
              <h4 className="font-bold text-xs text-slate-800 mb-1">পূর্বের ব্যাকআপ রিস্টোর করুন</h4>
              <p className="text-[11px] text-slate-500 mb-3">
                পূর্বে ডাউনলোড করা ব্যাকআপ ফাইল আপলোড করে সমস্ত হিসাব পুনরুদ্ধার করুন।
              </p>
            </div>
            <label className="py-2.5 px-4 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-xs">
              <Upload className="w-4 h-4 text-blue-600" />
              <span>ফাইল আপলোড করুন</span>
              <input type="file" accept=".json" onChange={handleFileUpload} className="hidden" />
            </label>
          </div>
        </div>
      </div>

      {/* Audit Log Stream */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-4">
        <h4 className="font-bold text-sm text-slate-900 mb-3 flex items-center gap-2">
          <FileText className="w-4 h-4 text-slate-500" />
          সিস্টেম অডিট লগ (কার্যক্রম ট্র্যাকিং)
        </h4>

        <div className="max-h-56 overflow-y-auto space-y-1.5 text-xs pr-1">
          {auditLogs.map(log => (
            <div
              key={log.id}
              className="p-2 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between gap-2"
            >
              <div className="min-w-0">
                <span className="font-semibold text-slate-800">{log.details}</span>
                <span className="text-[10px] text-slate-400 ml-2">দ্বারা: {log.performedBy}</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono shrink-0">
                {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
