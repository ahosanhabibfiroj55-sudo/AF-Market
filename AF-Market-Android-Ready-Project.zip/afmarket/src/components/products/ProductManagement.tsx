/**
 * AF Market - Product & Inventory Management
 * Handles wholesale purchasing prices, selling prices, stock levels,
 * low stock warnings, units (kg, litre, box, piece, packet, etc.), and role protection.
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Product, UnitType } from '../../types';
import {
  Package,
  Plus,
  Search,
  Edit2,
  Trash2,
  AlertTriangle,
  CheckCircle,
  X,
  Filter,
  BarChart2,
  ShieldAlert,
} from 'lucide-react';

export const ProductManagement: React.FC = () => {
  const { products, categories, saveProduct, deleteProduct, formatBDT, lang, t, isAdmin } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [nameBn, setNameBn] = useState('');
  const [category, setCategory] = useState('cat-grocery');
  const [barcode, setBarcode] = useState('');
  const [purchasePrice, setPurchasePrice] = useState<number>(0);
  const [sellingPrice, setSellingPrice] = useState<number>(0);
  const [currentStock, setCurrentStock] = useState<number>(0);
  const [minStockLevel, setMinStockLevel] = useState<number>(5);
  const [unit, setUnit] = useState<UnitType>('piece');
  const [description, setDescription] = useState('');

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchCat = selectedCategory === 'all' || p.category === selectedCategory;
      const matchQuery =
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.nameBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (p.barcode && p.barcode.includes(searchQuery));
      return matchCat && matchQuery;
    });
  }, [products, selectedCategory, searchQuery]);

  const openAddModal = () => {
    setEditingProduct(null);
    setName('');
    setNameBn('');
    setCategory(categories[0]?.id || 'cat-grocery');
    setBarcode(`8941${Math.floor(100000 + Math.random() * 900000)}`);
    setPurchasePrice(0);
    setSellingPrice(0);
    setCurrentStock(0);
    setMinStockLevel(5);
    setUnit('piece');
    setDescription('');
    setIsModalOpen(true);
  };

  const openEditModal = (p: Product) => {
    setEditingProduct(p);
    setName(p.name);
    setNameBn(p.nameBn);
    setCategory(p.category);
    setBarcode(p.barcode || '');
    setPurchasePrice(p.purchasePrice);
    setSellingPrice(p.sellingPrice);
    setCurrentStock(p.currentStock);
    setMinStockLevel(p.minStockLevel);
    setUnit(p.unit);
    setDescription(p.description || '');
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameBn.trim() && !name.trim()) return;

    const prodToSave: Product = {
      id: editingProduct ? editingProduct.id : `prod-${Date.now()}`,
      name: name.trim() || nameBn.trim(),
      nameBn: nameBn.trim() || name.trim(),
      category,
      barcode: barcode.trim(),
      purchasePrice: isAdmin ? purchasePrice : editingProduct ? editingProduct.purchasePrice : 0,
      sellingPrice,
      currentStock,
      minStockLevel,
      unit,
      description: description.trim(),
      createdAt: editingProduct ? editingProduct.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    saveProduct(prodToSave);
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, prodName: string) => {
    if (!isAdmin) {
      alert(lang === 'bn' ? 'শুধুমাত্র মালিক পণ্য ডিলিট করতে পারবেন' : 'Only admin can delete products');
      return;
    }
    if (confirm(lang === 'bn' ? `আপনি কি নিশ্চিত "${prodName}" পণ্যটি মুছে ফেলতে চান?` : `Delete product "${prodName}"?`)) {
      deleteProduct(id);
    }
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header & Add Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <Package className="w-5 h-5 text-[#0B2B50]" />
            {t.navProducts} ({products.length})
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'bn'
              ? 'দোকানের সমস্ত পাইকারি ও খুচরা পণ্যের তালিকা এবং স্টক পর্যবেক্ষণ'
              : 'Inventory catalog, weighted average costs & minimum stock thresholds'}
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={openAddModal}
            className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-[#0B2B50] hover:bg-[#071f3b] text-white text-xs font-bold shadow-sm transition-transform active:scale-95"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>{lang === 'bn' ? 'নতুন পণ্য যোগ করুন' : 'Add New Product'}</span>
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row gap-2.5 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={lang === 'bn' ? 'পণ্যের নাম বা বারকোড...' : 'Search product or barcode...'}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0B2B50]/20"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
              selectedCategory === 'all'
                ? 'bg-[#0B2B50] text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            {lang === 'bn' ? 'সব ক্যাটাগরি' : 'All Categories'}
          </button>
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat.id
                  ? 'bg-[#0B2B50] text-white font-semibold'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {lang === 'bn' ? cat.nameBn : cat.nameEn}
            </button>
          ))}
        </div>
      </div>

      {/* Products Table (Responsive Cards on Mobile, Clean Table on Desktop) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
              <tr>
                <th className="py-3 px-4">{t.productName}</th>
                <th className="py-3 px-3">{t.category}</th>
                {isAdmin && <th className="py-3 px-3 text-right">{t.purchasePrice}</th>}
                <th className="py-3 px-3 text-right">{t.sellingPrice}</th>
                <th className="py-3 px-3 text-center">{t.currentStock}</th>
                <th className="py-3 px-3 text-center">{lang === 'bn' ? 'স্ট্যাটাস' : 'Status'}</th>
                {isAdmin && <th className="py-3 px-4 text-right">{lang === 'bn' ? 'একশন' : 'Action'}</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProducts.map(product => {
                const categoryObj = categories.find(c => c.id === product.category);
                const isLowStock = product.currentStock <= product.minStockLevel;
                const isOutOfStock = product.currentStock <= 0;

                return (
                  <tr key={product.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900 leading-tight">
                        {lang === 'bn' ? product.nameBn : product.name}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5 font-mono">
                        {product.barcode || product.id}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-600">
                      {categoryObj ? (lang === 'bn' ? categoryObj.nameBn : categoryObj.nameEn) : product.category}
                    </td>
                    {isAdmin && (
                      <td className="py-3 px-3 text-right font-medium text-slate-700 tabular-nums">
                        {formatBDT(product.purchasePrice)}
                      </td>
                    )}
                    <td className="py-3 px-3 text-right font-bold text-slate-900 tabular-nums">
                      {formatBDT(product.sellingPrice)}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="font-bold text-slate-800 font-mono">
                        {product.currentStock}
                      </span>{' '}
                      <span className="text-[11px] text-slate-500">{product.unit}</span>
                    </td>
                    <td className="py-3 px-3 text-center">
                      {isOutOfStock ? (
                        <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800">
                          {t.outOfStock}
                        </span>
                      ) : isLowStock ? (
                        <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 animate-pulse">
                          {t.lowStock}
                        </span>
                      ) : (
                        <span className="inline-block px-2 py-0.5 rounded text-[10px] font-medium bg-emerald-50 text-emerald-700">
                          {t.inStock}
                        </span>
                      )}
                    </td>
                    {isAdmin && (
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => openEditModal(product)}
                            className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Edit Product"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDelete(product.id, product.nameBn)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            title="Delete Product"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredProducts.length === 0 && (
          <div className="py-12 text-center text-slate-400 text-xs">
            {lang === 'bn' ? 'কোনো পণ্য পাওয়া যায়নি' : 'No products found'}
          </div>
        )}
      </div>

      {/* Add / Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="bg-[#0B2B50] p-4 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm sm:text-base">
                {editingProduct
                  ? lang === 'bn'
                    ? 'পণ্য সম্পাদনা করুন'
                    : 'Edit Product'
                  : lang === 'bn'
                  ? 'নতুন পণ্য যোগ করুন'
                  : 'Add New Product'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-blue-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-4 sm:p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold block mb-1 text-slate-700">
                    {lang === 'bn' ? 'পণ্যের নাম (বাংলায়) *' : 'Product Name (Bangla) *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={nameBn}
                    onChange={e => setNameBn(e.target.value)}
                    placeholder="যেমন: মিনিকেট চাল ২৫ কেজি"
                    className="w-full p-2 bg-slate-50 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-semibold block mb-1 text-slate-700">
                    {lang === 'bn' ? 'পণ্যের নাম (ইংরেজিতে)' : 'Product Name (English)'}
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="e.g. Miniket Rice 25kg"
                    className="w-full p-2 bg-slate-50 border rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold block mb-1 text-slate-700">{t.category}</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full p-2 bg-slate-50 border rounded-xl"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.id}>
                        {lang === 'bn' ? c.nameBn : c.nameEn}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-semibold block mb-1 text-slate-700">{t.unit}</label>
                  <select
                    value={unit}
                    onChange={e => setUnit(e.target.value as UnitType)}
                    className="w-full p-2 bg-slate-50 border rounded-xl"
                  >
                    <option value="piece">{t.piece}</option>
                    <option value="kg">{t.kg}</option>
                    <option value="gram">{t.gram}</option>
                    <option value="litre">{t.litre}</option>
                    <option value="packet">{t.packet}</option>
                    <option value="box">{t.box}</option>
                    <option value="dozen">{t.dozen}</option>
                  </select>
                </div>
              </div>

              {/* Pricing Grid */}
              <div className="grid grid-cols-2 gap-3 bg-blue-50/50 p-3 rounded-xl border border-blue-100">
                <div>
                  <label className="font-semibold block mb-1 text-slate-700">
                    {t.purchasePrice} (৳)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={purchasePrice || ''}
                    onChange={e => setPurchasePrice(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full p-2 bg-white border rounded-xl font-bold"
                  />
                  <p className="text-[10px] text-slate-500 mt-0.5">
                    {lang === 'bn' ? 'গড় পাইকারি ক্রয়মূল্য' : 'Weighted average cost'}
                  </p>
                </div>

                <div>
                  <label className="font-semibold block mb-1 text-slate-700">
                    {lang === 'bn' ? 'প্রস্তাবিত বিক্রয় দর (৳) *' : `${t.sellingPrice} (৳) *`}
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={sellingPrice || ''}
                    onChange={e => setSellingPrice(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full p-2 bg-white border rounded-xl font-bold text-[#0B2B50]"
                  />
                  <p className="text-[10px] text-emerald-700 font-medium mt-0.5">
                    {lang === 'bn'
                      ? '💡 একদর নয় — বিক্রির সময় কাস্টমারভেদে কার্টে যেকোনো দর বসাতে পারবেন'
                      : 'Not fixed — rate can be changed for any customer during sale'}
                  </p>
                </div>
              </div>

              {/* Stock Levels */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-semibold block mb-1 text-slate-700">{t.currentStock}</label>
                  <input
                    type="number"
                    step="any"
                    value={currentStock || ''}
                    onChange={e => setCurrentStock(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full p-2 bg-slate-50 border rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="font-semibold block mb-1 text-slate-700">{t.minStock}</label>
                  <input
                    type="number"
                    step="any"
                    value={minStockLevel || ''}
                    onChange={e => setMinStockLevel(parseFloat(e.target.value) || 0)}
                    placeholder="5"
                    className="w-full p-2 bg-slate-50 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="font-semibold block mb-1 text-slate-700">বারকোড / কোড</label>
                  <input
                    type="text"
                    value={barcode}
                    onChange={e => setBarcode(e.target.value)}
                    placeholder="8941..."
                    className="w-full p-2 bg-slate-50 border rounded-xl font-mono text-[11px]"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">বিবরণ (ঐচ্ছিক)</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="পণ্য সম্পর্কে কোনো বিশেষ নোট..."
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                />
              </div>

              <div className="pt-2 border-t flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#0B2B50] hover:bg-[#071f3b] text-white font-bold shadow-md"
                >
                  {t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
