/**
 * AF Market - Login & User Role Switcher Modal
 * Features 4-digit PIN authentication with quick demo profile buttons
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Lock, ShieldCheck, UserCheck, KeyRound } from 'lucide-react';

export const LoginModal: React.FC = () => {
  const { isLoginModalOpen, setIsLoginModalOpen, switchUser, employees, lang, t, currentUser } = useApp();
  const [pin, setPin] = useState('');
  const [selectedEmpId, setSelectedEmpId] = useState<string>(currentUser.id);

  if (!isLoginModalOpen) return null;

  const handleDigit = (digit: string) => {
    if (pin.length < 4) {
      setPin(prev => prev + digit);
    }
  };

  const handleBackspace = () => {
    setPin(prev => prev.slice(0, -1));
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (pin.length !== 4) return;
    const success = switchUser(pin);
    if (success) {
      setPin('');
    }
  };

  const handleQuickSelect = (empPin: string, empId: string) => {
    setSelectedEmpId(empId);
    setPin(empPin);
    switchUser(empPin);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header with Official Logo */}
        <div className="bg-[#0B2B50] p-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="bg-white rounded-lg p-1">
              <img
                src="/logo.jpg"
                alt="AF Market"
                className="h-7 w-auto object-contain rounded"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base leading-tight">AF Market</h3>
              <p className="text-[11px] text-blue-200">{t.selectAccount}</p>
            </div>
          </div>
          <button
            onClick={() => setIsLoginModalOpen(false)}
            className="p-1.5 rounded-lg text-blue-200 hover:text-white hover:bg-blue-900 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 sm:p-6 space-y-5">
          {/* Employee list quick select */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-2">
              {lang === 'bn' ? 'ব্যবহারকারী নির্বাচন করুন' : 'Select User'}
            </label>
            <div className="grid grid-cols-1 gap-2">
              {employees.map(emp => {
                const isSelected = emp.id === selectedEmpId;
                const isAdmin = emp.role === 'ADMIN';
                return (
                  <button
                    key={emp.id}
                    type="button"
                    onClick={() => handleQuickSelect(emp.pin, emp.id)}
                    className={`flex items-center justify-between p-2.5 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'bg-blue-50 border-blue-500 ring-2 ring-blue-500/20'
                        : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                          isAdmin ? 'bg-amber-100 text-amber-900' : 'bg-blue-100 text-blue-900'
                        }`}
                      >
                        {isAdmin ? <ShieldCheck className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                      </div>
                      <div className="truncate">
                        <p className="text-xs font-bold text-slate-900 truncate">{emp.name}</p>
                        <p className="text-[10px] text-slate-500">
                          {isAdmin ? (lang === 'bn' ? 'মালিক / অ্যাডমিন' : 'Owner / Admin') : (lang === 'bn' ? 'কর্মচারী' : 'Employee')}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0 text-slate-400 text-xs">
                      <KeyRound className="w-3.5 h-3.5" />
                      <span className="font-mono text-[11px] font-semibold text-slate-600">{emp.pin}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* PIN Display & Keypad */}
          <div className="pt-2 border-t border-slate-100">
            <div className="text-center mb-3">
              <label className="text-xs font-medium text-slate-600 flex items-center justify-center gap-1">
                <Lock className="w-3.5 h-3.5 text-slate-500" />
                {t.enterPin}
              </label>
              {/* PIN Dots */}
              <div className="flex items-center justify-center gap-3 mt-2">
                {[0, 1, 2, 3].map(idx => (
                  <div
                    key={idx}
                    className={`w-3.5 h-3.5 rounded-full border transition-all ${
                      pin.length > idx
                        ? 'bg-[#0B2B50] border-[#0B2B50] scale-110'
                        : 'bg-slate-100 border-slate-300'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Numeric Keypad for fast touch input on phone */}
            <div className="grid grid-cols-3 gap-2 max-w-[240px] mx-auto">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map(btn => (
                <button
                  key={btn}
                  type="button"
                  onClick={() => {
                    if (btn === 'C') setPin('');
                    else if (btn === '⌫') handleBackspace();
                    else handleDigit(btn);
                  }}
                  className={`h-11 rounded-xl text-sm font-semibold transition-colors flex items-center justify-center ${
                    btn === 'C' || btn === '⌫'
                      ? 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      : 'bg-slate-50 border border-slate-200 text-slate-800 hover:bg-blue-50 hover:text-blue-900 active:scale-95'
                  }`}
                >
                  {btn}
                </button>
              ))}
            </div>

            <button
              onClick={() => handleSubmit()}
              disabled={pin.length !== 4}
              className="mt-4 w-full py-2.5 rounded-xl bg-[#0B2B50] hover:bg-[#071f3b] text-white text-xs font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-md"
            >
              {t.loginTitle}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
