/**
 * AF Market - Customer Management & Due Ledger (বাকি খাতা)
 * Manages customer balances, credit purchases, and due collections.
 * CRITICAL RULE: Due collection does NOT count as a new sale.
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Customer, PaymentMethod } from '../../types';
import {
  BookOpen,
  Plus,
  Search,
  Phone,
  MapPin,
  CheckCircle,
  X,
  CreditCard,
  UserCheck,
  History,
  AlertCircle,
  ArrowDownRight,
} from 'lucide-react';

export const CustomerManagement: React.FC = () => {
  const { customers, saveCustomer, collectDue, formatBDT, lang, t, sales } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterOnlyDue, setFilterOnlyDue] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [collectDueCustomer, setCollectDueCustomer] = useState<Customer | null>(null);
  const [collectAmount, setCollectAmount] = useState<string>('');
  const [collectMethod, setCollectMethod] = useState<PaymentMethod>('CASH');
  const [collectNote, setCollectNote] = useState<string>('');
  const [viewHistoryCustomer, setViewHistoryCustomer] = useState<Customer | null>(null);

  // New Customer form
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');

  const filteredCustomers = useMemo(() => {
    return customers.filter(c => {
      const matchDue = !filterOnlyDue || c.remainingDue > 0;
      const matchSearch =
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.phone.includes(searchQuery) ||
        (c.address && c.address.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchDue && matchSearch;
    });
  }, [customers, filterOnlyDue, searchQuery]);

  const totalOutstandingDue = customers.reduce((acc, c) => acc + c.remainingDue, 0);
  const totalDueCustomersCount = customers.filter(c => c.remainingDue > 0).length;

  const handleSaveCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    saveCustomer({
      id: `cust-${Date.now()}`,
      name: name.trim(),
      phone: phone.trim() || 'N/A',
      address: address.trim(),
      totalPurchases: 0,
      totalPaid: 0,
      remainingDue: 0,
      createdAt: new Date().toISOString(),
    });

    setIsAddModalOpen(false);
    setName('');
    setPhone('');
    setAddress('');
  };

  const handleCollectDueSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!collectDueCustomer) return;

    const amount = parseFloat(collectAmount);
    if (!amount || amount <= 0) return;

    collectDue(collectDueCustomer.id, amount, collectMethod, collectNote);
    setCollectDueCustomer(null);
    setCollectAmount('');
    setCollectNote('');
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header & KPI Summary */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-[#0B2B50]" />
            {t.navCustomers} ({customers.length})
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'bn'
              ? 'গ্রাহকদের খতিয়ান, বাকি আদায় ও লেনদেন রেকর্ড (বাকি আদায় নতুন বিক্রয় নয়)'
              : 'Customer accounts receivable, ledger tracking & payment collections'}
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-[#0B2B50] hover:bg-[#071f3b] text-white text-xs font-bold shadow-sm transition-transform active:scale-95"
        >
          <Plus className="w-4 h-4 text-amber-400" />
          <span>{lang === 'bn' ? 'নতুন কাস্টমার যোগ' : 'Add New Customer'}</span>
        </button>
      </div>

      {/* Due Summary Ribbon */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="bg-rose-50 border border-rose-200 p-3.5 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-xs text-rose-700 font-medium">{t.totalCustomerDue}</span>
            <div className="text-xl font-bold text-rose-800 tabular-nums font-mono mt-0.5">
              {formatBDT(totalOutstandingDue)}
            </div>
          </div>
          <div className="text-right">
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-rose-200 text-rose-900">
              {totalDueCustomersCount} {lang === 'bn' ? 'জনের বাকি আছে' : 'customers pending'}
            </span>
          </div>
        </div>

        <div className="bg-emerald-50 border border-emerald-200 p-3.5 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-xs text-emerald-700 font-medium">
              {lang === 'bn' ? 'মোট সংগৃহীত পেমেন্ট' : 'Total Collected Payments'}
            </span>
            <div className="text-xl font-bold text-emerald-800 tabular-nums font-mono mt-0.5">
              {formatBDT(customers.reduce((a, b) => a + b.totalPaid, 0))}
            </div>
          </div>
          <div className="text-right">
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-900">
              {customers.length} {lang === 'bn' ? 'জন কাস্টমার' : 'total customers'}
            </span>
          </div>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row gap-2.5 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={lang === 'bn' ? 'কাস্টমারের নাম বা মোবাইল...' : 'Search customer or phone...'}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0B2B50]/20"
          />
        </div>

        <button
          onClick={() => setFilterOnlyDue(!filterOnlyDue)}
          className={`w-full sm:w-auto px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
            filterOnlyDue
              ? 'bg-rose-50 border-rose-300 text-rose-800'
              : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
          }`}
        >
          {filterOnlyDue
            ? lang === 'bn'
              ? '✓ শুধু বাকি থাকা তালিকা'
              : '✓ Due Customers Only'
            : lang === 'bn'
            ? 'সব কাস্টমার দেখুন'
            : 'Show All Customers'}
        </button>
      </div>

      {/* Customer List Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
              <tr>
                <th className="py-3 px-4">কাস্টমারের নাম ও ঠিকানা</th>
                <th className="py-3 px-3">মোবাইল নম্বর</th>
                <th className="py-3 px-3 text-right">মোট কেনাকাটা</th>
                <th className="py-3 px-3 text-right">মোট পরিশোধ</th>
                <th className="py-3 px-3 text-right">অবশিষ্ট বাকি</th>
                <th className="py-3 px-4 text-right">একশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCustomers.map(customer => (
                <tr key={customer.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-bold text-slate-900">{customer.name}</div>
                    <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      <span>{customer.address || 'ঠিকানা দেওয়া হয়নি'}</span>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-slate-600 font-mono">
                    <div className="flex items-center gap-1">
                      <Phone className="w-3 h-3 text-slate-400" />
                      <span>{customer.phone}</span>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-right text-slate-700 font-medium tabular-nums">
                    {formatBDT(customer.totalPurchases)}
                  </td>
                  <td className="py-3 px-3 text-right text-emerald-700 font-semibold tabular-nums">
                    {formatBDT(customer.totalPaid)}
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums">
                    {customer.remainingDue > 0 ? (
                      <span className="font-bold text-rose-600 text-sm font-mono">
                        {formatBDT(customer.remainingDue)}
                      </span>
                    ) : (
                      <span className="text-emerald-600 font-medium">কোনো বাকি নেই</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      {customer.remainingDue > 0 && (
                        <button
                          onClick={() => {
                            setCollectDueCustomer(customer);
                            setCollectAmount(customer.remainingDue.toString());
                          }}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] shadow-xs flex items-center gap-1"
                        >
                          <CreditCard className="w-3 h-3" />
                          <span>{t.collectDue}</span>
                        </button>
                      )}
                      <button
                        onClick={() => setViewHistoryCustomer(customer)}
                        className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
                        title="View Purchase Ledger"
                      >
                        <History className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredCustomers.length === 0 && (
          <div className="py-12 text-center text-slate-400 text-xs">
            {lang === 'bn' ? 'কোনো কাস্টমার পাওয়া যায়নি' : 'No customers found'}
          </div>
        )}
      </div>

      {/* Collect Due Modal (বাকি আদায়) */}
      {collectDueCustomer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-200">
            <div className="bg-[#0B2B50] p-4 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm">
                {lang === 'bn' ? 'বাকি আদায় এন্ট্রি' : 'Collect Due Payment'}
              </h3>
              <button onClick={() => setCollectDueCustomer(null)} className="text-blue-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCollectDueSubmit} className="p-4 space-y-3.5 text-xs">
              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-900 text-sm">{collectDueCustomer.name}</p>
                <div className="flex justify-between items-center text-xs mt-1">
                  <span className="text-slate-500">বর্তমান বকেয়া বাকি:</span>
                  <span className="font-bold text-rose-600 tabular-nums text-sm">
                    {formatBDT(collectDueCustomer.remainingDue)}
                  </span>
                </div>
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">
                  {lang === 'bn' ? 'আদায়কৃত টাকার পরিমাণ (৳) *' : 'Amount Received (৳) *'}
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  max={collectDueCustomer.remainingDue}
                  step="any"
                  value={collectAmount}
                  onChange={e => setCollectAmount(e.target.value)}
                  placeholder="0"
                  className="w-full p-2.5 bg-slate-50 border rounded-xl text-sm font-bold text-emerald-800"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">{t.paymentMethod}</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {(['CASH', 'BKASH', 'NAGAD', 'BANK'] as PaymentMethod[]).map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setCollectMethod(m)}
                      className={`p-2 rounded-lg font-bold border text-center ${
                        collectMethod === m ? 'bg-[#0B2B50] text-white' : 'bg-slate-50 text-slate-700'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">নোট (ঐচ্ছিক)</label>
                <input
                  type="text"
                  value={collectNote}
                  onChange={e => setCollectNote(e.target.value)}
                  placeholder="যেমন: রশিদ বা চেক নম্বর"
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                />
              </div>

              <div className="text-[11px] text-amber-800 bg-amber-50 p-2 rounded-lg border border-amber-200">
                ℹ {lang === 'bn'
                  ? 'এই বাকি আদায় ক্যাশ বাক্সে নগদ জমা হিসেবে রেকর্ড হবে, কিন্তু নতুন বিক্রয় হিসেবে যোগ হবে না।'
                  : 'This collection will be added to the cash drawer without distorting sales revenue.'}
              </div>

              <div className="pt-2 border-t flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setCollectDueCustomer(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-semibold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-md"
                >
                  {lang === 'bn' ? 'আদায় নিশ্চিত করুন' : 'Confirm Collection'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add New Customer Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-200">
            <div className="bg-[#0B2B50] p-4 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm">
                {lang === 'bn' ? 'নতুন কাস্টমার নিবন্ধন' : 'Register New Customer'}
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-blue-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCustomer} className="p-4 space-y-3 text-xs">
              <div>
                <label className="font-semibold block mb-1 text-slate-700">কাস্টমারের নাম *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="যেমন: মো. কামাল হোসেন"
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">মোবাইল নম্বর *</label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="017xxxxxxxx"
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">ঠিকানা / পরিচিতি</label>
                <textarea
                  rows={2}
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  placeholder="বাজার মোড়, দোকান নং ১৫"
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                />
              </div>

              <div className="pt-2 border-t flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-semibold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#0B2B50] text-white font-bold shadow-md"
                >
                  {t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Customer Purchase History Drawer */}
      {viewHistoryCustomer && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-4 space-y-3">
            <div className="flex justify-between items-center pb-2 border-b">
              <h4 className="font-bold text-sm text-slate-900">
                {viewHistoryCustomer.name} - খতিয়ান হিস্ট্রি
              </h4>
              <button onClick={() => setViewHistoryCustomer(null)}>
                <X className="w-5 h-5 text-slate-500" />
              </button>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto text-xs">
              {sales
                .filter(s => s.customerId === viewHistoryCustomer.id)
                .map(sale => (
                  <div key={sale.id} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <div className="flex justify-between font-bold">
                      <span>{sale.invoiceNumber}</span>
                      <span className="tabular-nums font-mono text-[#0B2B50]">{formatBDT(sale.finalAmount)}</span>
                    </div>
                    <div className="flex justify-between text-[11px] text-slate-500 mt-1">
                      <span>তারিখ: {new Date(sale.createdAt).toLocaleDateString()}</span>
                      <span>পরিশোধ: {formatBDT(sale.amountPaid)}</span>
                    </div>
                    {sale.dueAmount > 0 && (
                      <div className="text-right text-[11px] text-rose-600 font-bold mt-0.5">
                        বাকি: ৳{sale.dueAmount}
                      </div>
                    )}
                  </div>
                ))}

              {sales.filter(s => s.customerId === viewHistoryCustomer.id).length === 0 && (
                <p className="text-center text-slate-400 py-6">কোনো পূর্ববর্তী লেনদেন পাওয়া যায়নি</p>
              )}
            </div>

            <button
              onClick={() => setViewHistoryCustomer(null)}
              className="w-full py-2 bg-slate-100 rounded-xl font-bold text-slate-700"
            >
              বন্ধ করুন
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
