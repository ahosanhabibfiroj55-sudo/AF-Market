/**
 * AF Market - Android APK & Beginner Technical Setup Guide (বাংলায়)
 * Explains PWA direct phone installation, Android Studio project setup,
 * Kotlin Room DB, Supabase PostgreSQL schema, and APK compilation in simple Bengali.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Smartphone,
  Download,
  Copy,
  Check,
  Terminal,
  Code2,
  Database,
  ExternalLink,
  ShieldCheck,
  Layers,
  HelpCircle,
  FileCode,
  QrCode,
} from 'lucide-react';

export const AndroidStudioGuide: React.FC = () => {
  const { lang, setIsMobileSetupOpen } = useApp();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [activeCodeTab, setActiveCodeTab] = useState<'manifest' | 'gradle' | 'room' | 'supabase'>('manifest');

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const manifestCode = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.afmarket.smartpos">

    <!-- Permissions for Network, Printing & Local Storage -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.BLUETOOTH" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
    <uses-permission android:name="android.permission.CAMERA" />

    <application
        android:name=".AFMarketApp"
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="AF Market"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AFMarket">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="portrait"
            android:theme="@style/Theme.AFMarket">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const gradleCode = `// app/build.gradle.kts
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.afmarket.smartpos"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.afmarket.smartpos"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
    }
}

dependencies {
    // Jetpack Compose & Material 3
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.material3)
    implementation(libs.androidx.navigation.compose)

    // Room Offline Database
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    // Supabase Kotlin SDK
    implementation(platform("io.github.jan-tennert.supabase:bom:3.0.0"))
    implementation("io.github.jan-tennert.supabase:postgrest-kt")
    implementation("io.github.jan-tennert.supabase:auth-kt")
}`;

  const roomCode = `// Kotlin Room Entities & DAO for AF Market
package com.afmarket.smartpos.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val name: String,
    val nameBn: String,
    val category: String,
    val barcode: String?,
    val purchasePrice: Double, // Weighted Average Cost
    val sellingPrice: Double,
    val currentStock: Double,
    val minStockLevel: Double,
    val unit: String,
    val syncStatus: String = "SYNCED"
)

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY nameBn ASC")
    fun getAllProducts(): Flow<List<ProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity)

    @Query("UPDATE products SET currentStock = currentStock - :qty WHERE id = :id")
    suspend fun reduceStock(id: String, qty: Double)

    @Query("UPDATE products SET currentStock = currentStock + :qty, purchasePrice = :newCost WHERE id = :id")
    suspend fun updateStockAndCost(id: String, qty: Double, newCost: Double)
}`;

  const supabaseSqlCode = `-- AF Market - Complete Supabase PostgreSQL Database Schema
CREATE TABLE IF NOT EXISTS public.businesses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL DEFAULT 'AF Market',
    tagline TEXT DEFAULT 'আপনার নিত্যদিনের বাজার',
    phone TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID REFERENCES public.businesses(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    name_bn TEXT NOT NULL,
    category TEXT NOT NULL,
    barcode TEXT,
    purchase_price NUMERIC(12,2) NOT NULL DEFAULT 0,
    selling_price NUMERIC(12,2) NOT NULL DEFAULT 0,
    current_stock NUMERIC(12,2) NOT NULL DEFAULT 0,
    min_stock_level NUMERIC(12,2) NOT NULL DEFAULT 5,
    unit TEXT NOT NULL DEFAULT 'piece',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID REFERENCES public.businesses(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    phone TEXT,
    address TEXT,
    total_purchases NUMERIC(12,2) DEFAULT 0,
    total_paid NUMERIC(12,2) DEFAULT 0,
    remaining_due NUMERIC(12,2) DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.sales (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID REFERENCES public.businesses(id) ON DELETE CASCADE,
    invoice_number TEXT NOT NULL UNIQUE,
    customer_id UUID REFERENCES public.customers(id),
    customer_name TEXT NOT NULL,
    subtotal NUMERIC(12,2) NOT NULL,
    discount NUMERIC(12,2) DEFAULT 0,
    final_amount NUMERIC(12,2) NOT NULL,
    amount_paid NUMERIC(12,2) NOT NULL,
    due_amount NUMERIC(12,2) DEFAULT 0,
    cost_of_goods_sold NUMERIC(12,2) NOT NULL,
    gross_profit NUMERIC(12,2) NOT NULL,
    payment_method TEXT NOT NULL,
    employee_id TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Row Level Security (RLS)
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow authenticated users full access" ON public.products
    FOR ALL TO authenticated USING (true);`;

  return (
    <div className="space-y-5 pb-12">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#0B2B50] to-[#164376] p-5 rounded-2xl text-white shadow-md">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-400 text-slate-950">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold">
              অ্যান্ড্রয়েড ফোন ইন্সটলেশন ও Native APK বিল্ড গাইড
            </h2>
            <p className="text-xs text-blue-200 mt-0.5">
              AF Market — নতুনদের জন্য সহজ বাংলায় মোবাইল অ্যাপ সেটআপ ও সোর্স কোড
            </p>
          </div>
        </div>
      </div>

      {/* Step 1: Direct Android Phone Install (PWA) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 space-y-4">
        <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
          <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold">
            ১
          </div>
          <h3 className="font-bold text-sm text-slate-900">
            মোবাইল ফোনে সরাসরি ইন্সটল করুন (অফলাইন কাজ করবে)
          </h3>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          আপনার কোনো কোডিং বা Android Studio জানা লাগবে না! এই অ্যাপটি সরাসরি আপনার অ্যান্ড্রয়েড ফোনে অ্যাপ আকারে হোম স্ক্রিনে ইন্সটল করে সম্পূর্ণ অফলাইনে সাধারণ দোকানের মতো ব্যবহার করতে পারবেন:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="font-bold text-slate-800 block">ধাপ ১: ব্রাউজার খুলুন</span>
            <p className="text-slate-500 text-[11px]">
              আপনার অ্যান্ড্রয়েড ফোনের <strong>Google Chrome</strong> ব্রাউজারে এই অ্যাপটির লিংক খুলুন।
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="font-bold text-slate-800 block">ধাপ ২: মেনুতে চাপ দিন</span>
            <p className="text-slate-500 text-[11px]">
              ডানদিকের উপরে <strong>তিনটি ডট (⋮)</strong> মেনুতে চাপ দিয়ে <strong>"Install app"</strong> অথবা <strong>"Add to Home screen"</strong> নির্বাচন করুন।
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 space-y-1">
            <span className="font-bold text-emerald-900 block">ধাপ ৩: অ্যাপ চালু করুন</span>
            <p className="text-emerald-800 text-[11px]">
              ফোনের হোম স্ক্রিনে অফিসিয়াল <strong>AF Market</strong> লোগোসহ আইকন চলে আসবে। নেট বন্ধ থাকলেও দ্রুত কাজ করবে!
            </p>
          </div>
        </div>

        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 bg-blue-50/70 p-3.5 rounded-xl border border-blue-200/80">
          <div className="flex items-center gap-2.5">
            <QrCode className="w-5 h-5 text-[#0B2B50] shrink-0" />
            <p className="text-xs text-slate-700">
              <strong>মোবাইলে সরাসরি নিতে চান?</strong> ফোনের ক্যামেরা দিয়ে স্ক্যান করার জন্য কিউআর কোড এবং ১-ক্লিক ইনস্টল উইন্ডো খুলুন।
            </p>
          </div>
          <button
            onClick={() => setIsMobileSetupOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#0B2B50] hover:bg-blue-900 text-white text-xs font-bold transition-all shadow-xs shrink-0 active:scale-95"
          >
            <Smartphone className="w-3.5 h-3.5 text-amber-400" />
            <span>QR কোড ও মোবাইল সেটআপ খুলুন</span>
          </button>
        </div>
      </div>

      {/* Step 2: Native Android Studio APK Building Guide */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 space-y-4">
        <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
          <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold">
            ২
          </div>
          <h3 className="font-bold text-sm text-slate-900">
            কম্পিউটারে Android Studio দিয়ে .APK ফাইল তৈরির নিয়ম
          </h3>
        </div>

        <div className="space-y-3 text-xs text-slate-700">
          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 text-[11px] leading-relaxed">
            <strong>💡 জেনে রাখা ভালো:</strong> ওয়েব ব্রাউজার ক্লাউড কনটেইনারে অ্যান্ড্রয়েড SDK এবং কম্পাইলার (javac/d8) সরাসরি রান করা যায় না। তাই নিচে আপনার জন্য পুরো রেডিমেড কোড (Kotlin, Room DB, Supabase Schema) তৈরি করে দেওয়া হয়েছে যাতে যেকেউ Android Studio-তে এক পেস্টেই সরাসরি <strong>.apk</strong> ফাইল এক্সপোর্ট করতে পারেন।
          </div>

          <ol className="list-decimal pl-5 space-y-2 text-xs">
            <li>
              <strong>Android Studio ইনস্টল করুন:</strong> গুগল থেকে একদম ফ্রি{' '}
              <a
                href="https://developer.android.com/studio"
                target="_blank"
                rel="noreferrer"
                className="text-blue-600 font-bold underline inline-flex items-center gap-0.5"
              >
                Android Studio <ExternalLink className="w-3 h-3" />
              </a>{' '}
              ডাউনলোড করুন।
            </li>
            <li>
              <strong>New Project খুলুন:</strong> "Empty Compose Activity" সিলেক্ট করুন, নাম দিন{' '}
              <code className="bg-slate-100 px-1 py-0.5 rounded font-mono font-bold">AF Market</code>, Package name দিন{' '}
              <code className="bg-slate-100 px-1 py-0.5 rounded font-mono font-bold">com.afmarket.smartpos</code>।
            </li>
            <li>
              <strong>অফিসিয়াল লোগো আইকন হিসেবে দিন:</strong> প্রকল্পের <code className="bg-slate-100 px-1">res/mipmap</code> ফোল্ডারে আপনার আপলোড করা লোগোটি রাখুন।
            </li>
            <li>
              <strong>নিচের কোডগুলো পেস্ট করুন:</strong> AndroidManifest, build.gradle, এবং Room Database কোড কপি করে ফাইলে বসিয়ে দিন।
            </li>
            <li>
              <strong>রিলিজ APK এক্সপোর্ট করুন:</strong> Android Studio এর উপরে মেনুবার থেকে{' '}
              <code className="bg-blue-100 text-[#0B2B50] font-bold px-1.5 py-0.5 rounded">
                Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)
              </code>{' '}
              চাপলেই মুহূর্তেই সরাসরি ফোনে ইন্সটলযোগ্য <strong>app-release.apk</strong> ফাইল তৈরি হয়ে যাবে!
            </li>
          </ol>
        </div>

        {/* Code Tabs Viewer */}
        <div className="pt-2 border-t border-slate-100">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2">
            {[
              { id: 'manifest', label: 'AndroidManifest.xml' },
              { id: 'gradle', label: 'build.gradle.kts' },
              { id: 'room', label: 'RoomDatabase.kt' },
              { id: 'supabase', label: 'Supabase_Schema.sql' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveCodeTab(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  activeCodeTab === tab.id
                    ? 'bg-[#0B2B50] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="relative mt-2">
            <button
              onClick={() => {
                const codeMap = {
                  manifest: manifestCode,
                  gradle: gradleCode,
                  room: roomCode,
                  supabase: supabaseSqlCode,
                };
                handleCopy(activeCodeTab, codeMap[activeCodeTab]);
              }}
              className="absolute right-3 top-3 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-1 transition-colors z-10"
            >
              {copiedKey === activeCodeTab ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>কপি হয়েছে!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>কপি কোড</span>
                </>
              )}
            </button>

            <pre className="p-4 bg-slate-950 text-slate-100 rounded-xl font-mono text-[11px] overflow-x-auto max-h-80 leading-relaxed border border-slate-800">
              {activeCodeTab === 'manifest' && manifestCode}
              {activeCodeTab === 'gradle' && gradleCode}
              {activeCodeTab === 'room' && roomCode}
              {activeCodeTab === 'supabase' && supabaseSqlCode}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
