/**
 * AF Market - Mobile Phone Setup & Direct PWA Run Modal (বাংলায়)
 * Provides dynamic QR code to scan with any phone, 1-click install button,
 * step-by-step guides for Android (Chrome) and iPhone (Safari),
 * Bluetooth printer setup, and offline mode verification.
 */

import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { useApp } from '../../context/AppContext';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import {
  Smartphone,
  QrCode,
  Download,
  Copy,
  Check,
  ExternalLink,
  WifiOff,
  Printer,
  ShieldCheck,
  CheckCircle2,
  HelpCircle,
  X,
  Share2,
  Sparkles,
  ArrowRight,
  Code2,
} from 'lucide-react';

export const MobileRunModal: React.FC = () => {
  const { isMobileSetupOpen, setIsMobileSetupOpen, lang, setActiveTab } = useApp();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();

  const [copied, setCopied] = useState(false);
  const [activePlatformTab, setActivePlatformTab] = useState<'android' | 'ios' | 'printer' | 'offline'>('android');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  // Get current app URL
  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://afmarket.app';

  useEffect(() => {
    if (isMobileSetupOpen) {
      QRCode.toDataURL(currentUrl, {
        width: 260,
        margin: 2,
        color: {
          dark: '#0B2B50',
          light: '#ffffff',
        },
      })
        .then(url => setQrDataUrl(url))
        .catch(err => console.error('QR code generation error:', err));
    }
  }, [isMobileSetupOpen, currentUrl]);

  if (!isMobileSetupOpen) return null;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      setIsMobileSetupOpen(false);
    }
  };

  const openAndroidStudioGuide = () => {
    setIsMobileSetupOpen(false);
    setActiveTab('android-guide');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-[#0B2B50] via-[#113864] to-[#1c4e85] text-white p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center shadow-md">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold leading-tight">
                {lang === 'bn' ? 'ফোনে AF Market অ্যাপ চালানোর সহজ নিয়ম' : 'How to Run AF Market on Mobile Phone'}
              </h2>
              <p className="text-xs text-blue-200 mt-0.5">
                {lang === 'bn'
                  ? 'কোনো ঝামেলা ছাড়াই সাধারণ মোবাইল অ্যাপের মতো ফুলস্ক্রিনে চালান'
                  : 'Install directly on Android or iPhone with full offline capability'}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsMobileSetupOpen(false)}
            className="p-1.5 rounded-full text-blue-200 hover:text-white hover:bg-white/10 transition-colors"
            title="বন্ধ করুন"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-6">
          {/* Quick Action Top Banner: QR Code & Direct Link */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50/60 rounded-2xl p-4 border border-blue-100 flex flex-col sm:flex-row items-center gap-5">
            {/* QR Code Container */}
            <div className="bg-white p-3 rounded-2xl shadow-sm border border-blue-200/80 flex flex-col items-center shrink-0">
              {qrDataUrl ? (
                <img
                  src={qrDataUrl}
                  alt="Scan to open on phone"
                  className="w-36 h-36 rounded-lg object-contain"
                />
              ) : (
                <div className="w-36 h-36 flex items-center justify-center text-slate-400">
                  <QrCode className="w-10 h-10 animate-pulse" />
                </div>
              )}
              <span className="text-[10px] font-bold text-blue-900 mt-1.5 flex items-center gap-1">
                <QrCode className="w-3 h-3 text-amber-500" />
                ফোনের ক্যামেরা দিয়ে স্ক্যান করুন
              </span>
            </div>

            {/* Quick Details & Direct Actions */}
            <div className="flex-1 space-y-3 w-full">
              <div>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                  <Sparkles className="w-3 h-3 text-emerald-600" />
                  ১ সেকেন্ডে রেডি — নো কোডিং
                </span>
                <h3 className="text-sm sm:text-base font-bold text-slate-900 mt-1">
                  ফোনে সরাসরি ইনস্টল করুন
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed mt-0.5">
                  কম্পিউটার বা ফোনের ব্রাউজারে লিংকটি ওপেন করে এক ক্লিকেই হোম স্ক্রিনে ইন্সটল করা যায়।
                </p>
              </div>

              {/* Install Button if browser supports beforeinstallprompt */}
              {isInstallable && (
                <button
                  onClick={handleInstallClick}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md transition-all active:scale-[0.98]"
                >
                  <Download className="w-4 h-4" />
                  <span>এখনই এই ডিভাইসে অ্যাপ ইনস্টল করুন (PWA)</span>
                </button>
              )}

              {/* Copy URL Box */}
              <div className="flex items-center gap-1.5 bg-white rounded-xl p-1.5 border border-slate-200 shadow-2xs">
                <input
                  type="text"
                  readOnly
                  value={currentUrl}
                  className="bg-transparent text-xs text-slate-700 px-2 py-1 flex-1 font-mono outline-hidden select-all truncate"
                />
                <button
                  onClick={handleCopyLink}
                  className="px-3 py-1.5 rounded-lg bg-[#0B2B50] hover:bg-blue-900 text-white text-xs font-semibold flex items-center gap-1 shrink-0 transition-colors"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>কপি হয়েছে</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>কপি লিংক</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Platform Tab Selector */}
          <div>
            <div className="flex items-center gap-1 border-b border-slate-200 pb-2 overflow-x-auto">
              <button
                onClick={() => setActivePlatformTab('android')}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activePlatformTab === 'android'
                    ? 'bg-[#0B2B50] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span>🤖 অ্যান্ড্রয়েড (Chrome)</span>
              </button>

              <button
                onClick={() => setActivePlatformTab('ios')}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activePlatformTab === 'ios'
                    ? 'bg-[#0B2B50] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span>🍎 আইফোন (iOS Safari)</span>
              </button>

              <button
                onClick={() => setActivePlatformTab('offline')}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activePlatformTab === 'offline'
                    ? 'bg-[#0B2B50] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <WifiOff className="w-3.5 h-3.5" />
                <span>অফলাইন সুবিধা</span>
              </button>

              <button
                onClick={() => setActivePlatformTab('printer')}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activePlatformTab === 'printer'
                    ? 'bg-[#0B2B50] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <Printer className="w-3.5 h-3.5" />
                <span>প্রিন্টার ও বারকোড</span>
              </button>
            </div>

            {/* Tab 1: Android Chrome Step-by-Step */}
            {activePlatformTab === 'android' && (
              <div className="pt-4 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <div className="w-7 h-7 rounded-xl bg-blue-100 text-blue-800 font-bold flex items-center justify-center text-xs">
                      ১
                    </div>
                    <h4 className="text-xs font-bold text-slate-900">Chrome-এ লিংক খুলুন</h4>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      উপরের কিউআর কোড স্ক্যান করুন অথবা Google Chrome ব্রাউজারে লিংকটি পেস্ট করে ওপেন করুন।
                    </p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <div className="w-7 h-7 rounded-xl bg-blue-100 text-blue-800 font-bold flex items-center justify-center text-xs">
                      ২
                    </div>
                    <h4 className="text-xs font-bold text-slate-900">মেনু থেকে ইনস্টল দিন</h4>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      ব্রাউজারের উপরে ডানদিকের <strong>তিনটি ডট (⋮)</strong> মেনু চাপুন এবং <strong>"Install app"</strong> অথবা <strong>"Add to Home screen"</strong> নির্বাচন করুন।
                    </p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1.5">
                    <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white font-bold flex items-center justify-center text-xs">
                      ৩
                    </div>
                    <h4 className="text-xs font-bold text-emerald-950">হোম স্ক্রিন থেকে চালান</h4>
                    <p className="text-[11px] text-emerald-800 leading-relaxed">
                      ফোনের হোম স্ক্রিনে অফিসিয়াল <strong>AF Market</strong> অ্যাপ আইকন তৈরি হয়ে যাবে। ফুলস্ক্রিনে সাধারণ অ্যাপের চেয়েও দ্রুত চলবে!
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-xs flex items-center justify-between">
                  <span>
                    💡 <strong>আপনি কি সরাসরি Android Studio .apk সোর্স ফাইল চান?</strong>
                  </span>
                  <button
                    onClick={openAndroidStudioGuide}
                    className="flex items-center gap-1 font-bold text-blue-700 hover:text-blue-900 underline ml-2 shrink-0"
                  >
                    <span>Android Studio গাইড দেখুন</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* Tab 2: iPhone iOS Safari Step-by-Step */}
            {activePlatformTab === 'ios' && (
              <div className="pt-4 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <div className="w-7 h-7 rounded-xl bg-slate-200 text-slate-800 font-bold flex items-center justify-center text-xs">
                      ১
                    </div>
                    <h4 className="text-xs font-bold text-slate-900">Safari ব্রাউজারে খুলুন</h4>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      iPhone এর মূল <strong>Safari</strong> ব্রাউজারে AF Market এর ওয়েব লিংকটি ওপেন করুন।
                    </p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <div className="w-7 h-7 rounded-xl bg-slate-200 text-slate-800 font-bold flex items-center justify-center text-xs">
                      ২
                    </div>
                    <h4 className="text-xs font-bold text-slate-900">শেয়ার বাটনে চাপ দিন</h4>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      নিচের মেনুবারে <strong>শেয়ার আইকন ⎋ (বক্সের ভেতর তীর)</strong> এ ক্লিক করুন।
                    </p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1.5">
                    <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white font-bold flex items-center justify-center text-xs">
                      ৩
                    </div>
                    <h4 className="text-xs font-bold text-emerald-950">Add to Home Screen</h4>
                    <p className="text-[11px] text-emerald-800 leading-relaxed">
                      মেনু স্ক্রল করে <strong>"Add to Home Screen"</strong> অপশনে চাপ দিন এবং 'Add' বাটনে ক্লিক করুন।
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-100 border border-slate-200 text-slate-700 text-xs">
                  🍏 আইফোনে একবার হোম স্ক্রিনে যোগ করার পর এটি কোনো ব্রাউজার বার ছাড়াই ফুলস্ক্রিন নেটিভ অ্যাপের মতো কাজ করবে।
                </div>
              </div>
            )}

            {/* Tab 3: Offline Features */}
            {activePlatformTab === 'offline' && (
              <div className="pt-4 space-y-3">
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-amber-900 font-bold text-sm">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>ইন্টারনেট ছাড়াও ১০০% বেচাকেনা চলবে</span>
                  </div>
                  <p className="text-slate-700 leading-relaxed">
                    AF Market একটি <strong>Offline-First PWA</strong> অ্যাপ্লিকেশন। আপনার ফোনে কোনো ডাটা প্যাক বা ওয়াইফাই না থাকলেও:
                  </p>
                  <ul className="list-disc pl-5 space-y-1 text-slate-700">
                    <li>নতুন বিক্রি সম্পন্ন ও ডিজিটাল রসিদ জেনারেট করা যাবে।</li>
                    <li>গ্রাহকের আগের বাকি দেখা ও নতুন বাকি তোলা যাবে।</li>
                    <li>স্টক হিসাব ও দৈনিক ক্যাশ ক্লোজিং করা যাবে।</li>
                    <li>পরবর্তীতে ইন্টারনেট কানেকশন পাওয়া মাত্রই সব ডাটা স্বয়ংক্রিয়ভাবে ক্লাউডে ব্যাকআপ নেওয়া যাবে।</li>
                  </ul>
                </div>
              </div>
            )}

            {/* Tab 4: Printer & Barcode Support */}
            {activePlatformTab === 'printer' && (
              <div className="pt-4 space-y-3 text-xs">
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                    <Printer className="w-4 h-4 text-blue-700" />
                    <span>মোবাইলের সাথে ব্লুটুথ থার্মাল প্রিন্টার কানেক্ট করার উপায়</span>
                  </h4>
                  <p className="text-slate-600 leading-relaxed">
                    দোকানের জন্য বাজারে সুলভ মূল্যের <strong>58mm</strong> বা <strong>80mm Bluetooth Thermal POS Printer</strong> খুব সহজে ব্যবহার করা যায়:
                  </p>
                  <ol className="list-decimal pl-5 space-y-1 text-slate-700">
                    <li>ফোনের <strong>Bluetooth</strong> চালু করে প্রিন্টারটির সাথে পেয়ার (Pair) করুন।</li>
                    <li>AF Market এ যেকোনো বিক্রি সম্পন্ন করার পর <strong>"রশিদ প্রিন্ট"</strong> বাটনে চাপ দিন।</li>
                    <li>ফোনের সিস্টেম প্রিন্ট উইন্ডো আসবে, সেখান থেকে আপনার ব্লুটুথ প্রিন্টার সিলেক্ট করে প্রিন্ট দিন অথবা সরাসরি PDF সেভ করুন।</li>
                  </ol>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>আপনার ডাটা আপনার ফোনেই সম্পূর্ণ নিরাপদ ও প্রাইভেট</span>
          </div>
          <button
            onClick={() => setIsMobileSetupOpen(false)}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition-colors"
          >
            বুঝেছি / সম্পন্ন
          </button>
        </div>
      </div>
    </div>
  );
};
