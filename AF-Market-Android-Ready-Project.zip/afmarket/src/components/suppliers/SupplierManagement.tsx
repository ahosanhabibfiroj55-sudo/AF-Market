/**
 * AF Market - Supplier Management & Accounts Payable (মহাজন পাওনা)
 * Manages wholesale suppliers, payable balances, and supplier payments.
 * CRITICAL RULE: Supplier payment does NOT count as a new purchase.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Supplier, PaymentMethod } from '../../types';
import {
  Building2,
  Plus,
  Search,
  Phone,
  MapPin,
  CreditCard,
  X,
  CheckCircle,
  Truck,
} from 'lucide-react';

export const SupplierManagement: React.FC = () => {
  const { suppliers, saveSupplier, paySupplier, formatBDT, lang, t, isAdmin } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [payModalSupplier, setPayModalSupplier] = useState<Supplier | null>(null);
  const [payAmount, setPayAmount] = useState<string>('');
  const [payMethod, setPayMethod] = useState<PaymentMethod>('CASH');
  const [payNote, setPayNote] = useState('');

  // Form states
  const [name, setName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');

  const filteredSuppliers = suppliers.filter(
    s =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.companyName && s.companyName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      s.phone.includes(searchQuery)
  );

  const totalOutstandingPayable = suppliers.reduce((acc, s) => acc + s.remainingPayable, 0);

  const handleSaveSupplier = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    saveSupplier({
      id: `sup-${Date.now()}`,
      name: name.trim(),
      companyName: companyName.trim() || undefined,
      phone: phone.trim() || 'N/A',
      address: address.trim() || undefined,
      totalPurchases: 0,
      totalPaid: 0,
      remainingPayable: 0,
      createdAt: new Date().toISOString(),
    });

    setIsAddModalOpen(false);
    setName('');
    setCompanyName('');
    setPhone('');
    setAddress('');
  };

  const handlePaySupplierSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payModalSupplier) return;

    const amount = parseFloat(payAmount);
    if (!amount || amount <= 0) return;

    paySupplier(payModalSupplier.id, amount, payMethod, payNote);
    setPayModalSupplier(null);
    setPayAmount('');
    setPayNote('');
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <Building2 className="w-5 h-5 text-[#0B2B50]" />
            {t.navSuppliers} ({suppliers.length})
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'bn'
              ? 'কোম্পানি বা পাইকারি মহাজনদের তালিকা এবং বকেয়া পাওনা হিসাব'
              : 'Wholesale suppliers and accounts payable management'}
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-[#0B2B50] hover:bg-[#071f3b] text-white text-xs font-bold shadow-sm transition-transform active:scale-95"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>{lang === 'bn' ? 'নতুন মহাজন / সাপ্লায়ার' : 'Add New Supplier'}</span>
          </button>
        )}
      </div>

      {/* Payable Summary Banner */}
      <div className="bg-orange-50 border border-orange-200 p-3.5 rounded-xl flex items-center justify-between">
        <div>
          <span className="text-xs text-orange-700 font-medium">{t.totalSupplierPayable}</span>
          <div className="text-xl font-bold text-orange-800 tabular-nums font-mono mt-0.5">
            {formatBDT(totalOutstandingPayable)}
          </div>
        </div>
        <div className="text-right">
          <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-orange-200 text-orange-900">
            {suppliers.filter(s => s.remainingPayable > 0).length} {lang === 'bn' ? 'প্রতিষ্ঠানের পাওনা আছে' : 'suppliers pending'}
          </span>
        </div>
      </div>

      {/* Search Input */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={lang === 'bn' ? 'সাপ্লায়ার বা কোম্পানির নাম...' : 'Search supplier name or company...'}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0B2B50]/20"
          />
        </div>
      </div>

      {/* Suppliers Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
              <tr>
                <th className="py-3 px-4">প্রতিষ্ঠান / মহাজনের নাম</th>
                <th className="py-3 px-3">যোগাযোগ</th>
                <th className="py-3 px-3 text-right">মোট ক্রয়কৃত মাল</th>
                <th className="py-3 px-3 text-right">মোট পরিশোধ</th>
                <th className="py-3 px-3 text-right">অবশিষ্ট পাওনা</th>
                {isAdmin && <th className="py-3 px-4 text-right">একশন</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredSuppliers.map(supplier => (
                <tr key={supplier.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-bold text-slate-900">{supplier.name}</div>
                    {supplier.companyName && (
                      <div className="text-[11px] text-slate-500">{supplier.companyName}</div>
                    )}
                  </td>
                  <td className="py-3 px-3 text-slate-600 font-mono">
                    <div className="flex items-center gap-1">
                      <Phone className="w-3 h-3 text-slate-400" />
                      <span>{supplier.phone}</span>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-right text-slate-700 font-medium tabular-nums">
                    {formatBDT(supplier.totalPurchases)}
                  </td>
                  <td className="py-3 px-3 text-right text-emerald-700 font-semibold tabular-nums">
                    {formatBDT(supplier.totalPaid)}
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums">
                    {supplier.remainingPayable > 0 ? (
                      <span className="font-bold text-orange-600 font-mono text-sm">
                        {formatBDT(supplier.remainingPayable)}
                      </span>
                    ) : (
                      <span className="text-emerald-600 font-medium">পরিশোধিত</span>
                    )}
                  </td>
                  {isAdmin && (
                    <td className="py-3 px-4 text-right">
                      {supplier.remainingPayable > 0 && (
                        <button
                          onClick={() => {
                            setPayModalSupplier(supplier);
                            setPayAmount(supplier.remainingPayable.toString());
                          }}
                          className="px-2.5 py-1 rounded-lg bg-orange-600 hover:bg-orange-500 text-white font-bold text-[11px] shadow-xs flex items-center gap-1 ml-auto"
                        >
                          <CreditCard className="w-3 h-3" />
                          <span>{t.paySupplier}</span>
                        </button>
                      )}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pay Supplier Modal */}
      {payModalSupplier && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-200">
            <div className="bg-[#0B2B50] p-4 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm">মহাজন পাওনা পরিশোধ এন্ট্রি</h3>
              <button onClick={() => setPayModalSupplier(null)} className="text-blue-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePaySupplierSubmit} className="p-4 space-y-3.5 text-xs">
              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-900 text-sm">{payModalSupplier.name}</p>
                <div className="flex justify-between items-center text-xs mt-1">
                  <span className="text-slate-500">মহাজনের বকেয়া পাওনা:</span>
                  <span className="font-bold text-orange-600 tabular-nums text-sm">
                    {formatBDT(payModalSupplier.remainingPayable)}
                  </span>
                </div>
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">পরিশোধের পরিমাণ (৳) *</label>
                <input
                  type="number"
                  required
                  min="1"
                  max={payModalSupplier.remainingPayable}
                  step="any"
                  value={payAmount}
                  onChange={e => setPayAmount(e.target.value)}
                  placeholder="0"
                  className="w-full p-2.5 bg-slate-50 border rounded-xl text-sm font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">{t.paymentMethod}</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {(['CASH', 'BANK', 'BKASH', 'NAGAD'] as PaymentMethod[]).map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setPayMethod(m)}
                      className={`p-2 rounded-lg font-bold border text-center ${
                        payMethod === m ? 'bg-[#0B2B50] text-white' : 'bg-slate-50 text-slate-700'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">চেক / ভাউচার নোট</label>
                <input
                  type="text"
                  value={payNote}
                  onChange={e => setPayNote(e.target.value)}
                  placeholder="যেমন: ব্যাংক চেক নং বা ভাউচার"
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                />
              </div>

              <div className="pt-2 border-t flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPayModalSupplier(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-semibold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#0B2B50] text-white font-bold shadow-md"
                >
                  পরিশোধ নিশ্চিত করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Supplier Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-200">
            <div className="bg-[#0B2B50] p-4 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm">নতুন মহাজন / সরবরাহকারী যোগ</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-blue-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSupplier} className="p-4 space-y-3 text-xs">
              <div>
                <label className="font-semibold block mb-1 text-slate-700">প্রতিষ্ঠানের নাম *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="যেমন: মেঘনা গ্রুপ / সিটি ট্রেডার্স"
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">কোম্পানি / ব্র্যান্ড</label>
                <input
                  type="text"
                  value={companyName}
                  onChange={e => setCompanyName(e.target.value)}
                  placeholder="যেমন: ফ্রেশ / তীর"
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">মোবাইল নম্বর *</label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="017xxxxxxxx"
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">ঠিকানা</label>
                <textarea
                  rows={2}
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  placeholder="দোকান বা গোডাউন ঠিকানা"
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                />
              </div>

              <div className="pt-2 border-t flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-semibold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#0B2B50] text-white font-bold shadow-md"
                >
                  {t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
