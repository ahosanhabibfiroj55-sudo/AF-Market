/**
 * AF Market - Daily Cash Management & Drawer Reconciliation
 * Compares calculated cash balance with physical counted cash in shop.
 * Displays shortage (ঘাটতি) or surplus (উদ্বৃত্ত) with audit history.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Wallet,
  CheckCircle2,
  AlertTriangle,
  History,
  Lock,
  ArrowDownLeft,
  ArrowUpRight,
  Calculator,
} from 'lucide-react';

export const DailyCashManagement: React.FC = () => {
  const { cashSession, allCashSessions, closeDailyCash, formatBDT, lang, t, isAdmin, currentUser } = useApp();

  const [actualCountedInput, setActualCountedInput] = useState<string>(
    cashSession.actualCountedCash !== null ? cashSession.actualCountedCash.toString() : ''
  );
  const [closingNotes, setClosingNotes] = useState<string>(cashSession.notes || '');

  const countedAmount = parseFloat(actualCountedInput) || 0;
  const difference = countedAmount - cashSession.expectedClosingCash;

  const handleCloseDrawer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) {
      alert(lang === 'bn' ? 'শুধুমাত্র মালিক ক্যাশ ড্রয়ার বন্ধ করতে পারবেন' : 'Only admin can close drawer');
      return;
    }
    if (actualCountedInput === '') {
      alert(lang === 'bn' ? 'দয়া করে ক্যাশ ড্রয়ারে গুনে পাওয়া টাকা লিখুন' : 'Please enter actual counted cash');
      return;
    }

    closeDailyCash(countedAmount, closingNotes);
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <Wallet className="w-5 h-5 text-[#0B2B50]" />
              {t.dailyCashTitle}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              তারিখ: {cashSession.date} · {cashSession.status === 'OPEN' ? '🟢 ড্রয়ার খোলা আছে' : '🔒 ড্রয়ার বন্ধ'}
            </p>
          </div>

          <span
            className={`px-3 py-1 rounded-full text-xs font-bold ${
              cashSession.status === 'OPEN'
                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                : 'bg-slate-200 text-slate-800'
            }`}
          >
            {cashSession.status === 'OPEN' ? 'সক্রিয় হিসাব' : 'সমাপ্ত হিসাব'}
          </span>
        </div>
      </div>

      {/* Main Breakdown Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Cash Inflows & Outflows (lg:col-span-7) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
            <h3 className="font-bold text-sm text-slate-900 pb-2 border-b border-slate-100 flex items-center justify-between">
              <span>ক্যাশ ড্রয়ার হিসাব বিবরণী</span>
              <span className="text-xs font-normal text-slate-500 font-mono">{cashSession.date}</span>
            </h3>

            {/* Inflows */}
            <div className="space-y-2 text-xs">
              <div className="flex justify-between items-center p-2 rounded-lg bg-slate-50">
                <span className="text-slate-600 font-medium">১. সকালের প্রারম্ভিক ক্যাশ (Opening Cash):</span>
                <span className="font-bold text-slate-800 tabular-nums">{formatBDT(cashSession.openingCash)}</span>
              </div>

              <div className="flex justify-between items-center p-2 rounded-lg bg-emerald-50/60 border border-emerald-100">
                <span className="text-emerald-800 font-medium flex items-center gap-1">
                  <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-600" />
                  ২. আজকের নগদ বিক্রয় জমা (+):
                </span>
                <span className="font-bold text-emerald-800 tabular-nums font-mono">
                  +{formatBDT(cashSession.cashSales)}
                </span>
              </div>

              <div className="flex justify-between items-center p-2 rounded-lg bg-emerald-50/60 border border-emerald-100">
                <span className="text-emerald-800 font-medium flex items-center gap-1">
                  <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-600" />
                  ৩. আজকের নগদ বাকি আদায় জমা (+):
                </span>
                <span className="font-bold text-emerald-800 tabular-nums font-mono">
                  +{formatBDT(cashSession.customerDueCollections)}
                </span>
              </div>

              {/* Outflows */}
              <div className="flex justify-between items-center p-2 rounded-lg bg-rose-50/60 border border-rose-100">
                <span className="text-rose-800 font-medium flex items-center gap-1">
                  <ArrowUpRight className="w-3.5 h-3.5 text-rose-600" />
                  ৪. নগদ পাইকারি মাল ক্রয় খরচ (-):
                </span>
                <span className="font-bold text-rose-800 tabular-nums font-mono">
                  -{formatBDT(cashSession.cashPurchases)}
                </span>
              </div>

              <div className="flex justify-between items-center p-2 rounded-lg bg-rose-50/60 border border-rose-100">
                <span className="text-rose-800 font-medium flex items-center gap-1">
                  <ArrowUpRight className="w-3.5 h-3.5 text-rose-600" />
                  ৫. নগদ দোকান খরচ (-):
                </span>
                <span className="font-bold text-rose-800 tabular-nums font-mono">
                  -{formatBDT(cashSession.cashExpenses)}
                </span>
              </div>
            </div>

            {/* Expected Result */}
            <div className="p-3.5 rounded-xl bg-[#0B2B50] text-white flex justify-between items-center font-bold">
              <div>
                <span className="text-xs text-blue-200 block">ক্যাশ বাক্সে থাকার কথা (হিসাবমতে):</span>
                <span className="text-lg tabular-nums font-mono">{formatBDT(cashSession.expectedClosingCash)}</span>
              </div>
              <Calculator className="w-6 h-6 text-amber-400 opacity-80" />
            </div>
          </div>
        </div>

        {/* Right: Cash Count Verification & Reconciliation (lg:col-span-5) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
            <h3 className="font-bold text-sm text-slate-900 pb-2 border-b border-slate-100">
              হাতে গুনে ক্যাশ হিসাব মিলানো
            </h3>

            <form onSubmit={handleCloseDrawer} className="space-y-3 text-xs">
              <div>
                <label className="font-bold block mb-1 text-slate-800">
                  {lang === 'bn' ? 'ড্রয়ার গুনে কত টাকা পাওয়া গেল? (৳) *' : 'Actual Cash Counted in Drawer (৳) *'}
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  required
                  value={actualCountedInput}
                  onChange={e => setActualCountedInput(e.target.value)}
                  placeholder="যেমন: ১৫০০০"
                  className="w-full p-2.5 bg-slate-50 border rounded-xl font-bold text-base text-slate-900 tabular-nums"
                />
              </div>

              {/* Real-time Shortage / Surplus Indicator */}
              {actualCountedInput !== '' && (
                <div
                  className={`p-3 rounded-xl border text-xs font-semibold ${
                    difference === 0
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                      : difference < 0
                      ? 'bg-rose-50 border-rose-300 text-rose-900'
                      : 'bg-indigo-50 border-indigo-300 text-indigo-900'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {difference === 0 ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 shrink-0" />
                    )}
                    <div>
                      <p className="font-bold">
                        {difference === 0
                          ? '✓ নিখুঁত হিসাব! ড্রয়ারের টাকা হুবহু মিলেছে।'
                          : difference < 0
                          ? `⚠️ টাকা কম! ঘাটতি: ${formatBDT(Math.abs(difference))}`
                          : `ℹ️ উদ্বৃত্ত টাকা: ${formatBDT(difference)} বেশি পাওয়া গেছে`}
                      </p>
                      <p className="text-[11px] opacity-90 mt-0.5">
                        {difference < 0
                          ? 'সম্ভাব্য কারণ: ভুল ফেরত দেওয়া বা কোনো নগদ খরচের মেমো বাদ পড়া।'
                          : 'সম্ভাব্য কারণ: বকশিশ বা অতিরিক্ত জমা।'}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label className="font-semibold block mb-1 text-slate-700">মন্তব্য বা নোট</label>
                <textarea
                  rows={2}
                  value={closingNotes}
                  onChange={e => setClosingNotes(e.target.value)}
                  placeholder="দিনের ক্লোজিং সম্পর্কে নোট..."
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                />
              </div>

              {isAdmin && (
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-[#0B2B50] hover:bg-[#071f3b] text-white font-bold text-xs shadow-md transition-colors"
                >
                  {cashSession.status === 'OPEN' ? 'আজকের ক্যাশ ড্রয়ার বন্ধ ও সেভ করুন' : 'হিসাব আপডেট করুন'}
                </button>
              )}
            </form>
          </div>
        </div>
      </div>

      {/* Historical Cash Closings Log */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-4">
        <h4 className="font-bold text-sm text-slate-900 mb-3 flex items-center gap-2">
          <History className="w-4 h-4 text-slate-500" />
          পূর্ববর্তী ক্যাশ ড্রয়ার ক্লোজিং লগ
        </h4>
        <div className="space-y-2">
          {allCashSessions.map(session => (
            <div
              key={session.id}
              className="flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs gap-2"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900">{session.date}</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-200 text-slate-700">
                    {session.status}
                  </span>
                </div>
                <p className="text-slate-500 text-[11px] mt-0.5">
                  প্রারম্ভিক: {formatBDT(session.openingCash)} · নগদ বিক্রয়: {formatBDT(session.cashSales)} · বাকি আদায়: {formatBDT(session.customerDueCollections)}
                </p>
              </div>

              <div className="text-left sm:text-right">
                <p className="font-bold text-slate-900">
                  গুনে পাওয়া: {session.actualCountedCash !== null ? formatBDT(session.actualCountedCash) : 'অসম্পূর্ণ'}
                </p>
                {session.difference !== null && (
                  <p
                    className={`text-[11px] font-bold ${
                      session.difference === 0
                        ? 'text-emerald-700'
                        : session.difference < 0
                        ? 'text-rose-600'
                        : 'text-indigo-600'
                    }`}
                  >
                    পার্থক্য: {session.difference === 0 ? '০ (মিলেছে)' : formatBDT(session.difference)}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
