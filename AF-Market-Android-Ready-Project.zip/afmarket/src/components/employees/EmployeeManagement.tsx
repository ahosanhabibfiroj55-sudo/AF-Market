/**
 * AF Market - Employee Management & Role-Based Access Control
 * Allows owner/admin to manage staff accounts, 4-digit PINs,
 * view employee performance, and enforce strict permission barriers.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Employee, UserRole } from '../../types';
import {
  Users,
  Plus,
  ShieldCheck,
  UserCheck,
  KeyRound,
  Phone,
  Mail,
  Calendar,
  CheckCircle,
  XCircle,
  Edit2,
  X,
  Lock,
  ShoppingBag,
} from 'lucide-react';

export const EmployeeManagement: React.FC = () => {
  const { employees, updateEmployee, sales, formatBDT, lang, t, isAdmin, currentUser } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEmp, setEditingEmp] = useState<Employee | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [pin, setPin] = useState('');
  const [role, setRole] = useState<UserRole>('EMPLOYEE');
  const [isActive, setIsActive] = useState(true);

  const openAddModal = () => {
    setEditingEmp(null);
    setName('');
    setPhone('');
    setEmail('');
    setPin(`${Math.floor(1000 + Math.random() * 9000)}`);
    setRole('EMPLOYEE');
    setIsActive(true);
    setIsModalOpen(true);
  };

  const openEditModal = (emp: Employee) => {
    setEditingEmp(emp);
    setName(emp.name);
    setPhone(emp.phone);
    setEmail(emp.email);
    setPin(emp.pin);
    setRole(emp.role);
    setIsActive(emp.isActive);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || pin.length !== 4) return;

    updateEmployee({
      id: editingEmp ? editingEmp.id : `emp-${Date.now()}`,
      name: name.trim(),
      phone: phone.trim() || 'N/A',
      email: email.trim() || `${name.toLowerCase().replace(/\s+/g, '')}@afmarket.com`,
      pin: pin.trim(),
      role,
      isActive,
      joiningDate: editingEmp ? editingEmp.joiningDate : new Date().toISOString().split('T')[0],
    });

    setIsModalOpen(false);
  };

  const toggleStatus = (emp: Employee) => {
    if (emp.id === currentUser.id) {
      alert('নিজের অ্যাকাউন্ট ডিএক্টিভেট করা যাবে না!');
      return;
    }
    updateEmployee({ ...emp, isActive: !emp.isActive });
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-[#0B2B50]" />
            {t.navEmployees} ({employees.length})
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            দোকানের বিক্রয় সহকারী ও স্টাফদের অ্যাকাউন্ট এবং দায়িত্ব নির্ধারণ
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={openAddModal}
            className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-[#0B2B50] hover:bg-[#071f3b] text-white text-xs font-bold shadow-sm transition-transform active:scale-95"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>নতুন কর্মচারী যুক্ত করুন</span>
          </button>
        )}
      </div>

      {/* Permissions Guide Info Box */}
      <div className="bg-slate-100 p-3.5 rounded-xl border border-slate-200 text-xs space-y-1.5">
        <h4 className="font-bold text-slate-800 flex items-center gap-1.5">
          <Lock className="w-4 h-4 text-blue-700" />
          নিরাপত্তা ও এক্সেস কন্ট্রোল নীতিমালা:
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-600">
          <div>
            <span className="font-bold text-slate-900">✓ কর্মচারীদের অনুমতি:</span> পণ্য বিক্রয় (POS), কাস্টমার তথ্য দেখা, বাকি আদায় ও রশিদ প্রদান।
          </div>
          <div>
            <span className="font-bold text-slate-900">✕ কর্মচারীদের নিষেধাজ্ঞা:</span> পাইকারি ক্রয়মূল্য দেখা নিষিদ্ধ, লাভ-ক্ষতির রিপোর্ট নিষিদ্ধ, পণ্য বা রেকর্ড মোছা নিষিদ্ধ।
          </div>
        </div>
      </div>

      {/* Employees Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {employees.map(emp => {
          const isThisAdmin = emp.role === 'ADMIN';
          const empSales = sales.filter(s => s.employeeId === emp.id);
          const empTotalSales = empSales.reduce((a, b) => a + b.finalAmount, 0);

          return (
            <div
              key={emp.id}
              className={`bg-white rounded-2xl border p-4 shadow-2xs flex flex-col justify-between transition-all ${
                emp.isActive ? 'border-slate-200 hover:border-blue-300' : 'border-slate-200 opacity-60 bg-slate-50'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold ${
                        isThisAdmin ? 'bg-amber-100 text-amber-900' : 'bg-blue-100 text-blue-900'
                      }`}
                    >
                      {isThisAdmin ? <ShieldCheck className="w-5 h-5" /> : <UserCheck className="w-5 h-5" />}
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{emp.name}</h4>
                      <span className="text-[10px] uppercase font-semibold text-slate-500">
                        {isThisAdmin ? 'মালিক / অ্যাডমিন' : 'দোকান কর্মচারী'}
                      </span>
                    </div>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      emp.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {emp.isActive ? 'সক্রিয়' : 'নিষ্ক্রিয়'}
                  </span>
                </div>

                <div className="py-2.5 border-y border-slate-100 space-y-1 text-xs text-slate-600">
                  <div className="flex items-center gap-1.5 font-mono">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{emp.phone}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    <span className="truncate">{emp.email}</span>
                  </div>
                  <div className="flex items-center gap-1.5 font-mono">
                    <KeyRound className="w-3.5 h-3.5 text-amber-600" />
                    <span className="font-bold text-slate-800">লগইন পিন: {emp.pin}</span>
                  </div>
                </div>

                {/* Sales Performance */}
                <div className="py-2 text-xs flex items-center justify-between text-slate-700">
                  <span className="flex items-center gap-1 text-[11px] text-slate-500">
                    <ShoppingBag className="w-3.5 h-3.5" />
                    মোট বিক্রয়:
                  </span>
                  <span className="font-bold tabular-nums text-slate-900 font-mono">
                    {formatBDT(empTotalSales)} ({empSales.length})
                  </span>
                </div>
              </div>

              {isAdmin && (
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 mt-2">
                  <button
                    onClick={() => toggleStatus(emp)}
                    className={`text-xs font-semibold px-2 py-1 rounded-lg ${
                      emp.isActive
                        ? 'text-rose-600 hover:bg-rose-50'
                        : 'text-emerald-600 hover:bg-emerald-50'
                    }`}
                  >
                    {emp.isActive ? 'ডিএক্টিভেট' : 'সক্রিয় করুন'}
                  </button>

                  <button
                    onClick={() => openEditModal(emp)}
                    className="flex items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-800 p-1 rounded-lg hover:bg-blue-50"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>এডিট</span>
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Add / Edit Employee Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-200">
            <div className="bg-[#0B2B50] p-4 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm">
                {editingEmp ? 'কর্মচারী তথ্য আপডেট' : 'নতুন কর্মচারী যুক্ত করুন'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-blue-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-4 space-y-3.5 text-xs">
              <div>
                <label className="font-semibold block mb-1 text-slate-700">কর্মচারীর নাম *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="যেমন: শাকিল আহমেদ"
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">মোবাইল নম্বর *</label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="018xxxxxxxx"
                  className="w-full p-2 bg-slate-50 border rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">৪ সংখ্যার গোপন পিন (Security PIN) *</label>
                <input
                  type="text"
                  required
                  maxLength={4}
                  value={pin}
                  onChange={e => setPin(e.target.value)}
                  placeholder="1234"
                  className="w-full p-2 bg-slate-50 border rounded-xl font-mono text-center text-sm font-bold tracking-widest"
                />
                <p className="text-[10px] text-slate-500 mt-0.5">এই পিন দিয়ে কর্মচারী নিজের ফোনে লগইন করবে</p>
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">ভূমিকা / রোল</label>
                <select
                  value={role}
                  onChange={e => setRole(e.target.value as UserRole)}
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                >
                  <option value="EMPLOYEE">কর্মচারী (Employee - POS ও বাকি আদায় এক্সেস)</option>
                  <option value="ADMIN">মালিক / অ্যাডমিন (Admin - পূর্ণ এক্সেস)</option>
                </select>
              </div>

              <div className="pt-2 border-t flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-semibold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#0B2B50] text-white font-bold shadow-md"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
