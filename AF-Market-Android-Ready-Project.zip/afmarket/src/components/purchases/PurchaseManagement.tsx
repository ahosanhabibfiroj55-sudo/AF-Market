/**
 * AF Market - Wholesale Purchase Management
 * Manages wholesale purchases, automatic inventory stock increment,
 * and weighted average unit cost (WAUC) calculations.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Purchase, PurchaseItem, PaymentMethod } from '../../types';
import {
  Truck,
  Plus,
  Trash2,
  Calendar,
  Building2,
  CheckCircle2,
  X,
  FileText,
  Calculator,
  AlertCircle,
} from 'lucide-react';

export const PurchaseManagement: React.FC = () => {
  const { purchases, suppliers, products, recordPurchase, formatBDT, lang, t, currentUser } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedSupplierId, setSelectedSupplierId] = useState(suppliers[0]?.id || '');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CASH');
  const [purchaseDate, setPurchaseDate] = useState(new Date().toISOString().split('T')[0]);
  const [transportCost, setTransportCost] = useState<number>(0);
  const [discount, setDiscount] = useState<number>(0);
  const [amountPaid, setAmountPaid] = useState<string>('');

  // Purchase items in modal
  const [items, setItems] = useState<{ productId: string; quantity: number; unitPrice: number }[]>([
    { productId: products[0]?.id || '', quantity: 10, unitPrice: products[0]?.purchasePrice || 100 },
  ]);

  const addItemRow = () => {
    setItems(prev => [...prev, { productId: products[0]?.id || '', quantity: 5, unitPrice: 100 }]);
  };

  const updateItemRow = (index: number, field: string, value: any) => {
    setItems(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  const removeItemRow = (index: number) => {
    setItems(prev => prev.filter((_, i) => i !== index));
  };

  const subtotal = items.reduce((acc, item) => acc + item.quantity * item.unitPrice, 0);
  const totalAmount = Math.max(0, subtotal + transportCost - discount);
  const paidVal = amountPaid !== '' ? parseFloat(amountPaid) || 0 : totalAmount;
  const remainingPayable = Math.max(0, totalAmount - paidVal);

  const handleSavePurchase = (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;

    const supplier = suppliers.find(s => s.id === selectedSupplierId);

    const purchaseItems: PurchaseItem[] = items.map(item => {
      const prod = products.find(p => p.id === item.productId);
      return {
        productId: item.productId,
        productName: prod ? (lang === 'bn' ? prod.nameBn : prod.name) : 'Product',
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        subtotal: item.quantity * item.unitPrice,
      };
    });

    recordPurchase({
      supplierId: selectedSupplierId,
      supplierName: supplier?.name || 'Supplier',
      supplierPhone: supplier?.phone,
      items: purchaseItems,
      subtotal,
      discount,
      additionalCosts: transportCost,
      totalAmount,
      amountPaid: Math.min(totalAmount, paidVal),
      remainingPayable,
      paymentMethod,
      date: purchaseDate,
      recordedBy: currentUser.name,
    });

    setIsModalOpen(false);
    setItems([{ productId: products[0]?.id || '', quantity: 10, unitPrice: products[0]?.purchasePrice || 100 }]);
    setTransportCost(0);
    setDiscount(0);
    setAmountPaid('');
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <Truck className="w-5 h-5 text-[#0B2B50]" />
            {t.purchaseTitle}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'bn'
              ? 'মহাজন বা কোম্পানির পাইকারি চালান এন্ট্রি। স্বয়ংক্রিয়ভাবে স্টক বাড়বে ও গড় মূল্য সমন্বয় হবে।'
              : 'Wholesale supplier invoice entries with automated inventory cost weighting.'}
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-[#0B2B50] hover:bg-[#071f3b] text-white text-xs font-bold shadow-sm transition-transform active:scale-95"
        >
          <Plus className="w-4 h-4 text-amber-400" />
          <span>{lang === 'bn' ? 'নতুন চালান এন্ট্রি' : 'New Purchase Entry'}</span>
        </button>
      </div>

      {/* Weighted Average Formula Info Card */}
      <div className="bg-blue-50/70 border border-blue-200 p-3.5 rounded-xl flex items-start gap-3 text-xs">
        <Calculator className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
        <div>
          <h4 className="font-bold text-blue-900">
            {lang === 'bn' ? 'অ্যাকাউন্টিং নিয়ম: ওয়েটেড অ্যাভারেজ কস্ট (WAUC)' : 'Weighted Average Cost Rule'}
          </h4>
          <p className="text-blue-800 text-[11px] mt-0.5">
            {lang === 'bn'
              ? 'নতুন পণ্য কেনার সাথে সাথে ফর্মুলা অনুসারে স্বয়ংক্রিয়ভাবে গড় ক্রয়মূল্য আপডেট হয়: ((পূর্বের স্টক × পূর্বের রেট) + (নতুন চালানের পরিমাণ × নতুন রেট)) ÷ নতুন মোট স্টক।'
              : 'Every new purchase updates inventory value and COGS automatically based on weighted average unit price.'}
          </p>
        </div>
      </div>

      {/* Purchases List Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
              <tr>
                <th className="py-3 px-4">চালান নং ও তারিখ</th>
                <th className="py-3 px-3">সাপ্লায়ার / মহাজন</th>
                <th className="py-3 px-3">পণ্য সংখ্যা</th>
                <th className="py-3 px-3 text-right">চালানের মোট টাকা</th>
                <th className="py-3 px-3 text-right">পরিশোধ</th>
                <th className="py-3 px-3 text-right">অবশিষ্ট পাওনা</th>
                <th className="py-3 px-4 text-center">মাধ্যম</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {purchases.map(p => (
                <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-bold text-slate-900">{p.purchaseNumber}</div>
                    <div className="text-[11px] text-slate-400">{p.date}</div>
                  </td>
                  <td className="py-3 px-3">
                    <div className="font-semibold text-slate-800">{p.supplierName}</div>
                    <div className="text-[11px] text-slate-400">{p.supplierPhone}</div>
                  </td>
                  <td className="py-3 px-3 text-slate-600">
                    {p.items.length} টি পণ্য ({p.items.reduce((a, b) => a + b.quantity, 0)} একক)
                  </td>
                  <td className="py-3 px-3 text-right font-bold text-slate-900 tabular-nums">
                    {formatBDT(p.totalAmount)}
                  </td>
                  <td className="py-3 px-3 text-right text-emerald-700 font-semibold tabular-nums">
                    {formatBDT(p.amountPaid)}
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums">
                    {p.remainingPayable > 0 ? (
                      <span className="font-bold text-orange-600">
                        {formatBDT(p.remainingPayable)}
                      </span>
                    ) : (
                      <span className="text-slate-400">পরিশোধিত</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                      {p.paymentMethod}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {purchases.length === 0 && (
          <div className="py-12 text-center text-slate-400 text-xs">
            {lang === 'bn' ? 'কোনো পাইকারি চালানের রেকর্ড পাওয়া যায়নি' : 'No purchases recorded yet'}
          </div>
        )}
      </div>

      {/* New Purchase Entry Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-200">
            <div className="bg-[#0B2B50] p-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Truck className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm sm:text-base">
                  {lang === 'bn' ? 'নতুন পাইকারি চালান এন্ট্রি' : 'New Purchase Invoice'}
                </h3>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-blue-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePurchase} className="p-4 sm:p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="font-semibold block mb-1 text-slate-700">{t.supplier} *</label>
                  <select
                    value={selectedSupplierId}
                    onChange={e => setSelectedSupplierId(e.target.value)}
                    className="w-full p-2 bg-slate-50 border rounded-xl"
                  >
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} {s.remainingPayable > 0 ? `(পূর্বের পাওনা: ৳${s.remainingPayable})` : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-semibold block mb-1 text-slate-700">চালানের তারিখ</label>
                  <input
                    type="date"
                    value={purchaseDate}
                    onChange={e => setPurchaseDate(e.target.value)}
                    className="w-full p-2 bg-slate-50 border rounded-xl"
                  />
                </div>
              </div>

              {/* Items Table */}
              <div className="border border-slate-200 rounded-xl p-3 bg-slate-50/50 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800">চালানের পণ্যসমূহ (আইটেম তালিকা)</span>
                  <button
                    type="button"
                    onClick={addItemRow}
                    className="px-2.5 py-1 rounded-lg bg-blue-100 hover:bg-blue-200 text-[#0B2B50] font-bold text-[11px] flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" />
                    <span>আইটেম যোগ করুন</span>
                  </button>
                </div>

                <div className="space-y-2">
                  {items.map((row, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-white p-2 rounded-lg border border-slate-200">
                      <div className="flex-1">
                        <select
                          value={row.productId}
                          onChange={e => {
                            const prod = products.find(p => p.id === e.target.value);
                            updateItemRow(idx, 'productId', e.target.value);
                            if (prod) {
                              updateItemRow(idx, 'unitPrice', prod.purchasePrice || 100);
                            }
                          }}
                          className="w-full p-1.5 bg-slate-50 border rounded-lg text-xs"
                        >
                          {products.map(p => (
                            <option key={p.id} value={p.id}>
                              {lang === 'bn' ? p.nameBn : p.name} (বর্তমান স্টক: {p.currentStock} {p.unit})
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="w-20">
                        <input
                          type="number"
                          min="1"
                          step="any"
                          value={row.quantity}
                          onChange={e => updateItemRow(idx, 'quantity', parseFloat(e.target.value) || 0)}
                          placeholder="পরিমাণ"
                          className="w-full p-1.5 border rounded-lg text-center font-bold"
                        />
                      </div>

                      <div className="w-24">
                        <input
                          type="number"
                          min="0"
                          step="any"
                          value={row.unitPrice}
                          onChange={e => updateItemRow(idx, 'unitPrice', parseFloat(e.target.value) || 0)}
                          placeholder="দর ৳"
                          className="w-full p-1.5 border rounded-lg text-right font-bold"
                        />
                      </div>

                      <div className="w-24 text-right font-bold text-slate-800 tabular-nums">
                        ৳{row.quantity * row.unitPrice}
                      </div>

                      {items.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeItemRow(idx)}
                          className="p-1 text-slate-400 hover:text-rose-600"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Totals & Payments */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="space-y-2">
                  <div>
                    <label className="font-semibold block mb-1 text-slate-700">{t.transportCost} (৳)</label>
                    <input
                      type="number"
                      min="0"
                      value={transportCost || ''}
                      onChange={e => setTransportCost(parseFloat(e.target.value) || 0)}
                      placeholder="0"
                      className="w-full p-2 bg-white border rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="font-semibold block mb-1 text-slate-700">{t.paymentMethod}</label>
                    <select
                      value={paymentMethod}
                      onChange={e => setPaymentMethod(e.target.value as PaymentMethod)}
                      className="w-full p-2 bg-white border rounded-xl"
                    >
                      <option value="CASH">নগদ (Cash)</option>
                      <option value="BANK">ব্যাংক চেক (Bank)</option>
                      <option value="BKASH">বিকাশ (bKash)</option>
                      <option value="CREDIT">সম্পূর্ণ বাকি (Supplier Credit)</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between font-bold text-sm text-slate-900">
                    <span>সর্বমোট চালান মূল্য:</span>
                    <span className="tabular-nums font-mono text-[#0B2B50]">{formatBDT(totalAmount)}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-700">{t.paidAmount} (৳):</span>
                    <input
                      type="number"
                      min="0"
                      value={amountPaid}
                      onChange={e => setAmountPaid(e.target.value)}
                      placeholder={totalAmount.toString()}
                      className="w-28 p-1.5 text-right bg-white border rounded-lg font-bold"
                    />
                  </div>

                  {remainingPayable > 0 && (
                    <div className="flex justify-between font-bold text-orange-600 bg-orange-50 p-1.5 rounded border border-orange-200">
                      <span>বাকি থাকবে (মহাজন পাবে):</span>
                      <span className="tabular-nums font-mono">৳{remainingPayable}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="pt-2 border-t flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-semibold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#0B2B50] text-white font-bold shadow-md"
                >
                  {lang === 'bn' ? 'চালান নিশ্চিত ও স্টক বৃদ্ধি করুন' : 'Confirm & Increment Stock'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
