/**
 * AF Market - Shop Expense Management
 * Tracks shop rent, electricity, staff salary, tea/food, transport, packaging.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Expense, ExpenseCategory, PaymentMethod } from '../../types';
import {
  Receipt,
  Plus,
  Calendar,
  Tag,
  DollarSign,
  X,
  CreditCard,
  PieChart,
} from 'lucide-react';

export const ExpenseManagement: React.FC = () => {
  const { expenses, recordExpense, formatBDT, lang, t, currentUser } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('FOOD');
  const [amount, setAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CASH');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  const categoryLabels: Record<ExpenseCategory, { bn: string; en: string }> = {
    RENT: { bn: 'দোকান ভাড়া', en: 'Shop Rent' },
    ELECTRICITY: { bn: 'বিদ্যুৎ বিল', en: 'Electricity Bill' },
    SALARY: { bn: 'কর্মচারীর বেতন', en: 'Staff Salary' },
    TRANSPORT: { bn: 'যাতায়াত ও কুলি', en: 'Transport' },
    FOOD: { bn: 'খাবার ও নাস্তা', en: 'Tea & Food' },
    MAINTENANCE: { bn: 'মেরামত ও রক্ষণাবেক্ষণ', en: 'Maintenance' },
    PACKAGING: { bn: 'প্যাকিং ও পলিথিন', en: 'Packaging' },
    OTHER: { bn: 'অন্যান্য খরচ', en: 'Other Expense' },
  };

  const totalExpenseAmount = expenses.reduce((acc, e) => acc + e.amount, 0);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (!title.trim() || !parsedAmount || parsedAmount <= 0) return;

    recordExpense({
      title: title.trim(),
      category,
      amount: parsedAmount,
      paymentMethod,
      description: description.trim() || undefined,
      recordedBy: currentUser.name,
      date,
    });

    setIsModalOpen(false);
    setTitle('');
    setAmount('');
    setDescription('');
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <Receipt className="w-5 h-5 text-[#0B2B50]" />
            {t.navExpenses} ({expenses.length})
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'bn'
              ? 'দোকানের ভাড়া, বিদ্যুৎ বিল, কর্মচারীদের নাস্তা ও বিবিধ খরচের হিসাব'
              : 'Daily operating expenses, utilities, rent, and packaging logs'}
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-[#0B2B50] hover:bg-[#071f3b] text-white text-xs font-bold shadow-sm transition-transform active:scale-95"
        >
          <Plus className="w-4 h-4 text-amber-400" />
          <span>{lang === 'bn' ? 'নতুন খরচ এন্ট্রি' : 'Add Expense'}</span>
        </button>
      </div>

      {/* Expense Summary Card */}
      <div className="bg-rose-50 border border-rose-200 p-4 rounded-xl flex items-center justify-between">
        <div>
          <span className="text-xs text-rose-700 font-medium">{lang === 'bn' ? 'মোট দোকান খরচ' : 'Total Expenses'}</span>
          <div className="text-2xl font-bold text-rose-800 tabular-nums font-mono mt-0.5">
            {formatBDT(totalExpenseAmount)}
          </div>
        </div>
        <div className="p-2.5 rounded-xl bg-rose-200/60 text-rose-800">
          <Receipt className="w-6 h-6" />
        </div>
      </div>

      {/* Expenses Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
              <tr>
                <th className="py-3 px-4">তারিখ</th>
                <th className="py-3 px-3">খরচের বিবরণ</th>
                <th className="py-3 px-3">ক্যাটাগরি</th>
                <th className="py-3 px-3 text-right">টাকা</th>
                <th className="py-3 px-3 text-center">পেমেন্ট মাধ্যম</th>
                <th className="py-3 px-4 text-right">এন্ট্রি করেছেন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {expenses.map(expense => (
                <tr key={expense.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4 font-mono text-slate-500">{expense.date}</td>
                  <td className="py-3 px-3">
                    <div className="font-bold text-slate-900">{expense.title}</div>
                    {expense.description && (
                      <div className="text-[11px] text-slate-400 truncate max-w-xs">{expense.description}</div>
                    )}
                  </td>
                  <td className="py-3 px-3">
                    <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                      {categoryLabels[expense.category] ? categoryLabels[expense.category].bn : expense.category}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right font-bold text-rose-600 font-mono text-sm tabular-nums">
                    {formatBDT(expense.amount)}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-200 text-slate-800">
                      {expense.paymentMethod}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right text-slate-500">{expense.recordedBy}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {expenses.length === 0 && (
          <div className="py-12 text-center text-slate-400 text-xs">কোনো খরচ রেকর্ড করা হয়নি</div>
        )}
      </div>

      {/* Add Expense Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-200">
            <div className="bg-[#0B2B50] p-4 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm">নতুন দোকান খরচ এন্ট্রি</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-blue-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-4 space-y-3.5 text-xs">
              <div>
                <label className="font-semibold block mb-1 text-slate-700">খরচের নাম / বিবরণ *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="যেমন: দোকানের বিদ্যুৎ বিল / নাস্তা"
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="font-semibold block mb-1 text-slate-700">ক্যাটাগরি</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value as ExpenseCategory)}
                    className="w-full p-2 bg-slate-50 border rounded-xl"
                  >
                    {Object.entries(categoryLabels).map(([catKey, catVal]) => (
                      <option key={catKey} value={catKey}>
                        {catVal.bn}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-semibold block mb-1 text-slate-700">তারিখ</label>
                  <input
                    type="date"
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full p-2 bg-slate-50 border rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">টাকার পরিমাণ (৳) *</label>
                <input
                  type="number"
                  required
                  min="1"
                  step="any"
                  value={amount}
                  onChange={e => setAmount(e.target.value)}
                  placeholder="0"
                  className="w-full p-2.5 bg-slate-50 border rounded-xl font-bold text-rose-600 text-sm"
                />
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">{t.paymentMethod}</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['CASH', 'BKASH', 'NAGAD'] as PaymentMethod[]).map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setPaymentMethod(m)}
                      className={`p-2 rounded-lg font-bold border text-center ${
                        paymentMethod === m ? 'bg-[#0B2B50] text-white' : 'bg-slate-50 text-slate-700'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-semibold block mb-1 text-slate-700">অতিরিক্ত নোট</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="কাকে দেওয়া হলো বা ভাউচার নম্বর..."
                  className="w-full p-2 bg-slate-50 border rounded-xl"
                />
              </div>

              <div className="pt-2 border-t flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-semibold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#0B2B50] text-white font-bold shadow-md"
                >
                  খরচ সংরক্ষণ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
