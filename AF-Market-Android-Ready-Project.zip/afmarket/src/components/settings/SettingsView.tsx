/**
 * AF Market - Application Settings
 * Business profile, shop contact details, default currency, and system reset.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Settings,
  Store,
  DollarSign,
  Globe,
  Database,
  Smartphone,
  Save,
  RotateCcw,
  ShieldCheck,
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { lang, setLang, t, showToast, refreshAllData } = useApp();

  const [shopName, setShopName] = useState('AF Market');
  const [taglineBn, setTaglineBn] = useState('আপনার নিত্যদিনের বাজার');
  const [taglineEn, setTaglineEn] = useState('Smart Business Management System');
  const [phone, setPhone] = useState('01712-345678');
  const [address, setAddress] = useState('বাজার মোড়, মেইন রোড, বাংলাদেশ');

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    showToast('দোকানের সেটিংস সফলভাবে আপডেট করা হয়েছে!', 'success');
  };

  const handleResetData = () => {
    if (confirm('সতর্কতা: আপনি কি নিশ্চিত সব ডাটা মুছে প্রাথমিক ডেমো অবস্থায় ফিরতে চান?')) {
      localStorage.clear();
      window.location.reload();
    }
  };

  return (
    <div className="space-y-4 pb-12 max-w-3xl">
      {/* Header */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
        <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
          <Settings className="w-5 h-5 text-[#0B2B50]" />
          {t.navSettings}
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          দোকানের নাম, ঠিকানা, মুদ্রা ও সিস্টেম পছন্দসমূহ
        </p>
      </div>

      {/* Business Profile Form */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <h3 className="font-bold text-sm text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2 mb-4">
          <Store className="w-4 h-4 text-blue-700" />
          দোকানের পরিচিতি ও রসিদের হেডার
        </h3>

        <form onSubmit={handleSaveProfile} className="space-y-3.5 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold block mb-1 text-slate-700">দোকানের অফিসিয়াল নাম</label>
              <input
                type="text"
                disabled
                value={shopName}
                className="w-full p-2.5 bg-slate-100 border rounded-xl font-bold text-slate-900 cursor-not-allowed"
              />
              <p className="text-[10px] text-slate-400 mt-0.5">অফিসিয়াল নাম নির্ধারিত: AF Market</p>
            </div>

            <div>
              <label className="font-semibold block mb-1 text-slate-700">ট্যাগলাইন (বাংলায়)</label>
              <input
                type="text"
                value={taglineBn}
                onChange={e => setTaglineBn(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold block mb-1 text-slate-700">দোকানের মোবাইল নম্বর</label>
              <input
                type="text"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border rounded-xl font-mono"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1 text-slate-700">ডিফল্ট মুদ্রা (Currency)</label>
              <input
                type="text"
                disabled
                value="বাংলাদেশি টাকা (BDT / ৳)"
                className="w-full p-2.5 bg-slate-100 border rounded-xl font-bold cursor-not-allowed"
              />
            </div>
          </div>

          <div>
            <label className="font-semibold block mb-1 text-slate-700">দোকানের পূর্ণ ঠিকানা</label>
            <input
              type="text"
              value={address}
              onChange={e => setAddress(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border rounded-xl"
            />
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-[#0B2B50] hover:bg-[#071f3b] text-white font-bold text-xs shadow-md flex items-center gap-1.5"
            >
              <Save className="w-4 h-4 text-amber-400" />
              <span>সেটিংস সংরক্ষণ করুন</span>
            </button>
          </div>
        </form>
      </div>

      {/* Language Preference */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
        <h3 className="font-bold text-sm text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2">
          <Globe className="w-4 h-4 text-blue-700" />
          অ্যাপ্লিকেশনের ভাষা পছন্দ (Language)
        </h3>

        <div className="flex gap-3 text-xs">
          <button
            onClick={() => setLang('bn')}
            className={`flex-1 p-3 rounded-xl border text-center font-bold transition-all ${
              lang === 'bn'
                ? 'bg-blue-50 border-[#0B2B50] text-[#0B2B50] ring-2 ring-blue-500/20'
                : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            বাংলা (বাংলা ভাষা - ডিফল্ট)
          </button>
          <button
            onClick={() => setLang('en')}
            className={`flex-1 p-3 rounded-xl border text-center font-bold transition-all ${
              lang === 'en'
                ? 'bg-blue-50 border-[#0B2B50] text-[#0B2B50] ring-2 ring-blue-500/20'
                : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            English (English Language)
          </button>
        </div>
      </div>

      {/* System Reset / Danger Zone */}
      <div className="bg-white p-5 rounded-2xl border border-red-200 shadow-2xs space-y-3">
        <h3 className="font-bold text-sm text-red-900 pb-2 border-b border-red-100 flex items-center gap-2">
          <RotateCcw className="w-4 h-4 text-red-600" />
          সিস্টেম রিসেট ও ডেমো ডাটা
        </h3>
        <p className="text-xs text-slate-600">
          আপনি যদি টেস্ট ডেটা পরিবর্তন করে একদম নতুন দোকান শুরু করতে চান তবে নিচের বাটনে ক্লিক করুন।
        </p>
        <button
          onClick={handleResetData}
          className="px-4 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-bold transition-colors"
        >
          সমস্ত টেস্ট ডাটা রিসেট করুন
        </button>
      </div>
    </div>
  );
};
