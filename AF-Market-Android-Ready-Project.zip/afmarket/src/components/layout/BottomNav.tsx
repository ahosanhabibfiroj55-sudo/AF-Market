/**
 * AF Market - Mobile Bottom Navigation
 * Styled like native Android Material 3 bottom navigation bar with Bengali labels
 */

import React, { useState } from 'react';
import { useApp, AppTab } from '../../context/AppContext';
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  BookOpen,
  MoreHorizontal,
  Truck,
  Receipt,
  Wallet,
  TrendingUp,
  Users,
  Settings,
  HelpCircle,
  X,
  Smartphone,
  QrCode,
} from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, t, lang, isAdmin, setIsMobileSetupOpen } = useApp();
  const [isMoreOpen, setIsMoreOpen] = useState(false);

  const mainItems: { tab: AppTab; label: string; icon: any }[] = [
    { tab: 'dashboard', label: t.navDashboard, icon: LayoutDashboard },
    { tab: 'pos', label: t.navPos, icon: ShoppingCart },
    { tab: 'products', label: t.navProducts, icon: Package },
    { tab: 'customers', label: t.navCustomers, icon: BookOpen },
  ];

  const moreItems: { tab: AppTab; label: string; icon: any; adminOnly?: boolean }[] = [
    { tab: 'purchases', label: t.navPurchases, icon: Truck, adminOnly: true },
    { tab: 'expenses', label: t.navExpenses, icon: Receipt },
    { tab: 'daily-cash', label: t.navDailyCash, icon: Wallet, adminOnly: true },
    { tab: 'reports', label: t.navReports, icon: TrendingUp, adminOnly: true },
    { tab: 'employees', label: t.navEmployees, icon: Users, adminOnly: true },
    { tab: 'android-guide', label: t.navAndroidGuide, icon: HelpCircle },
    { tab: 'settings', label: t.navSettings, icon: Settings, adminOnly: true },
  ];

  const handleSelectTab = (tab: AppTab) => {
    setActiveTab(tab);
    setIsMoreOpen(false);
  };

  return (
    <>
      {/* Bottom Sheet Menu for 'More' */}
      {isMoreOpen && (
        <div className="fixed inset-0 z-40 bg-black/50 backdrop-blur-xs flex flex-col justify-end">
          <div className="bg-white rounded-t-2xl p-4 shadow-2xl max-w-lg mx-auto w-full border-t border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="font-bold text-slate-800 text-sm">
                {lang === 'bn' ? 'অতিরিক্ত মেনু ও ফিচার' : 'Additional Features'}
              </span>
              <button
                onClick={() => setIsMoreOpen(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mobile Setup Quick Button */}
            <div className="pt-3">
              <button
                onClick={() => {
                  setIsMoreOpen(false);
                  setIsMobileSetupOpen(true);
                }}
                className="w-full p-2.5 rounded-xl bg-gradient-to-r from-[#0B2B50] to-[#164376] text-white flex items-center justify-between shadow-sm active:scale-[0.99] transition-all"
              >
                <div className="flex items-center gap-2">
                  <div className="p-1 rounded-lg bg-amber-400 text-slate-950">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-bold leading-tight">
                      {lang === 'bn' ? 'ফোনে ইনস্টল ও QR কোড' : 'Install on Phone (QR Code)'}
                    </p>
                    <p className="text-[10px] text-blue-200">
                      {lang === 'bn' ? 'অ্যাপ হিসেবে সরাসরি ফোনে চালান' : 'Run as native app with offline support'}
                    </p>
                  </div>
                </div>
                <QrCode className="w-4 h-4 text-amber-400 shrink-0" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2.5 py-4">
              {moreItems.map(item => {
                if (item.adminOnly && !isAdmin) return null;
                const Icon = item.icon;
                const isCurrent = activeTab === item.tab;
                return (
                  <button
                    key={item.tab}
                    onClick={() => handleSelectTab(item.tab)}
                    className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                      isCurrent
                        ? 'bg-blue-50 border-blue-500 text-[#0B2B50] font-semibold'
                        : 'bg-slate-50 border-slate-200/80 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className={`w-5 h-5 mb-1.5 ${isCurrent ? 'text-blue-700' : 'text-slate-500'}`} />
                    <span className="text-[11px] leading-tight line-clamp-1">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Persistent Bottom Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-slate-200 shadow-lg px-2 py-1 flex items-center justify-around">
        {mainItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.tab;
          return (
            <button
              key={item.tab}
              onClick={() => setActiveTab(item.tab)}
              className={`flex-1 flex flex-col items-center justify-center py-1 rounded-lg transition-colors ${
                isActive ? 'text-[#0B2B50]' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <div
                className={`p-1 rounded-full transition-all ${
                  isActive ? 'bg-blue-100 text-[#0B2B50]' : 'bg-transparent'
                }`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <span
                className={`text-[10px] tracking-tight mt-0.5 whitespace-nowrap ${
                  isActive ? 'font-bold text-[#0B2B50]' : 'font-medium'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}

        {/* More Button */}
        <button
          onClick={() => setIsMoreOpen(prev => !prev)}
          className={`flex-1 flex flex-col items-center justify-center py-1 rounded-lg transition-colors ${
            isMoreOpen || !mainItems.some(i => i.tab === activeTab)
              ? 'text-[#0B2B50]'
              : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <div
            className={`p-1 rounded-full ${
              isMoreOpen || !mainItems.some(i => i.tab === activeTab)
                ? 'bg-blue-100 text-[#0B2B50]'
                : 'bg-transparent'
            }`}
          >
            <MoreHorizontal className="w-5 h-5" />
          </div>
          <span className="text-[10px] tracking-tight mt-0.5 font-medium whitespace-nowrap">
            {lang === 'bn' ? 'আরও মেনু' : 'More'}
          </span>
        </button>
      </nav>
    </>
  );
};
