/**
 * AF Market - Desktop / Tablet Sidebar Navigation
 * Clean enterprise styling with deep blue active highlights and badge indicators
 */

import React from 'react';
import { useApp, AppTab } from '../../context/AppContext';
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  BookOpen,
  Truck,
  Building2,
  Receipt,
  Wallet,
  TrendingUp,
  Users,
  Settings,
  HelpCircle,
  AlertTriangle,
  RefreshCw,
  LogOut,
  Smartphone,
  QrCode,
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, t, lang, isAdmin, products, syncMeta, currentUser, setIsLoginModalOpen, setIsMobileSetupOpen } = useApp();

  const lowStockCount = products.filter(p => p.currentStock <= p.minStockLevel).length;

  const navSections: {
    title: string;
    items: { tab: AppTab; label: string; icon: any; badge?: number | string; badgeColor?: string; adminOnly?: boolean }[];
  }[] = [
    {
      title: lang === 'bn' ? 'প্রধান ব্যবসা' : 'Core Business',
      items: [
        { tab: 'dashboard', label: t.navDashboard, icon: LayoutDashboard },
        { tab: 'pos', label: t.navPos, icon: ShoppingCart },
        {
          tab: 'products',
          label: t.navProducts,
          icon: Package,
          badge: lowStockCount > 0 ? lowStockCount : undefined,
          badgeColor: 'bg-red-500 text-white',
        },
        { tab: 'purchases', label: t.navPurchases, icon: Truck, adminOnly: true },
      ],
    },
    {
      title: lang === 'bn' ? 'খাতা ও লেনদেন' : 'Ledgers & Accounts',
      items: [
        { tab: 'customers', label: t.navCustomers, icon: BookOpen },
        { tab: 'suppliers', label: t.navSuppliers, icon: Building2, adminOnly: true },
        { tab: 'expenses', label: t.navExpenses, icon: Receipt },
        { tab: 'daily-cash', label: t.navDailyCash, icon: Wallet, adminOnly: true },
      ],
    },
    {
      title: lang === 'bn' ? 'অ্যাকাউন্টিং ও সেটিংস' : 'Reports & System',
      items: [
        { tab: 'reports', label: t.navReports, icon: TrendingUp, adminOnly: true },
        { tab: 'employees', label: t.navEmployees, icon: Users, adminOnly: true },
        {
          tab: 'sync',
          label: t.navSync,
          icon: RefreshCw,
          badge: syncMeta.pendingCount > 0 ? syncMeta.pendingCount : undefined,
          badgeColor: 'bg-amber-500 text-slate-900',
        },
        { tab: 'android-guide', label: t.navAndroidGuide, icon: HelpCircle },
        { tab: 'settings', label: t.navSettings, icon: Settings, adminOnly: true },
      ],
    },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col shrink-0 min-h-[calc(100vh-60px)]">
      {/* Navigation Links */}
      <div className="flex-1 py-4 px-3 space-y-6 overflow-y-auto">
        {navSections.map((section, idx) => {
          const visibleItems = section.items.filter(item => !item.adminOnly || isAdmin);
          if (visibleItems.length === 0) return null;

          return (
            <div key={idx}>
              <div className="px-3 mb-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                {section.title}
              </div>
              <div className="space-y-0.5">
                {visibleItems.map(item => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.tab;
                  return (
                    <button
                      key={item.tab}
                      onClick={() => setActiveTab(item.tab)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-colors ${
                        isActive
                          ? 'bg-[#0B2B50] text-white shadow-sm font-semibold'
                          : 'text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-amber-400' : 'text-slate-500'}`} />
                        <span className="truncate">{item.label}</span>
                      </div>
                      {item.badge !== undefined && (
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full shrink-0 ${
                            item.badgeColor || 'bg-slate-200 text-slate-700'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Mobile App Setup Card */}
      <div className="px-3 pb-2 pt-1">
        <button
          onClick={() => setIsMobileSetupOpen(true)}
          className="w-full p-2.5 rounded-xl bg-gradient-to-r from-[#0B2B50] to-[#164376] hover:from-[#113864] hover:to-[#1e528f] text-white flex items-center justify-between text-left transition-all shadow-xs"
        >
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-amber-400 text-slate-950 font-bold">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold leading-tight">
                {lang === 'bn' ? 'ফোনে চালান' : 'Run on Phone'}
              </p>
              <p className="text-[10px] text-blue-200">
                {lang === 'bn' ? 'QR কোড ও অ্যাপ ইনস্টল' : 'QR Scan & Install'}
              </p>
            </div>
          </div>
          <QrCode className="w-4 h-4 text-amber-400" />
        </button>
      </div>

      {/* User Status Footer Box */}
      <div className="p-3 border-t border-slate-200 bg-slate-50/80">
        <div className="flex items-center justify-between gap-2 p-2 rounded-xl bg-white border border-slate-200 shadow-2xs">
          <div className="min-w-0">
            <p className="text-xs font-bold text-slate-900 truncate">{currentUser.name}</p>
            <p className="text-[10px] text-slate-500 truncate">
              {isAdmin
                ? lang === 'bn'
                  ? 'মালিক (পূর্ণ এক্সেস)'
                  : 'Owner (Full Access)'
                : lang === 'bn'
                ? 'কর্মচারী এক্সেস'
                : 'Employee Access'}
            </p>
          </div>
          <button
            onClick={() => setIsLoginModalOpen(true)}
            className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
            title={t.switchRole}
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
};
