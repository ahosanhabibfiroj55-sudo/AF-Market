/**
 * AF Market - App Header
 * Features official logo, brand identity, user role switch,
 * online/offline detector & simulator, sync button, and language toggle.
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Wifi,
  WifiOff,
  RefreshCw,
  Globe,
  User,
  Smartphone,
  Monitor,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Menu,
} from 'lucide-react';

interface HeaderProps {
  onToggleMobileMenu?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleMobileMenu }) => {
  const {
    lang,
    setLang,
    t,
    currentUser,
    isAdmin,
    setIsLoginModalOpen,
    isOnline,
    setIsOnline,
    syncMeta,
    syncNow,
    isAndroidFrame,
    setIsAndroidFrame,
    setIsMobileSetupOpen,
  } = useApp();

  return (
    <header className="sticky top-0 z-30 bg-[#0B2B50] text-white shadow-md border-b border-blue-950">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex items-center justify-between gap-3">
        {/* Left: Mobile Menu Button & Brand Identity with Official Logo */}
        <div className="flex items-center gap-3">
          {onToggleMobileMenu && (
            <button
              onClick={onToggleMobileMenu}
              className="md:hidden p-1.5 rounded-lg bg-blue-900/60 hover:bg-blue-800 text-white transition-colors"
              aria-label="Toggle navigation"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}

          <div className="flex items-center gap-2.5">
            <div className="bg-white rounded-lg p-1 shadow-sm flex items-center justify-center shrink-0">
              <img
                src="/logo.jpg"
                alt="AF Market Logo"
                className="h-9 w-auto max-w-[120px] sm:max-w-[150px] object-contain rounded"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="hidden sm:block">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-lg tracking-tight leading-tight text-white">
                  AF Market
                </span>
                <span className="text-[10px] uppercase font-semibold bg-amber-500 text-slate-950 px-1.5 py-0.5 rounded leading-none">
                  Smart POS
                </span>
              </div>
              <p className="text-[11px] text-blue-200 leading-none mt-0.5">
                {lang === 'bn' ? 'আপনার নিত্যদিনের বাজার' : 'Smart Business Management System'}
              </p>
            </div>
          </div>
        </div>

        {/* Right: Controls & User Switcher */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          {/* Network Mode Status (Clickable to simulate offline/online) */}
          <button
            onClick={() => setIsOnline(!isOnline)}
            title={isOnline ? t.statusOnline : t.statusOffline}
            className={`flex items-center gap-1.5 px-2 py-1 rounded text-xs font-medium transition-colors ${
              isOnline
                ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700/60'
                : 'bg-amber-950/90 text-amber-300 border border-amber-600 animate-pulse'
            }`}
          >
            {isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
            <span className="hidden md:inline">
              {isOnline ? (lang === 'bn' ? 'অনলাইন' : 'Online') : (lang === 'bn' ? 'অফলাইন মোড' : 'Offline')}
            </span>
          </button>

          {/* Sync Status Button */}
          <button
            onClick={() => syncNow()}
            disabled={syncMeta.status === 'SYNCING'}
            title={lang === 'bn' ? 'ডাটাবেস সিঙ্ক করুন' : 'Sync to Cloud'}
            className="flex items-center gap-1.5 px-2 py-1 rounded text-xs font-medium bg-blue-900/80 hover:bg-blue-800 border border-blue-700/50 text-blue-100 transition-colors"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${syncMeta.status === 'SYNCING' ? 'animate-spin text-amber-400' : ''}`}
            />
            {syncMeta.pendingCount > 0 ? (
              <span className="bg-amber-500 text-slate-900 text-[10px] font-bold px-1 rounded-full leading-none">
                {syncMeta.pendingCount}
              </span>
            ) : (
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 hidden sm:inline" />
            )}
            <span className="hidden lg:inline">
              {syncMeta.status === 'SYNCING'
                ? t.syncing
                : syncMeta.pendingCount > 0
                ? `${syncMeta.pendingCount} ${t.pendingSync}`
                : t.synced}
            </span>
          </button>

          {/* Run on Mobile / QR & PWA Install Button */}
          <button
            onClick={() => setIsMobileSetupOpen(true)}
            title={lang === 'bn' ? 'মোবাইলে চালান / ইনস্টল গাইড ও QR কোড' : 'Run on Mobile (QR & Install)'}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 transition-colors"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">
              {lang === 'bn' ? 'ফোনে চালান' : 'Mobile'}
            </span>
          </button>

          {/* Android Frame Simulator Toggle (Desktop only) */}
          <button
            onClick={() => setIsAndroidFrame(!isAndroidFrame)}
            title={isAndroidFrame ? 'Switch to Fullscreen/Desktop' : 'Switch to Android Mobile View'}
            className="hidden xl:flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-blue-900/60 hover:bg-blue-800 text-blue-200 border border-blue-700/40 transition-colors"
          >
            {isAndroidFrame ? <Monitor className="w-3.5 h-3.5" /> : <Smartphone className="w-3.5 h-3.5" />}
            <span>{isAndroidFrame ? 'Desktop' : 'Frame'}</span>
          </button>

          {/* Language Switcher */}
          <button
            onClick={() => setLang(lang === 'bn' ? 'en' : 'bn')}
            className="flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-blue-900/60 hover:bg-blue-800 text-blue-100 border border-blue-700/40 transition-colors"
            title="বাংলা / English"
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-semibold">{lang === 'bn' ? 'English' : 'বাংলা'}</span>
          </button>

          {/* User Account / Role Switcher */}
          <button
            onClick={() => setIsLoginModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-semibold shadow-sm transition-all"
            title={t.switchRole}
          >
            {isAdmin ? <ShieldCheck className="w-4 h-4" /> : <User className="w-4 h-4" />}
            <div className="text-left leading-tight hidden sm:block">
              <span className="block text-[11px] font-bold max-w-[90px] truncate">{currentUser.name}</span>
              <span className="block text-[9px] text-slate-900/80 font-medium uppercase">
                {isAdmin ? (lang === 'bn' ? 'মালিক' : 'Admin') : (lang === 'bn' ? 'কর্মচারী' : 'Staff')}
              </span>
            </div>
            <span className="sm:hidden font-bold">{isAdmin ? 'মালিক' : 'স্টাফ'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
