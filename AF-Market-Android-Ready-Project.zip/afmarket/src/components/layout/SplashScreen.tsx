/**
 * AF Market - Splash Screen
 * Features official original brand logo with deep blue background and animations.
 */

import React, { useEffect, useState } from 'react';
import { ShoppingCart, CheckCircle2, ShieldCheck } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(15);

  useEffect(() => {
    const timer1 = setTimeout(() => setProgress(55), 400);
    const timer2 = setTimeout(() => setProgress(90), 800);
    const timer3 = setTimeout(() => {
      setProgress(100);
      setTimeout(onComplete, 350);
    }, 1200);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 bg-[#0B2B50] flex flex-col items-center justify-between p-8 text-white select-none">
      <div />

      {/* Center Brand Identity with Official Logo */}
      <div className="flex flex-col items-center text-center space-y-4 max-w-sm w-full">
        {/* Official Logo Container */}
        <div className="bg-white p-3 rounded-3xl shadow-2xl flex items-center justify-center transition-transform duration-700 transform scale-100 animate-in fade-in zoom-in-75">
          <img
            src="/logo.jpg"
            alt="AF Market Logo"
            className="w-56 sm:w-64 h-auto object-contain rounded-xl"
            referrerPolicy="no-referrer"
          />
        </div>

        <div className="space-y-1">
          <h1 className="text-2xl font-bold tracking-tight text-white font-sans">AF Market</h1>
          <p className="text-sm text-amber-400 font-semibold">আপনার নিত্যদিনের বাজার</p>
          <p className="text-[11px] text-blue-200">Smart Business Management System</p>
        </div>

        {/* Loading Progress Bar */}
        <div className="w-48 h-1.5 bg-blue-950 rounded-full overflow-hidden mt-6">
          <div
            className="h-full bg-gradient-to-r from-amber-400 to-amber-500 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-[10px] text-blue-300 font-mono tracking-wider">
          {progress < 100 ? 'INITIALIZING OFFLINE STORAGE...' : 'READY'}
        </p>
      </div>

      {/* Footer */}
      <div className="text-center text-[11px] text-blue-300 space-y-1">
        <p>পাইকারি ও খুচরা ব্যবসায়িক হিসাব সফটওয়্যার</p>
        <p className="text-[9px] text-blue-400">অফলাইন ও অনলাইন সংস্করণ ১.০</p>
      </div>
    </div>
  );
};
