/**
 * AF Market - Fast Point of Sale (POS) System
 * High-speed retail checkout, barcode support, customer dues integration,
 * multiple payment methods (Cash, bKash, Nagad, Rocket, Bank, Credit).
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Product, UnitType, PaymentMethod, Customer } from '../../types';
import { ReceiptModal } from './ReceiptModal';
import {
  Search,
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  CheckCircle2,
  User,
  CreditCard,
  Tag,
  AlertCircle,
  Package,
  Layers,
  ArrowRight,
  UserPlus,
  X,
  Edit3,
  AlertTriangle,
  Sparkles,
} from 'lucide-react';

interface CartItem {
  product: Product;
  quantity: number;
  unitPrice: number; // Negotiated / custom selling rate for this sale
}

export const POSView: React.FC = () => {
  const {
    products,
    categories,
    customers,
    saveCustomer,
    recordSale,
    formatBDT,
    lang,
    t,
    isAdmin,
    currentUser,
    lastCompletedSale,
    setLastCompletedSale,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('walk-in');
  const [discount, setDiscount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CASH');
  const [amountPaidCustom, setAmountPaidCustom] = useState<string>('');
  const [isMobileCartOpen, setIsMobileCartOpen] = useState(false);
  const [showAddCustomerModal, setShowAddCustomerModal] = useState(false);

  // New customer quick form
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustAddress, setNewCustAddress] = useState('');

  // Filtered products
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      if (p.isArchived) return false;
      const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
      const matchesSearch =
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.nameBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (p.barcode && p.barcode.includes(searchQuery));
      return matchesCategory && matchesSearch;
    });
  }, [products, selectedCategory, searchQuery]);

  // Cart operations
  const addToCart = (product: Product, customPrice?: number) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? {
                ...item,
                quantity: item.quantity + 1,
                unitPrice: customPrice !== undefined ? customPrice : item.unitPrice,
              }
            : item
        );
      }
      return [
        ...prev,
        {
          product,
          quantity: 1,
          unitPrice: customPrice !== undefined ? customPrice : product.sellingPrice,
        },
      ];
    });
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => {
      return prev
        .map(item => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const updateUnitPrice = (productId: string, newPrice: number) => {
    setCart(prev =>
      prev.map(item =>
        item.product.id === productId
          ? { ...item, unitPrice: Math.max(0, isNaN(newPrice) ? 0 : newPrice) }
          : item
      )
    );
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
    setDiscount(0);
    setAmountPaidCustom('');
    setSelectedCustomerId('walk-in');
  };

  // Calculations
  const subtotal = useMemo(() => {
    return cart.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);
  }, [cart]);

  const grandTotal = Math.max(0, subtotal - discount);

  // Default paid amount based on method
  const computedPaidAmount = useMemo(() => {
    if (paymentMethod === 'CREDIT') return 0;
    if (amountPaidCustom !== '') {
      const parsed = parseFloat(amountPaidCustom);
      return isNaN(parsed) ? grandTotal : parsed;
    }
    return grandTotal;
  }, [paymentMethod, amountPaidCustom, grandTotal]);

  const dueAmount = Math.max(0, grandTotal - computedPaidAmount);
  const changeAmount = Math.max(0, computedPaidAmount - grandTotal);

  // Selected Customer details
  const selectedCustomer = customers.find(c => c.id === selectedCustomerId);

  // Submit Sale
  const handleCompleteSale = () => {
    if (cart.length === 0) return;

    if (dueAmount > 0 && selectedCustomerId === 'walk-in') {
      alert(
        lang === 'bn'
          ? 'বাকি বিক্রয় করার জন্য অবশ্যই একজন কাস্টমার নির্বাচন করুন!'
          : 'Please select a customer for credit sales with outstanding dues!'
      );
      return;
    }

    const saleItems = cart.map(item => ({
      productId: item.product.id,
      productName: item.product.name,
      productNameBn: item.product.nameBn,
      unit: item.product.unit,
      quantity: item.quantity,
      unitPrice: item.unitPrice,
      purchaseUnitCost: item.product.purchasePrice,
      subtotal: item.unitPrice * item.quantity,
    }));

    const sale = recordSale({
      customerId: selectedCustomerId === 'walk-in' ? undefined : selectedCustomerId,
      customerName:
        selectedCustomerId === 'walk-in'
          ? lang === 'bn'
            ? 'সাধারণ নগদ ক্রেতা'
            : 'Walk-in Customer'
          : selectedCustomer?.name || 'Customer',
      customerPhone: selectedCustomer?.phone,
      items: saleItems,
      subtotal,
      discount,
      finalAmount: grandTotal,
      amountPaid: Math.min(grandTotal, computedPaidAmount),
      dueAmount,
      paymentMethod,
      employeeId: currentUser.id,
      employeeName: currentUser.name,
      deviceId: 'DEVICE-01',
    });

    clearCart();
    setIsMobileCartOpen(false);
  };

  // Create Quick Customer
  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustName.trim()) return;

    const newCust: Customer = {
      id: `cust-${Date.now()}`,
      name: newCustName.trim(),
      phone: newCustPhone.trim() || 'N/A',
      address: newCustAddress.trim(),
      totalPurchases: 0,
      totalPaid: 0,
      remainingDue: 0,
      createdAt: new Date().toISOString(),
    };

    saveCustomer(newCust);
    setSelectedCustomerId(newCust.id);
    setNewCustName('');
    setNewCustPhone('');
    setNewCustAddress('');
    setShowAddCustomerModal(false);
  };

  return (
    <div className="pb-16 lg:pb-4">
      {/* 2-Column POS Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Left Column: Product Catalog & Search (lg:col-span-7 xl:col-span-8) */}
        <div className="lg:col-span-7 xl:col-span-8 space-y-3">
          {/* Flexible Pricing Active Notice Banner */}
          <div className="bg-gradient-to-r from-amber-500/15 via-blue-50/50 to-transparent border border-amber-300/80 rounded-2xl p-2.5 px-3 flex items-center justify-between gap-2 shadow-2xs">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse shrink-0" />
              <p className="text-slate-800 text-[11px] sm:text-xs">
                <strong className="text-amber-900 font-bold">
                  {lang === 'bn' ? 'ফ্লেক্সিবল বিক্রয় দর চালু:' : 'Flexible Selling Price:'}
                </strong>{' '}
                {lang === 'bn'
                  ? 'কোনো পণ্য একদামে বাঁধা নেই! কাস্টমারের সাথে কথা বলে কার্টেই সরাসরি যেকোনো দর বসিয়ে বিক্রি করতে পারবেন।'
                  : 'Products are not locked to a fixed price. Negotiate and change unit prices directly in the cart.'}
              </p>
            </div>
            <span className="hidden sm:inline-flex text-[10px] bg-amber-500/20 text-amber-900 font-bold px-2 py-0.5 rounded-full border border-amber-300">
              {lang === 'bn' ? 'উন্মুক্ত দর' : 'Custom Rates'}
            </span>
          </div>

          {/* Search & Category Filter Bar */}
          <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs space-y-2.5">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder={lang === 'bn' ? 'পণ্যের নাম বা বারকোড দিয়ে খুঁজুন...' : 'Search product or barcode...'}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0B2B50]/20 focus:border-[#0B2B50]"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Category Segmented Scroll */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedCategory === 'all'
                    ? 'bg-[#0B2B50] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {lang === 'bn' ? 'সব পণ্য' : 'All Items'} ({products.length})
              </button>
              {categories.map(cat => {
                const count = products.filter(p => p.category === cat.id).length;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                      selectedCategory === cat.id
                        ? 'bg-[#0B2B50] text-white shadow-xs font-semibold'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {lang === 'bn' ? cat.nameBn : cat.nameEn} ({count})
                  </button>
                );
              })}
            </div>
          </div>

          {/* Product Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-2.5">
            {filteredProducts.map(product => {
              const inCartItem = cart.find(i => i.product.id === product.id);
              const isLowStock = product.currentStock <= product.minStockLevel;
              const isOutOfStock = product.currentStock <= 0;

              return (
                <div
                  key={product.id}
                  onClick={() => !isOutOfStock && addToCart(product)}
                  className={`bg-white p-3 rounded-xl border transition-all text-left flex flex-col justify-between cursor-pointer select-none ${
                    isOutOfStock
                      ? 'opacity-50 border-slate-200 cursor-not-allowed bg-slate-50'
                      : inCartItem
                      ? 'border-blue-500 ring-2 ring-blue-500/10 shadow-xs'
                      : 'border-slate-200 hover:border-blue-300 hover:shadow-xs'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-1 mb-1">
                      <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
                        {product.unit}
                      </span>
                      {isOutOfStock ? (
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-rose-100 text-rose-800">
                          {t.outOfStock}
                        </span>
                      ) : isLowStock ? (
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800">
                          {product.currentStock} {t.lowStock}
                        </span>
                      ) : (
                        <span className="text-[9px] font-medium text-slate-400">
                          {lang === 'bn' ? 'স্টক' : 'Stock'}: {product.currentStock}
                        </span>
                      )}
                    </div>

                    <h4 className="font-bold text-xs sm:text-sm text-slate-900 line-clamp-2 leading-snug">
                      {lang === 'bn' ? product.nameBn : product.name}
                    </h4>
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <span className="text-xs sm:text-sm font-bold text-slate-900 tabular-nums block">
                        {formatBDT(inCartItem ? inCartItem.unitPrice : product.sellingPrice)}
                      </span>
                      <span className="text-[9px] text-emerald-700 font-semibold bg-emerald-50 px-1 py-0.2 rounded inline-block mt-0.5">
                        {inCartItem && inCartItem.unitPrice !== product.sellingPrice
                          ? lang === 'bn'
                            ? `দর বসানো: ৳${inCartItem.unitPrice}`
                            : `Rate set: ৳${inCartItem.unitPrice}`
                          : lang === 'bn'
                          ? 'দর পরিবর্তনযোগ্য'
                          : 'Custom rate'}
                      </span>
                    </div>

                    {inCartItem ? (
                      <span className="w-6 h-6 rounded-full bg-[#0B2B50] text-white flex items-center justify-center text-xs font-bold shadow-xs">
                        {inCartItem.quantity}
                      </span>
                    ) : (
                      <div className="w-6 h-6 rounded-full bg-slate-100 hover:bg-blue-100 text-slate-600 hover:text-blue-700 flex items-center justify-center transition-colors">
                        <Plus className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {filteredProducts.length === 0 && (
            <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center">
              <Package className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-xs text-slate-500">
                {lang === 'bn' ? 'কোনো পণ্য পাওয়া যায়নি' : 'No products matched your search'}
              </p>
            </div>
          )}
        </div>

        {/* Right Column: POS Cart & Checkout Panel (Desktop) */}
        <div className="hidden lg:block lg:col-span-5 xl:col-span-4 bg-white rounded-2xl border border-slate-200 shadow-sm p-4 sticky top-16 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-4 h-4 text-[#0B2B50]" />
              <h3 className="font-bold text-sm text-slate-900">{t.cart}</h3>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-100 text-[#0B2B50]">
                {cart.length}
              </span>
            </div>
            {cart.length > 0 && (
              <button
                onClick={clearCart}
                className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{lang === 'bn' ? 'খালি করুন' : 'Clear'}</span>
              </button>
            )}
          </div>

          {/* Cart Item List */}
          {/* Cart Item List with Negotiable Unit Prices */}
          <div className="max-h-[380px] overflow-y-auto space-y-2.5 pr-1">
            {cart.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs">
                <ShoppingCart className="w-8 h-8 text-slate-300 mx-auto mb-2 opacity-50" />
                {t.emptyCart}
              </div>
            ) : (
              cart.map(item => {
                const isBelowCost = item.unitPrice < item.product.purchasePrice;
                const isPriceAltered = item.unitPrice !== item.product.sellingPrice;

                return (
                  <div
                    key={item.product.id}
                    className={`p-2.5 rounded-xl border text-xs transition-all space-y-2 ${
                      isBelowCost
                        ? 'bg-rose-50/50 border-rose-200 shadow-2xs'
                        : isPriceAltered
                        ? 'bg-amber-50/40 border-amber-200/90 shadow-2xs'
                        : 'bg-slate-50 border-slate-200/80'
                    }`}
                  >
                    {/* Top Row: Item Name, Unit, Quantity Controls & Remove */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-slate-900 leading-tight">
                            {lang === 'bn' ? item.product.nameBn : item.product.name}
                          </span>
                          <span className="text-[10px] text-slate-500 bg-white border border-slate-200 px-1.5 py-0.2 rounded font-medium">
                            {item.product.unit}
                          </span>
                        </div>
                        {isAdmin && (
                          <span className="text-[10px] text-slate-500 block mt-0.5">
                            {lang === 'bn' ? 'কেনা খরচ' : 'Cost'}: ৳{item.product.purchasePrice}
                          </span>
                        )}
                      </div>

                      {/* Quantity Controls */}
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.product.id, -1)}
                          className="w-6 h-6 rounded-md bg-white border border-slate-200 text-slate-700 flex items-center justify-center hover:bg-slate-100 transition-colors"
                          title="কমান"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="font-bold text-xs px-1 font-mono min-w-[20px] text-center">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.product.id, 1)}
                          className="w-6 h-6 rounded-md bg-white border border-slate-200 text-slate-700 flex items-center justify-center hover:bg-slate-100 transition-colors"
                          title="বাড়ান"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          onClick={() => removeFromCart(item.product.id)}
                          className="w-6 h-6 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 flex items-center justify-center ml-0.5 transition-colors"
                          title="বাদ দিন"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Rate Input Row & Item Total */}
                    <div className="bg-white p-2 rounded-lg border border-slate-200 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 flex-1 min-w-0">
                        <label className="text-[11px] font-semibold text-slate-600 whitespace-nowrap flex items-center gap-0.5">
                          <Edit3 className="w-3 h-3 text-amber-600" />
                          <span>{lang === 'bn' ? 'দর:' : 'Rate:'}</span>
                        </label>
                        <div className="relative flex items-center max-w-[95px] w-full">
                          <span className="absolute left-2 text-slate-400 text-xs font-bold pointer-events-none">
                            ৳
                          </span>
                          <input
                            type="number"
                            step="any"
                            min="0"
                            value={item.unitPrice === 0 ? '' : item.unitPrice}
                            onChange={e =>
                              updateUnitPrice(item.product.id, parseFloat(e.target.value) || 0)
                            }
                            className={`w-full pl-5 pr-1 py-1 text-xs font-bold font-mono rounded-md border text-slate-900 bg-white transition-all focus:outline-hidden focus:ring-2 focus:ring-[#0B2B50]/20 ${
                              isBelowCost
                                ? 'border-rose-400 text-rose-700 bg-rose-50/50'
                                : 'border-slate-300 focus:border-[#0B2B50]'
                            }`}
                            placeholder="0"
                          />
                        </div>

                        {/* Reset to Default Base Rate if changed */}
                        {isPriceAltered && (
                          <button
                            type="button"
                            onClick={() => updateUnitPrice(item.product.id, item.product.sellingPrice)}
                            title={
                              lang === 'bn'
                                ? `পূর্বনির্ধারিত দর ৳${item.product.sellingPrice}-এ ফিরে যান`
                                : `Reset to default ৳${item.product.sellingPrice}`
                            }
                            className="text-[10px] text-blue-600 hover:text-blue-800 underline font-medium whitespace-nowrap"
                          >
                            {lang === 'bn' ? 'আসল দর' : 'Reset'}
                          </button>
                        )}
                      </div>

                      {/* Subtotal */}
                      <div className="text-right shrink-0">
                        <span className="text-[10px] text-slate-400 block leading-none">
                          {lang === 'bn' ? 'মোট' : 'Total'}
                        </span>
                        <span className="font-bold text-xs text-[#0B2B50] font-mono tabular-nums leading-tight">
                          {formatBDT(item.unitPrice * item.quantity)}
                        </span>
                      </div>
                    </div>

                    {/* Below Cost Warning */}
                    {isBelowCost && (
                      <div className="flex items-center gap-1 text-[10px] text-rose-700 bg-rose-100/70 px-2 py-0.5 rounded border border-rose-200 font-medium">
                        <AlertTriangle className="w-3 h-3 shrink-0 text-rose-600" />
                        <span>
                          {lang === 'bn'
                            ? `সতর্কতা: কেনা দর (৳${item.product.purchasePrice}) এর চেয়ে কম!`
                            : `Warning: Sold below cost (৳${item.product.purchasePrice})!`}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* Customer Selection */}
          <div className="pt-2 border-t border-slate-100 space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-600 flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-slate-500" />
                {t.customer}
              </label>
              <button
                type="button"
                onClick={() => setShowAddCustomerModal(true)}
                className="text-[11px] text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-0.5"
              >
                <UserPlus className="w-3 h-3" />
                <span>{lang === 'bn' ? '+ নতুন কাস্টমার' : '+ New Customer'}</span>
              </button>
            </div>

            <select
              value={selectedCustomerId}
              onChange={e => setSelectedCustomerId(e.target.value)}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-[#0B2B50]/20"
            >
              <option value="walk-in">
                {lang === 'bn' ? 'সাধারণ নগদ ক্রেতা (Walk-in Customer)' : 'General Walk-in Customer'}
              </option>
              {customers.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name} {c.remainingDue > 0 ? `(বাকি: ৳${c.remainingDue})` : ''} - {c.phone}
                </option>
              ))}
            </select>

            {selectedCustomer && selectedCustomer.remainingDue > 0 && (
              <div className="text-[11px] text-rose-700 bg-rose-50 px-2.5 py-1 rounded-lg border border-rose-200 flex justify-between font-medium">
                <span>{lang === 'bn' ? 'পূর্বের বাকি আছে' : 'Previous Due'}:</span>
                <span className="font-bold tabular-nums">৳{selectedCustomer.remainingDue}</span>
              </div>
            )}
          </div>

          {/* Payment Method Selector */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600">{t.paymentMethod}</label>
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { id: 'CASH', label: t.cash },
                { id: 'BKASH', label: t.bkash },
                { id: 'NAGAD', label: t.nagad },
                { id: 'ROCKET', label: t.rocket },
                { id: 'BANK', label: t.bank },
                { id: 'CREDIT', label: t.credit },
              ].map(method => (
                <button
                  key={method.id}
                  type="button"
                  onClick={() => setPaymentMethod(method.id as PaymentMethod)}
                  className={`py-1.5 px-2 rounded-lg text-[11px] font-semibold border transition-all truncate ${
                    paymentMethod === method.id
                      ? 'bg-[#0B2B50] border-[#0B2B50] text-white shadow-xs'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {method.label}
                </button>
              ))}
            </div>
          </div>

          {/* Billing Calculations Strip */}
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80 space-y-1.5 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>{t.subtotal}:</span>
              <span className="font-bold tabular-nums">{formatBDT(subtotal)}</span>
            </div>

            <div className="flex items-center justify-between text-slate-600">
              <span className="flex items-center gap-1">
                <Tag className="w-3 h-3 text-slate-400" />
                {t.discount}:
              </span>
              <input
                type="number"
                min="0"
                value={discount || ''}
                onChange={e => setDiscount(Math.max(0, parseFloat(e.target.value) || 0))}
                placeholder="৳ 0"
                className="w-20 p-1 text-right bg-white border border-slate-200 rounded text-xs font-bold focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div className="flex justify-between text-sm font-bold text-slate-900 pt-1 border-t border-slate-200">
              <span>{t.grandTotal}:</span>
              <span className="text-[#0B2B50] tabular-nums font-mono text-base">{formatBDT(grandTotal)}</span>
            </div>

            {/* Paid Amount Input */}
            <div className="flex items-center justify-between pt-1">
              <span className="font-medium text-slate-700">{t.paidAmount}:</span>
              <input
                type="number"
                min="0"
                value={amountPaidCustom}
                onChange={e => setAmountPaidCustom(e.target.value)}
                placeholder={grandTotal.toString()}
                className="w-24 p-1 text-right bg-white border border-slate-200 rounded text-xs font-bold tabular-nums focus:ring-1 focus:ring-blue-500"
              />
            </div>

            {dueAmount > 0 && (
              <div className="flex justify-between font-bold text-rose-600 bg-rose-50 p-1.5 rounded border border-rose-200">
                <span>{t.dueAmount}:</span>
                <span className="tabular-nums">৳{dueAmount}</span>
              </div>
            )}

            {changeAmount > 0 && (
              <div className="flex justify-between font-bold text-emerald-700 bg-emerald-50 p-1.5 rounded border border-emerald-200">
                <span>{t.changeAmount}:</span>
                <span className="tabular-nums">৳{changeAmount}</span>
              </div>
            )}
          </div>

          {/* Checkout Button */}
          <button
            onClick={handleCompleteSale}
            disabled={cart.length === 0}
            className="w-full py-3 rounded-xl bg-[#0B2B50] hover:bg-[#071f3b] text-white text-sm font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-md flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{t.checkout}</span>
          </button>
        </div>
      </div>

      {/* Sticky Mobile Cart Bar (When on small phone screens) */}
      <div className="lg:hidden fixed bottom-14 left-0 right-0 z-20 bg-[#0B2B50] text-white px-4 py-2.5 shadow-lg flex items-center justify-between">
        <div onClick={() => setIsMobileCartOpen(true)} className="flex items-center gap-2.5 cursor-pointer">
          <div className="relative">
            <ShoppingCart className="w-5 h-5 text-amber-400" />
            {cart.length > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-rose-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {cart.length}
              </span>
            )}
          </div>
          <div>
            <p className="text-xs font-bold leading-tight">{formatBDT(grandTotal)}</p>
            <p className="text-[10px] text-blue-200 leading-none">
              {cart.reduce((a, b) => a + b.quantity, 0)} {lang === 'bn' ? 'পণ্য' : 'items'}
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsMobileCartOpen(true)}
          className="px-4 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1 shadow-sm"
        >
          <span>{lang === 'bn' ? 'কার্ট ও বিল' : 'View Cart'}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Mobile Cart Full Modal Drawer */}
      {isMobileCartOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex flex-col justify-end">
          <div className="bg-white rounded-t-2xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="p-4 bg-[#0B2B50] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm">{t.cart} ({cart.length})</h3>
              </div>
              <button onClick={() => setIsMobileCartOpen(false)} className="text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-4 flex-1">
              {/* Item List with Flexible Unit Prices (Mobile) */}
              <div className="space-y-2.5">
                {cart.map(item => {
                  const isBelowCost = item.unitPrice < item.product.purchasePrice;
                  const isPriceAltered = item.unitPrice !== item.product.sellingPrice;

                  return (
                    <div
                      key={item.product.id}
                      className={`p-3 rounded-xl border text-xs space-y-2 ${
                        isBelowCost
                          ? 'bg-rose-50/60 border-rose-200'
                          : isPriceAltered
                          ? 'bg-amber-50/50 border-amber-200'
                          : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="font-bold text-slate-900 leading-snug">
                            {lang === 'bn' ? item.product.nameBn : item.product.name}
                          </p>
                          <span className="text-[10px] text-slate-500 font-medium">
                            {item.product.unit} {isAdmin && `· কেনা: ৳${item.product.purchasePrice}`}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.product.id, -1)}
                            className="w-7 h-7 rounded-lg bg-white border border-slate-200 text-slate-700 flex items-center justify-center font-bold text-sm"
                          >
                            -
                          </button>
                          <span className="font-bold text-xs px-1 min-w-[18px] text-center">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.product.id, 1)}
                            className="w-7 h-7 rounded-lg bg-white border border-slate-200 text-slate-700 flex items-center justify-center font-bold text-sm"
                          >
                            +
                          </button>
                          <button
                            type="button"
                            onClick={() => removeFromCart(item.product.id)}
                            className="w-7 h-7 rounded-lg text-slate-400 hover:text-rose-600 flex items-center justify-center ml-1"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Unit Price Input */}
                      <div className="bg-white p-2 rounded-lg border border-slate-200 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 flex-1">
                          <span className="text-[11px] font-semibold text-slate-600 whitespace-nowrap">
                            {lang === 'bn' ? 'দর:' : 'Rate:'}
                          </span>
                          <div className="relative flex items-center max-w-[100px] w-full">
                            <span className="absolute left-2 text-slate-400 text-xs font-bold pointer-events-none">
                              ৳
                            </span>
                            <input
                              type="number"
                              step="any"
                              min="0"
                              value={item.unitPrice === 0 ? '' : item.unitPrice}
                              onChange={e =>
                                updateUnitPrice(item.product.id, parseFloat(e.target.value) || 0)
                              }
                              className="w-full pl-5 pr-1 py-1 text-xs font-bold font-mono rounded-md border border-slate-300 text-slate-900 bg-white"
                              placeholder="0"
                            />
                          </div>
                          {isPriceAltered && (
                            <button
                              type="button"
                              onClick={() => updateUnitPrice(item.product.id, item.product.sellingPrice)}
                              className="text-[10px] text-blue-600 underline font-medium"
                            >
                              {lang === 'bn' ? 'আসল দর' : 'Reset'}
                            </button>
                          )}
                        </div>
                        <div className="text-right shrink-0">
                          <span className="text-xs font-bold text-[#0B2B50] font-mono tabular-nums">
                            {formatBDT(item.unitPrice * item.quantity)}
                          </span>
                        </div>
                      </div>

                      {isBelowCost && (
                        <p className="text-[10px] text-rose-700 font-medium">
                          ⚠️ কেনা দর (৳{item.product.purchasePrice}) এর চেয়ে কম দর বসিয়েছেন!
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Customer */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700">{t.customer}</label>
                <select
                  value={selectedCustomerId}
                  onChange={e => setSelectedCustomerId(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                >
                  <option value="walk-in">{lang === 'bn' ? 'সাধারণ নগদ ক্রেতা' : 'Walk-in Customer'}</option>
                  {customers.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} {c.remainingDue > 0 ? `(বাকি: ৳${c.remainingDue})` : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* Payment Method */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700">{t.paymentMethod}</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { id: 'CASH', label: t.cash },
                    { id: 'BKASH', label: t.bkash },
                    { id: 'NAGAD', label: t.nagad },
                    { id: 'ROCKET', label: t.rocket },
                    { id: 'BANK', label: t.bank },
                    { id: 'CREDIT', label: t.credit },
                  ].map(method => (
                    <button
                      key={method.id}
                      type="button"
                      onClick={() => setPaymentMethod(method.id as PaymentMethod)}
                      className={`py-1.5 rounded-lg text-xs font-semibold border ${
                        paymentMethod === method.id ? 'bg-[#0B2B50] text-white' : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {method.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Totals & Paid */}
              <div className="bg-slate-100 p-3 rounded-xl space-y-2 text-xs">
                <div className="flex justify-between font-bold text-sm">
                  <span>{t.grandTotal}:</span>
                  <span className="text-[#0B2B50] font-mono">{formatBDT(grandTotal)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>{t.paidAmount}:</span>
                  <input
                    type="number"
                    value={amountPaidCustom}
                    onChange={e => setAmountPaidCustom(e.target.value)}
                    placeholder={grandTotal.toString()}
                    className="w-24 p-1.5 text-right bg-white rounded border border-slate-300 font-bold"
                  />
                </div>
                {dueAmount > 0 && (
                  <div className="flex justify-between text-rose-600 font-bold">
                    <span>{t.dueAmount}:</span>
                    <span>৳{dueAmount}</span>
                  </div>
                )}
              </div>

              <button
                onClick={handleCompleteSale}
                className="w-full py-3 rounded-xl bg-[#0B2B50] text-white font-bold text-sm shadow-md"
              >
                {t.checkout}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quick Add Customer Modal */}
      {showAddCustomerModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-4 space-y-3">
            <div className="flex justify-between items-center pb-2 border-b">
              <h4 className="font-bold text-sm">{lang === 'bn' ? 'নতুন কাস্টমার যোগ করুন' : 'Add New Customer'}</h4>
              <button onClick={() => setShowAddCustomerModal(false)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleCreateCustomer} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold block mb-1">{lang === 'bn' ? 'কাস্টমারের নাম' : 'Customer Name'} *</label>
                <input
                  type="text"
                  required
                  value={newCustName}
                  onChange={e => setNewCustName(e.target.value)}
                  placeholder="যেমন: মো. রফিকুল ইসলাম"
                  className="w-full p-2 border rounded-xl"
                />
              </div>
              <div>
                <label className="font-semibold block mb-1">{lang === 'bn' ? 'মোবাইল নম্বর' : 'Phone Number'}</label>
                <input
                  type="text"
                  value={newCustPhone}
                  onChange={e => setNewCustPhone(e.target.value)}
                  placeholder="017xxxxxxxx"
                  className="w-full p-2 border rounded-xl"
                />
              </div>
              <div>
                <label className="font-semibold block mb-1">{lang === 'bn' ? 'ঠিকানা / দোকান' : 'Address'}</label>
                <input
                  type="text"
                  value={newCustAddress}
                  onChange={e => setNewCustAddress(e.target.value)}
                  placeholder="বাজার মোড়"
                  className="w-full p-2 border rounded-xl"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-[#0B2B50] text-white font-bold"
              >
                {t.save}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Thermal Receipt Modal Trigger */}
      {lastCompletedSale && (
        <ReceiptModal sale={lastCompletedSale} onClose={() => setLastCompletedSale(null)} />
      )}
    </div>
  );
};
