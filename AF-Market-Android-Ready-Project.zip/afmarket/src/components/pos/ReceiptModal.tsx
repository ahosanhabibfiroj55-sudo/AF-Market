/**
 * AF Market - POS Thermal Receipt Modal
 * Designed for 80mm/58mm POS receipt printers, PDF export, and WhatsApp sharing.
 */

import React from 'react';
import { Sale } from '../../types';
import { useApp } from '../../context/AppContext';
import { X, Printer, Share2, Check, Download } from 'lucide-react';

interface ReceiptModalProps {
  sale: Sale | null;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ sale, onClose }) => {
  const { lang, formatBDT, t } = useApp();

  if (!sale) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleShareWhatsApp = () => {
    const text = `*AF Market — বিক্রয় মেমো*\nইনভয়েস: ${sale.invoiceNumber}\nতারিখ: ${new Date(sale.createdAt).toLocaleString()}\nক্রেতা: ${sale.customerName}\nমোট বিল: ৳${sale.finalAmount}\nজমা: ৳${sale.amountPaid}\nবাকি: ৳${sale.dueAmount}\n\nধন্যবাদ, আবার আসবেন!`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto no-print">
      <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Top Action Bar */}
        <div className="bg-[#0B2B50] p-3.5 text-white flex items-center justify-between">
          <span className="font-bold text-xs sm:text-sm">
            {lang === 'bn' ? 'বিক্রয় রসিদ / ক্যাশ মেমো' : 'Sales Cash Memo'}
          </span>
          <div className="flex items-center gap-1">
            <button
              onClick={handlePrint}
              className="p-1.5 rounded-lg bg-blue-900/80 hover:bg-blue-800 text-white transition-colors"
              title="Print Receipt"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={handleShareWhatsApp}
              className="p-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors"
              title="Share Receipt"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-blue-200 hover:text-white hover:bg-blue-900 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Paper Container */}
        <div id="printable-receipt" className="p-4 bg-white text-slate-900 font-mono text-xs select-text">
          {/* Header with Official Logo */}
          <div className="text-center pb-3 border-b border-dashed border-slate-300">
            <div className="flex justify-center mb-1.5">
              <img
                src="/logo.jpg"
                alt="AF Market"
                className="h-10 w-auto object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <h2 className="text-sm font-bold tracking-tight text-slate-950 font-sans">AF Market</h2>
            <p className="text-[10px] text-slate-600 font-sans">
              {lang === 'bn' ? 'আপনার নিত্যদিনের বাজার' : 'Smart Wholesale & Retail Sales'}
            </p>
            <p className="text-[9px] text-slate-500 font-sans mt-0.5">
              বাজার মোড়, মেইন রোড · মোবাইল: ০১৭১২-৩৪৫৬৭৮
            </p>
          </div>

          {/* Meta Info */}
          <div className="py-2.5 text-[11px] border-b border-dashed border-slate-300 space-y-0.5 font-sans">
            <div className="flex justify-between">
              <span className="text-slate-500">{lang === 'bn' ? 'মেমো নং' : 'Memo No'}:</span>
              <span className="font-bold">{sale.invoiceNumber}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">{lang === 'bn' ? 'তারিখ' : 'Date'}:</span>
              <span>{new Date(sale.createdAt).toLocaleDateString()} {new Date(sale.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">{lang === 'bn' ? 'ক্রেতা' : 'Customer'}:</span>
              <span className="font-bold truncate max-w-[170px]">{sale.customerName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">{lang === 'bn' ? 'ক্যাশিয়ার' : 'Cashier'}:</span>
              <span>{sale.employeeName}</span>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="py-2.5 border-b border-dashed border-slate-300 font-sans">
            <table className="w-full text-[11px]">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="text-left pb-1">{lang === 'bn' ? 'পণ্য' : 'Item'}</th>
                  <th className="text-center pb-1">{lang === 'bn' ? 'পরিমাণ' : 'Qty'}</th>
                  <th className="text-right pb-1">{lang === 'bn' ? 'দর' : 'Rate'}</th>
                  <th className="text-right pb-1">{lang === 'bn' ? 'মোট' : 'Total'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sale.items.map((item, idx) => (
                  <tr key={idx} className="py-1">
                    <td className="py-1 text-slate-800 leading-tight">
                      {lang === 'bn' ? item.productNameBn : item.productName}
                    </td>
                    <td className="py-1 text-center font-mono">
                      {item.quantity} {item.unit}
                    </td>
                    <td className="py-1 text-right tabular-nums">৳{item.unitPrice}</td>
                    <td className="py-1 text-right font-bold tabular-nums">৳{item.subtotal}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div className="py-2.5 space-y-1 text-xs font-sans">
            <div className="flex justify-between text-slate-600">
              <span>{lang === 'bn' ? 'উপমোট' : 'Subtotal'}:</span>
              <span className="tabular-nums font-mono">৳{sale.subtotal}</span>
            </div>
            {sale.discount > 0 && (
              <div className="flex justify-between text-emerald-600">
                <span>{lang === 'bn' ? 'বিশেষ ছাড়' : 'Discount'}:</span>
                <span className="tabular-nums font-mono">-৳{sale.discount}</span>
              </div>
            )}
            <div className="flex justify-between font-bold text-sm text-slate-900 pt-1 border-t border-slate-200">
              <span>{lang === 'bn' ? 'সর্বমোট প্রদেয়' : 'Grand Total'}:</span>
              <span className="tabular-nums font-mono text-[#0B2B50]">৳{sale.finalAmount}</span>
            </div>
            <div className="flex justify-between text-slate-700 pt-0.5">
              <span>
                {lang === 'bn' ? 'পরিশোধিত' : 'Paid'} ({sale.paymentMethod}):
              </span>
              <span className="tabular-nums font-mono font-bold text-emerald-700">৳{sale.amountPaid}</span>
            </div>
            {sale.dueAmount > 0 && (
              <div className="flex justify-between text-rose-600 font-bold bg-rose-50 px-1.5 py-0.5 rounded">
                <span>{lang === 'bn' ? 'অবশিষ্ট বাকি' : 'Remaining Due'}:</span>
                <span className="tabular-nums font-mono">৳{sale.dueAmount}</span>
              </div>
            )}
            {sale.amountPaid > sale.finalAmount && (
              <div className="flex justify-between text-blue-700">
                <span>{lang === 'bn' ? 'ফেরত টাকা' : 'Change'}:</span>
                <span className="tabular-nums font-mono">৳{sale.amountPaid - sale.finalAmount}</span>
              </div>
            )}
          </div>

          {/* Footer Note & Barcode simulator */}
          <div className="text-center pt-3 border-t border-dashed border-slate-300 font-sans">
            <p className="text-[11px] font-bold text-slate-800">
              {lang === 'bn' ? 'আমাদের সাথে কেনাকাটা করার জন্য ধন্যবাদ!' : 'Thank you for shopping with us!'}
            </p>
            <p className="text-[9px] text-slate-500 mt-0.5">
              {lang === 'bn' ? 'বিকাশ ও নগদ পেমেন্ট গ্রহণযোগ্য' : 'bKash & Nagad Payments Accepted'}
            </p>
            <div className="mt-2 text-[9px] tracking-widest text-slate-400 font-mono uppercase">
              *{sale.invoiceNumber}*
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex gap-2">
          <button
            onClick={handlePrint}
            className="flex-1 py-2 rounded-xl bg-[#0B2B50] hover:bg-[#071f3b] text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>{lang === 'bn' ? 'রসিদ প্রিন্ট' : 'Print Receipt'}</span>
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-semibold transition-colors"
          >
            {lang === 'bn' ? 'সম্পন্ন' : 'Done'}
          </button>
        </div>
      </div>
    </div>
  );
};
