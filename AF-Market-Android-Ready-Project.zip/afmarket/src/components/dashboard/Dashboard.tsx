/**
 * AF Market - Main Business Dashboard
 * Real-time calculated KPIs, financial overview, low-stock warnings,
 * sales breakdown, and fast action launchers.
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  TrendingUp,
  ShoppingBag,
  DollarSign,
  Receipt,
  BookOpen,
  Building2,
  Package,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  PlusCircle,
  ShoppingCart,
  Truck,
  Wallet,
  Clock,
  ChevronRight,
  Sparkles,
  Smartphone,
  QrCode,
} from 'lucide-react';

export const Dashboard: React.FC = () => {
  const {
    t,
    lang,
    formatBDT,
    setActiveTab,
    sales,
    purchases,
    expenses,
    customers,
    suppliers,
    products,
    cashSession,
    isAdmin,
    currentUser,
    setIsMobileSetupOpen,
  } = useApp();

  const todayStr = new Date().toISOString().split('T')[0];

  // Today's Sales
  const todaySalesList = sales.filter(s => s.createdAt.startsWith(todayStr));
  const todayTotalSales = todaySalesList.reduce((acc, s) => acc + s.finalAmount, 0);
  const todayCOGS = todaySalesList.reduce((acc, s) => acc + s.costOfGoodsSold, 0);
  const todayGrossProfit = todayTotalSales - todayCOGS;

  // Today's Expenses
  const todayExpensesList = expenses.filter(e => e.date === todayStr);
  const todayTotalExpenses = todayExpensesList.reduce((acc, e) => acc + e.amount, 0);
  const todayNetProfit = todayGrossProfit - todayTotalExpenses;

  // Today's Cash Received (Cash sales + Due collections)
  const todayCashIn = cashSession.cashSales + cashSession.customerDueCollections;

  // Balances
  const totalCustomerDue = customers.reduce((acc, c) => acc + c.remainingDue, 0);
  const totalSupplierPayable = suppliers.reduce((acc, s) => acc + s.remainingPayable, 0);
  const totalInventoryValue = products.reduce((acc, p) => acc + Math.max(0, p.currentStock) * p.purchasePrice, 0);

  // Low stock products
  const lowStockProducts = products.filter(p => p.currentStock <= p.minStockLevel);

  // Recent 5 sales
  const recentSales = sales.slice(0, 5);

  return (
    <div className="space-y-5 pb-8">
      {/* Top Welcome Bar & Action Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gradient-to-r from-[#0B2B50] to-[#123E72] p-4 sm:p-5 rounded-2xl text-white shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg sm:text-xl font-bold tracking-tight">
              {lang === 'bn' ? `আস-সালামু আলাইকুম, ${currentUser.name}` : `Welcome back, ${currentUser.name}`}
            </h1>
            <span className="text-[10px] font-semibold bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full">
              {isAdmin ? (lang === 'bn' ? 'মালিক' : 'Admin') : (lang === 'bn' ? 'স্টাফ' : 'Staff')}
            </span>
          </div>
          <p className="text-xs text-blue-200 mt-1">
            {new Date().toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric',
            })}
            {' · '}
            <span className="text-amber-300">
              {lang === 'bn' ? 'পাইকারি ক্রয় ও খুচরা বিক্রয় শাখা' : 'Wholesale & Retail Branch'}
            </span>
          </p>
        </div>

        {/* Primary Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('pos')}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition-transform active:scale-95"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>{lang === 'bn' ? 'নতুন বিক্রয় (POS)' : 'New Sale (POS)'}</span>
          </button>
          {isAdmin && (
            <button
              onClick={() => setActiveTab('purchases')}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-medium text-xs border border-white/20 transition-colors"
            >
              <Truck className="w-4 h-4 text-amber-300" />
              <span>{lang === 'bn' ? 'পাইকারি চালান' : 'Wholesale'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Mobile Phone Quick Setup Banner */}
      <div className="bg-gradient-to-r from-blue-900/90 via-[#0B2B50] to-indigo-900 rounded-2xl p-3.5 sm:p-4 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm border border-blue-800/60">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold shrink-0">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-bold flex items-center gap-2">
              <span>
                {lang === 'bn'
                  ? 'দোকানের কর্মচারীদের ফোনে বা নিজের মোবাইলে চালান'
                  : 'Run AF Market on Mobile Phone'}
              </span>
              <span className="text-[10px] bg-emerald-500 text-slate-950 px-1.5 py-0.5 rounded-full font-bold">
                PWA Offline
              </span>
            </h4>
            <p className="text-[11px] text-blue-200 mt-0.5">
              {lang === 'bn'
                ? 'ফোনের ক্যামেরা দিয়ে QR কোড স্ক্যান করে সরাসরি হোম স্ক্রিনে অ্যাপ আকারে ইন্সটল করে নিন।'
                : 'Scan QR code with phone camera to install directly on your home screen.'}
            </p>
          </div>
        </div>
        <button
          onClick={() => setIsMobileSetupOpen(true)}
          className="flex items-center justify-center gap-2 px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold transition-all shadow-sm shrink-0 active:scale-95"
        >
          <QrCode className="w-4 h-4" />
          <span>{lang === 'bn' ? 'QR কোড ও নির্দেশিকা' : 'Mobile Setup'}</span>
        </button>
      </div>

      {/* Low Stock Alert Banner (If Any) */}
      {lowStockProducts.length > 0 && (
        <div className="bg-amber-50 border border-amber-300 rounded-xl p-3 sm:p-4 flex items-start sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-100 text-amber-700 shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-amber-900">
                {lang === 'bn'
                  ? `${lowStockProducts.length}টি পণ্যের স্টক সংকট! অবিলম্বে অর্ডার প্রয়োজন`
                  : `Low Stock Alert: ${lowStockProducts.length} items below minimum level`}
              </h4>
              <p className="text-[11px] text-amber-800 line-clamp-1">
                {lowStockProducts.map(p => (lang === 'bn' ? p.nameBn : p.name)).join(', ')}
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('products')}
            className="shrink-0 text-xs font-bold text-amber-900 hover:text-amber-950 underline px-2 py-1"
          >
            {lang === 'bn' ? 'স্টক দেখুন' : 'View Stock'}
          </button>
        </div>
      )}

      {/* Main KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Today's Sales */}
        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">{t.todaySales}</span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-700">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-bold text-slate-900 tabular-nums">
            {formatBDT(todayTotalSales)}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {todaySalesList.length} {lang === 'bn' ? 'টি মেমো কাটা হয়েছে' : 'invoices today'}
          </p>
        </div>

        {/* Today's Gross Profit (Owner Only) */}
        {isAdmin ? (
          <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-slate-500">{t.todayGrossProfit}</span>
              <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="text-lg sm:text-xl font-bold text-emerald-700 tabular-nums">
              {formatBDT(todayGrossProfit)}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              COGS: <span className="tabular-nums font-medium">{formatBDT(todayCOGS)}</span>
            </p>
          </div>
        ) : (
          <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-slate-500">
                {lang === 'bn' ? 'আমার আজকের বিক্রয়' : 'My Sales Today'}
              </span>
              <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
                <ShoppingBag className="w-4 h-4" />
              </div>
            </div>
            <div className="text-lg sm:text-xl font-bold text-emerald-700 tabular-nums">
              {formatBDT(todayTotalSales)}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              {lang === 'bn' ? 'আপনার লগইন আইডি থেকে' : 'From your shift'}
            </p>
          </div>
        )}

        {/* Today's Net Profit (Owner Only) */}
        {isAdmin ? (
          <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-slate-500">{t.todayNetProfit}</span>
              <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700">
                <DollarSign className="w-4 h-4" />
              </div>
            </div>
            <div
              className={`text-lg sm:text-xl font-bold tabular-nums ${
                todayNetProfit >= 0 ? 'text-indigo-700' : 'text-rose-600'
              }`}
            >
              {formatBDT(todayNetProfit)}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              {lang === 'bn' ? 'খরচ বাদ দিয়ে লাভ' : 'Profit after expenses'}
            </p>
          </div>
        ) : (
          <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-slate-500">
                {lang === 'bn' ? 'আজকের নগদ লেনদেন' : 'Cash Collected'}
              </span>
              <div className="p-2 rounded-lg bg-amber-50 text-amber-700">
                <Wallet className="w-4 h-4" />
              </div>
            </div>
            <div className="text-lg sm:text-xl font-bold text-slate-900 tabular-nums">
              {formatBDT(todayCashIn)}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              {lang === 'bn' ? 'ক্যাশ ড্রয়ারে জমা' : 'In drawer'}
            </p>
          </div>
        )}

        {/* Today's Cash Received */}
        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">{t.todayCashIn}</span>
            <div className="p-2 rounded-lg bg-amber-50 text-amber-700">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-bold text-amber-600 tabular-nums">
            {formatBDT(todayCashIn)}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {lang === 'bn' ? 'বিক্রয় ও বাকি আদায়' : 'Sales & Collections'}
          </p>
        </div>
      </div>

      {/* Secondary Financial KPI Strip (Customer Due, Supplier Payable, Stock Value, Cash Drawer) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Total Customer Due (বাকি খাতা) */}
        <div
          onClick={() => setActiveTab('customers')}
          className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs hover:border-blue-400 cursor-pointer transition-all"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium">{t.totalCustomerDue}</span>
            <BookOpen className="w-3.5 h-3.5 text-rose-500" />
          </div>
          <div className="text-base sm:text-lg font-bold text-rose-600 tabular-nums">
            {formatBDT(totalCustomerDue)}
          </div>
          <div className="text-[11px] text-blue-600 font-medium flex items-center gap-1 mt-1">
            <span>{lang === 'bn' ? 'বাকি আদায় করুন' : 'Collect Dues'}</span>
            <ChevronRight className="w-3 h-3" />
          </div>
        </div>

        {/* Supplier Payable (মহাজন পাওনা) */}
        <div
          onClick={() => isAdmin && setActiveTab('suppliers')}
          className={`bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs transition-all ${
            isAdmin ? 'hover:border-blue-400 cursor-pointer' : ''
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium">{t.totalSupplierPayable}</span>
            <Building2 className="w-3.5 h-3.5 text-orange-500" />
          </div>
          <div className="text-base sm:text-lg font-bold text-orange-600 tabular-nums">
            {isAdmin ? formatBDT(totalSupplierPayable) : '••••••'}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {suppliers.filter(s => s.remainingPayable > 0).length} {lang === 'bn' ? 'মহাজনের পাওনা' : 'suppliers pending'}
          </p>
        </div>

        {/* Total Inventory Asset Value */}
        <div
          onClick={() => setActiveTab('products')}
          className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs hover:border-blue-400 cursor-pointer transition-all"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium">{t.totalStockValue}</span>
            <Package className="w-3.5 h-3.5 text-blue-500" />
          </div>
          <div className="text-base sm:text-lg font-bold text-slate-900 tabular-nums">
            {isAdmin ? formatBDT(totalInventoryValue) : `${products.length} Items`}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {products.length} {lang === 'bn' ? 'টি আইটেম স্টকে আছে' : 'total items in stock'}
          </p>
        </div>

        {/* Daily Cash Drawer Status */}
        <div
          onClick={() => isAdmin && setActiveTab('daily-cash')}
          className={`bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs transition-all ${
            isAdmin ? 'hover:border-blue-400 cursor-pointer' : ''
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium">{t.dailyCashTitle}</span>
            <Wallet className="w-3.5 h-3.5 text-emerald-500" />
          </div>
          <div className="text-base sm:text-lg font-bold text-emerald-700 tabular-nums">
            {formatBDT(cashSession.expectedClosingCash)}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {cashSession.status === 'OPEN'
              ? lang === 'bn'
                ? 'ড্রয়ার খোলা আছে'
                : 'Drawer Open'
              : lang === 'bn'
              ? 'ড্রয়ার ক্লোজড'
              : 'Drawer Closed'}
          </p>
        </div>
      </div>

      {/* Quick Action Cards Bar */}
      <div className="bg-slate-100/70 p-3 rounded-2xl border border-slate-200/80">
        <div className="text-xs font-bold text-slate-700 mb-2 px-1">
          {lang === 'bn' ? 'দ্রুত শর্টকাট একশন' : 'Quick Actions'}
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          <button
            onClick={() => setActiveTab('pos')}
            className="flex items-center gap-2 p-2.5 rounded-xl bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 text-slate-800 transition-all text-left shadow-2xs"
          >
            <div className="p-1.5 rounded-lg bg-blue-100 text-[#0B2B50]">
              <ShoppingCart className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold leading-tight">{lang === 'bn' ? 'বিক্রয় (POS)' : 'Sale POS'}</p>
              <p className="text-[10px] text-slate-500 leading-none">{lang === 'bn' ? 'দ্রুত মেমো' : 'Fast billing'}</p>
            </div>
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className="flex items-center gap-2 p-2.5 rounded-xl bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 text-slate-800 transition-all text-left shadow-2xs"
          >
            <div className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold leading-tight">{lang === 'bn' ? 'বাকি আদায়' : 'Due Collect'}</p>
              <p className="text-[10px] text-slate-500 leading-none">{lang === 'bn' ? 'খাতা আপডেট' : 'Update due'}</p>
            </div>
          </button>

          {isAdmin && (
            <button
              onClick={() => setActiveTab('purchases')}
              className="flex items-center gap-2 p-2.5 rounded-xl bg-white hover:bg-amber-50 border border-slate-200 hover:border-amber-300 text-slate-800 transition-all text-left shadow-2xs"
            >
              <div className="p-1.5 rounded-lg bg-amber-100 text-amber-800">
                <Truck className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold leading-tight">{lang === 'bn' ? 'পাইকারি ক্রয়' : 'Purchase'}</p>
                <p className="text-[10px] text-slate-500 leading-none">{lang === 'bn' ? 'চালান এন্ট্রি' : 'Stock in'}</p>
              </div>
            </button>
          )}

          <button
            onClick={() => setActiveTab('expenses')}
            className="flex items-center gap-2 p-2.5 rounded-xl bg-white hover:bg-rose-50 border border-slate-200 hover:border-rose-300 text-slate-800 transition-all text-left shadow-2xs"
          >
            <div className="p-1.5 rounded-lg bg-rose-100 text-rose-800">
              <Receipt className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold leading-tight">{lang === 'bn' ? 'দোকান খরচ' : 'Expense'}</p>
              <p className="text-[10px] text-slate-500 leading-none">{lang === 'bn' ? 'ভাড়া, বিদ্যুৎ' : 'Bills & rent'}</p>
            </div>
          </button>

          {isAdmin && (
            <button
              onClick={() => setActiveTab('daily-cash')}
              className="flex items-center gap-2 p-2.5 rounded-xl bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-slate-800 transition-all text-left shadow-2xs"
            >
              <div className="p-1.5 rounded-lg bg-indigo-100 text-indigo-800">
                <Wallet className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold leading-tight">{lang === 'bn' ? 'ক্যাশ মিলানো' : 'Reconcile'}</p>
                <p className="text-[10px] text-slate-500 leading-none">{lang === 'bn' ? 'দিনের হিসাব' : 'Cash check'}</p>
              </div>
            </button>
          )}
        </div>
      </div>

      {/* Two Column Section: Recent Sales & Top Products / Inventory Status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recent Sales List */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-500" />
              {lang === 'bn' ? 'সাম্প্রতিক বিক্রয় লেনদেন' : 'Recent Sales'}
            </h3>
            <button
              onClick={() => setActiveTab('reports')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800"
            >
              {lang === 'bn' ? 'সব দেখুন' : 'View All'}
            </button>
          </div>

          {recentSales.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs">
              {lang === 'bn' ? 'এখনো কোনো বিক্রয় রেকর্ড হয়নি' : 'No sales recorded yet'}
            </div>
          ) : (
            <div className="space-y-2">
              {recentSales.map(sale => (
                <div
                  key={sale.id}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 hover:bg-blue-50/50 transition-colors border border-slate-100 text-xs"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">{sale.invoiceNumber}</span>
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-200 text-slate-700">
                        {sale.paymentMethod}
                      </span>
                    </div>
                    <p className="text-slate-500 text-[11px] truncate mt-0.5">
                      {sale.customerName} · {sale.items.length} {lang === 'bn' ? 'পণ্য' : 'items'}
                    </p>
                  </div>

                  <div className="text-right shrink-0">
                    <p className="font-bold text-slate-900 tabular-nums">{formatBDT(sale.finalAmount)}</p>
                    {sale.dueAmount > 0 && (
                      <p className="text-[10px] text-rose-600 font-semibold tabular-nums">
                        {lang === 'bn' ? 'বাকি' : 'Due'}: {formatBDT(sale.dueAmount)}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Low Stock & Inventory Overview */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <Package className="w-4 h-4 text-slate-500" />
              {lang === 'bn' ? 'স্টক সংকট ও সতর্কতা' : 'Stock Alerts & Inventory'}
            </h3>
            <button
              onClick={() => setActiveTab('products')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800"
            >
              {lang === 'bn' ? 'পণ্য তালিকা' : 'Products'}
            </button>
          </div>

          {lowStockProducts.length === 0 ? (
            <div className="py-8 text-center text-emerald-600 text-xs font-medium bg-emerald-50/50 rounded-xl border border-emerald-100">
              ✓ {lang === 'bn' ? 'আলহামদুলিল্লাহ! সব পণ্যের পর্যাপ্ত স্টক রয়েছে' : 'All products have sufficient stock!'}
            </div>
          ) : (
            <div className="space-y-2">
              {lowStockProducts.map(prod => (
                <div
                  key={prod.id}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-amber-50/60 border border-amber-200/80 text-xs"
                >
                  <div>
                    <p className="font-bold text-slate-900">{lang === 'bn' ? prod.nameBn : prod.name}</p>
                    <p className="text-[11px] text-amber-800">
                      {lang === 'bn' ? 'সর্বনিম্ন মাত্রা' : 'Min alert'}: {prod.minStockLevel} {prod.unit}
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="inline-block px-2 py-0.5 rounded text-[11px] font-bold bg-amber-200 text-amber-900 tabular-nums">
                      {lang === 'bn' ? 'বাকি আছে' : 'Remaining'}: {prod.currentStock} {prod.unit}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
