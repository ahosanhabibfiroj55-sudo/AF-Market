/**
 * AF Market - App Context
 * State management for inventory, sales, dues, expenses, user role,
 * offline/online mode, and UI localization.
 */

import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import {
  Product,
  ProductCategory,
  Customer,
  Supplier,
  Sale,
  Purchase,
  Expense,
  DailyCashSession,
  Employee,
  AuditLog,
  SyncMetadata,
  PaymentMethod,
} from '../types';
import { AFMarketStorage } from '../db/storage';
import { translations } from '../translations';

export type AppTab =
  | 'dashboard'
  | 'pos'
  | 'products'
  | 'purchases'
  | 'customers'
  | 'suppliers'
  | 'expenses'
  | 'daily-cash'
  | 'reports'
  | 'employees'
  | 'sync'
  | 'settings'
  | 'android-guide';

interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
}

interface AppContextType {
  // Localization
  lang: 'bn' | 'en';
  setLang: (lang: 'bn' | 'en') => void;
  t: typeof translations['bn'];
  formatBDT: (amount: number) => string;

  // Active Tab & Navigation
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;

  // Android View Mode (Mobile Frame vs Fullscreen/Desktop)
  isAndroidFrame: boolean;
  setIsAndroidFrame: (val: boolean) => void;

  // Auth & Roles
  currentUser: Employee;
  employees: Employee[];
  switchUser: (pin: string) => boolean;
  updateEmployee: (emp: Employee) => void;
  isAdmin: boolean;
  isLoginModalOpen: boolean;
  setIsLoginModalOpen: (val: boolean) => void;
  isMobileSetupOpen: boolean;
  setIsMobileSetupOpen: (val: boolean) => void;

  // Data
  products: Product[];
  categories: ProductCategory[];
  customers: Customer[];
  suppliers: Supplier[];
  sales: Sale[];
  purchases: Purchase[];
  expenses: Expense[];
  cashSession: DailyCashSession;
  allCashSessions: DailyCashSession[];
  auditLogs: AuditLog[];
  syncMeta: SyncMetadata;

  // Network & Sync
  isOnline: boolean;
  setIsOnline: (val: boolean) => void;
  syncNow: () => Promise<void>;

  // Operations
  refreshAllData: () => void;
  saveProduct: (product: Product) => void;
  deleteProduct: (id: string) => void;
  recordSale: (saleData: any) => Sale;
  recordPurchase: (purchaseData: any) => Purchase;
  saveCustomer: (cust: Customer) => void;
  collectDue: (customerId: string, amount: number, method: PaymentMethod, note?: string) => void;
  saveSupplier: (sup: Supplier) => void;
  paySupplier: (supplierId: string, amount: number, method: PaymentMethod, note?: string) => void;
  recordExpense: (expData: any) => void;
  closeDailyCash: (actualCounted: number, notes?: string) => void;

  // Thermal Receipt State
  lastCompletedSale: Sale | null;
  setLastCompletedSale: (sale: Sale | null) => void;

  // Toasts
  toasts: ToastMessage[];
  showToast: (message: string, type?: 'success' | 'error' | 'info' | 'warning') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [lang, setLangState] = useState<'bn' | 'en'>('bn');
  const [activeTab, setActiveTab] = useState<AppTab>('dashboard');
  const [isAndroidFrame, setIsAndroidFrame] = useState<boolean>(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [isMobileSetupOpen, setIsMobileSetupOpen] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [lastCompletedSale, setLastCompletedSale] = useState<Sale | null>(null);

  // Online / Offline State
  const [isOnline, setIsOnlineState] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  // Core Data States
  const [currentUser, setCurrentUser] = useState<Employee>(() => {
    AFMarketStorage.init();
    return AFMarketStorage.getActiveUser();
  });
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [cashSession, setCashSession] = useState<DailyCashSession>(() => AFMarketStorage.getTodayCashSession());
  const [allCashSessions, setAllCashSessions] = useState<DailyCashSession[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [syncMeta, setSyncMeta] = useState<SyncMetadata>(() => AFMarketStorage.getSyncMetadata());

  // Show Toast
  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' | 'warning' = 'success') => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts(prev => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  }, []);

  // Reload data from local storage
  const refreshAllData = useCallback(() => {
    setProducts(AFMarketStorage.getProducts());
    setCategories(AFMarketStorage.getCategories());
    setCustomers(AFMarketStorage.getCustomers());
    setSuppliers(AFMarketStorage.getSuppliers());
    setSales(AFMarketStorage.getSales());
    setPurchases(AFMarketStorage.getPurchases());
    setExpenses(AFMarketStorage.getExpenses());
    setCashSession(AFMarketStorage.getTodayCashSession());
    setAllCashSessions(AFMarketStorage.getCashSessions());
    setEmployees(AFMarketStorage.getEmployees());
    setAuditLogs(AFMarketStorage.getAuditLogs());
    setSyncMeta(AFMarketStorage.getSyncMetadata());
    setCurrentUser(AFMarketStorage.getActiveUser());
  }, []);

  // Initial load & network listener
  useEffect(() => {
    AFMarketStorage.init();
    refreshAllData();

    const handleOnline = () => {
      setIsOnlineState(true);
      showToast(lang === 'bn' ? 'ইন্টারনেট সংযোগ পুনরুদ্ধার হয়েছে' : 'Internet connection restored', 'info');
    };
    const handleOffline = () => {
      setIsOnlineState(false);
      showToast(lang === 'bn' ? 'অফলাইন মোড সক্রিয় (সব ডাটা সুরক্ষিত)' : 'Offline mode active (Local storage safe)', 'warning');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [refreshAllData, showToast, lang]);

  const setLang = (newLang: 'bn' | 'en') => {
    setLangState(newLang);
    document.documentElement.lang = newLang;
  };

  const setIsOnline = (val: boolean) => {
    setIsOnlineState(val);
    if (!val) {
      showToast(lang === 'bn' ? 'অফলাইন মোড সিমুলেট করা হচ্ছে' : 'Simulating offline mode', 'warning');
    } else {
      showToast(lang === 'bn' ? 'অনলাইন মোড সক্রিয়' : 'Online mode active', 'info');
    }
  };

  // User Switch
  const switchUser = (pin: string): boolean => {
    const allEmps = AFMarketStorage.getEmployees();
    const found = allEmps.find(e => e.pin === pin && e.isActive);
    if (found) {
      AFMarketStorage.setActiveUser(found);
      setCurrentUser(found);
      setIsLoginModalOpen(false);
      showToast(
        lang === 'bn'
          ? `স্বাগতম ${found.name} (${found.role === 'ADMIN' ? 'মালিক' : 'কর্মচারী'})`
          : `Welcome ${found.name} (${found.role})`,
        'success'
      );
      return true;
    }
    showToast(lang === 'bn' ? 'ভুল পিন কোড! আবার চেষ্টা করুন' : 'Incorrect PIN! Try again', 'error');
    return false;
  };

  const updateEmployee = (emp: Employee) => {
    AFMarketStorage.saveEmployee(emp);
    refreshAllData();
    showToast(lang === 'bn' ? 'কর্মচারী তথ্য আপডেট করা হয়েছে' : 'Employee updated', 'success');
  };

  // Number / Currency Formatter
  const formatBDT = useCallback((amount: number): string => {
    const rounded = Math.round(amount);
    const formatted = rounded.toLocaleString('en-US');
    if (lang === 'bn') {
      // Bengali digits
      const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
      const bnStr = formatted.replace(/\d/g, d => bnDigits[parseInt(d, 10)]);
      return `৳ ${bnStr}`;
    }
    return `৳ ${formatted}`;
  }, [lang]);

  // Operations
  const saveProduct = (product: Product) => {
    AFMarketStorage.saveProduct(product);
    refreshAllData();
    showToast(lang === 'bn' ? 'পণ্য সফলভাবে সংরক্ষিত' : 'Product saved successfully', 'success');
  };

  const deleteProduct = (id: string) => {
    AFMarketStorage.deleteProduct(id);
    refreshAllData();
    showToast(lang === 'bn' ? 'পণ্য মুছে ফেলা হয়েছে' : 'Product deleted', 'info');
  };

  const recordSale = (saleData: any): Sale => {
    const sale = AFMarketStorage.recordSale(saleData);
    refreshAllData();
    setLastCompletedSale(sale);
    showToast(
      lang === 'bn'
        ? `বিক্রয় সম্পন্ন! চালান: ${sale.invoiceNumber} (লাভ: ${formatBDT(sale.grossProfit)})`
        : `Sale complete! Inv: ${sale.invoiceNumber}`,
      'success'
    );
    return sale;
  };

  const recordPurchase = (purchaseData: any): Purchase => {
    const pur = AFMarketStorage.recordPurchase(purchaseData);
    refreshAllData();
    showToast(
      lang === 'bn'
        ? `পাইকারি ক্রয় চালানে স্টক বৃদ্ধি ও গড় মূল্য সমন্বয় হয়েছে`
        : `Purchase recorded & weighted cost updated`,
      'success'
    );
    return pur;
  };

  const saveCustomer = (cust: Customer) => {
    AFMarketStorage.saveCustomer(cust);
    refreshAllData();
    showToast(lang === 'bn' ? 'কাস্টমার তথ্য সংরক্ষিত' : 'Customer saved', 'success');
  };

  const collectDue = (customerId: string, amount: number, method: PaymentMethod, note?: string) => {
    AFMarketStorage.collectCustomerDue(customerId, amount, method, note);
    refreshAllData();
    showToast(
      lang === 'bn' ? `৳${amount} বাকি আদায় সম্পন্ন হয়েছে!` : `Due collected: ৳${amount}`,
      'success'
    );
  };

  const saveSupplier = (sup: Supplier) => {
    AFMarketStorage.saveSupplier(sup);
    refreshAllData();
    showToast(lang === 'bn' ? 'সাপ্লায়ার তথ্য সংরক্ষিত' : 'Supplier saved', 'success');
  };

  const paySupplier = (supplierId: string, amount: number, method: PaymentMethod, note?: string) => {
    AFMarketStorage.paySupplier(supplierId, amount, method, note);
    refreshAllData();
    showToast(
      lang === 'bn' ? `মহাজন পাওনা ৳${amount} পরিশোধ করা হয়েছে` : `Supplier paid: ৳${amount}`,
      'success'
    );
  };

  const recordExpense = (expData: any) => {
    AFMarketStorage.recordExpense(expData);
    refreshAllData();
    showToast(lang === 'bn' ? 'দোকানের খরচ এন্ট্রি করা হয়েছে' : 'Expense recorded', 'success');
  };

  const closeDailyCash = (actualCounted: number, notes?: string) => {
    AFMarketStorage.closeDailyCash(actualCounted, notes);
    refreshAllData();
    showToast(
      lang === 'bn' ? 'আজকের ক্যাশ ড্রয়ার সমাপ্ত ও সংরক্ষিত হয়েছে' : 'Daily cash drawer closed',
      'success'
    );
  };

  // Online Synchronization
  const syncNow = async () => {
    if (!isOnline) {
      showToast(lang === 'bn' ? 'ইন্টারনেট অফলাইন! সংযোগ দিন' : 'Offline! Connect to internet', 'error');
      return;
    }
    const meta = AFMarketStorage.getSyncMetadata();
    meta.status = 'SYNCING';
    setSyncMeta({ ...meta });
    
    // Simulate real cloud sync with Supabase
    await new Promise(resolve => setTimeout(resolve, 1400));
    AFMarketStorage.markSynced();
    refreshAllData();
    showToast(
      lang === 'bn'
        ? 'ক্লাউড ডেটাবেস ও ব্যাকআপে সমস্ত রেকর্ড সফলভাবে সিঙ্ক হয়েছে!'
        : 'All records synced to Supabase Cloud Database!',
      'success'
    );
  };

  const isAdmin = currentUser.role === 'ADMIN';
  const t = translations[lang];

  const value = useMemo(
    () => ({
      lang,
      setLang,
      t,
      formatBDT,
      activeTab,
      setActiveTab,
      isAndroidFrame,
      setIsAndroidFrame,
      currentUser,
      employees,
      switchUser,
      updateEmployee,
      isAdmin,
      isLoginModalOpen,
      setIsLoginModalOpen,
      isMobileSetupOpen,
      setIsMobileSetupOpen,
      products,
      categories,
      customers,
      suppliers,
      sales,
      purchases,
      expenses,
      cashSession,
      allCashSessions,
      auditLogs,
      syncMeta,
      isOnline,
      setIsOnline,
      syncNow,
      refreshAllData,
      saveProduct,
      deleteProduct,
      recordSale,
      recordPurchase,
      saveCustomer,
      collectDue,
      saveSupplier,
      paySupplier,
      recordExpense,
      closeDailyCash,
      lastCompletedSale,
      setLastCompletedSale,
      toasts,
      showToast,
    }),
    [
      lang,
      t,
      formatBDT,
      activeTab,
      isAndroidFrame,
      currentUser,
      employees,
      isAdmin,
      isLoginModalOpen,
      isMobileSetupOpen,
      products,
      categories,
      customers,
      suppliers,
      sales,
      purchases,
      expenses,
      cashSession,
      allCashSessions,
      auditLogs,
      syncMeta,
      isOnline,
      toasts,
      showToast,
      refreshAllData,
      lastCompletedSale,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
