import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Safely register PWA Service Worker for offline caching in production
if (import.meta.env.PROD && typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  import('virtual:pwa-register')
    .then(({ registerSW }) => {
      registerSW({
        immediate: true,
        onNeedRefresh() {
          console.log('AF Market new version available.');
        },
        onOfflineReady() {
          console.log('AF Market is ready to work offline.');
        },
      });
    })
    .catch(err => {
      console.debug('Service Worker registration skipped:', err);
    });
}

createRoot(document.getElementById('root')!).render(<App />);
