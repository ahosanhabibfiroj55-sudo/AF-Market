/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/layout/Header';
import { BottomNav } from './components/layout/BottomNav';
import { Sidebar } from './components/layout/Sidebar';
import { SplashScreen } from './components/layout/SplashScreen';
import { LoginModal } from './components/auth/LoginModal';
import { MobileRunModal } from './components/mobile/MobileRunModal';
import { Dashboard } from './components/dashboard/Dashboard';
import { POSView } from './components/pos/POSView';
import { ProductManagement } from './components/products/ProductManagement';
import { PurchaseManagement } from './components/purchases/PurchaseManagement';
import { CustomerManagement } from './components/customers/CustomerManagement';
import { SupplierManagement } from './components/suppliers/SupplierManagement';
import { ExpenseManagement } from './components/expenses/ExpenseManagement';
import { DailyCashManagement } from './components/cash/DailyCashManagement';
import { ReportsView } from './components/reports/ReportsView';
import { EmployeeManagement } from './components/employees/EmployeeManagement';
import { SyncAndBackupView } from './components/sync/SyncAndBackupView';
import { AndroidStudioGuide } from './components/android/AndroidStudioGuide';
import { SettingsView } from './components/settings/SettingsView';
import {
  CheckCircle,
  AlertCircle,
  Info,
  AlertTriangle,
  Wifi,
  Battery,
  Signal,
  X,
  Maximize2,
  Minimize2,
} from 'lucide-react';

const AppContent: React.FC = () => {
  const {
    activeTab,
    isAndroidFrame,
    setIsAndroidFrame,
    toasts,
    currentUser,
    isAdmin,
    t,
    lang,
  } = useApp();

  const [hasShownSplash, setHasShownSplash] = useState(true); // Can show once if desired or start directly

  // Render view based on active tab
  const renderCurrentView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'pos':
        return <POSView />;
      case 'products':
        return <ProductManagement />;
      case 'purchases':
        return <PurchaseManagement />;
      case 'customers':
        return <CustomerManagement />;
      case 'suppliers':
        return <SupplierManagement />;
      case 'expenses':
        return <ExpenseManagement />;
      case 'daily-cash':
        return <DailyCashManagement />;
      case 'reports':
        return <ReportsView />;
      case 'employees':
        return <EmployeeManagement />;
      case 'sync':
        return <SyncAndBackupView />;
      case 'android-guide':
        return <AndroidStudioGuide />;
      case 'settings':
        return <SettingsView />;
      default:
        return <Dashboard />;
    }
  };

  // Toast Container
  const renderToasts = () => (
    <div className="fixed top-14 right-3 sm:right-6 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      {toasts.map(toast => {
        const bg =
          toast.type === 'error'
            ? 'bg-rose-600 text-white'
            : toast.type === 'warning'
            ? 'bg-amber-500 text-slate-950 font-semibold'
            : toast.type === 'info'
            ? 'bg-blue-600 text-white'
            : 'bg-[#0B2B50] text-white border border-blue-800';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto p-3 rounded-xl shadow-xl flex items-center gap-2.5 text-xs animate-in slide-in-from-top-2 duration-200 ${bg}`}
          >
            {toast.type === 'error' ? (
              <AlertCircle className="w-4 h-4 shrink-0 text-white" />
            ) : toast.type === 'warning' ? (
              <AlertTriangle className="w-4 h-4 shrink-0 text-slate-950" />
            ) : toast.type === 'info' ? (
              <Info className="w-4 h-4 shrink-0 text-white" />
            ) : (
              <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
            )}
            <span className="flex-1 leading-snug">{toast.message}</span>
          </div>
        );
      })}
    </div>
  );

  // If Android Mobile Device Frame is active
  if (isAndroidFrame) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-2 sm:p-6 select-none">
        {/* Frame Controls Bar */}
        <div className="mb-3 flex items-center justify-between w-full max-w-[420px] text-slate-300 text-xs px-2">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-bold">Android Phone Preview</span>
          </div>
          <button
            onClick={() => setIsAndroidFrame(false)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-semibold transition-colors"
          >
            <Maximize2 className="w-3.5 h-3.5" />
            <span>ফুলস্ক্রিন ভিউ</span>
          </button>
        </div>

        {/* Realistic Android Phone Device Shell */}
        <div className="w-full max-w-[410px] h-[840px] max-h-[92vh] bg-black rounded-[44px] p-3 shadow-2xl ring-1 ring-slate-700/80 flex flex-col relative overflow-hidden">
          {/* Hardware Camera Notch */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-4 bg-black rounded-b-xl z-40 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-slate-900 ring-1 ring-slate-800" />
          </div>

          {/* Android Screen Body */}
          <div className="flex-1 bg-slate-50 rounded-[34px] overflow-hidden flex flex-col relative">
            {/* Android System Status Bar */}
            <div className="bg-[#0B2B50] text-white px-5 pt-1.5 pb-1 flex items-center justify-between text-[11px] font-mono shrink-0 select-none">
              <span>{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              <div className="flex items-center gap-2 text-slate-200">
                <Wifi className="w-3 h-3" />
                <Signal className="w-3 h-3" />
                <div className="flex items-center gap-0.5">
                  <span className="text-[10px]">98%</span>
                  <Battery className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>

            {/* App Header */}
            <Header />

            {/* Scrollable Viewport Content */}
            <main className="flex-1 overflow-y-auto p-3.5 pb-20">
              {renderCurrentView()}
            </main>

            {/* Android Bottom Navigation */}
            <BottomNav />

            {/* Android System Gesture Navigation Pill */}
            <div className="bg-white py-1 flex justify-center shrink-0 border-t border-slate-100">
              <div className="w-28 h-1 bg-slate-400 rounded-full" />
            </div>

            {renderToasts()}
            <LoginModal />
            <MobileRunModal />
          </div>
        </div>
      </div>
    );
  }

  // Standard Fullscreen / Desktop / Mobile responsive layout
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      <Header />

      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {/* Desktop Sidebar (visible on md screens and up) */}
        <div className="hidden md:block">
          <Sidebar />
        </div>

        {/* Main Content Area */}
        <main className="flex-1 min-w-0 p-3 sm:p-6 overflow-y-auto">
          {renderCurrentView()}
        </main>
      </div>

      {/* Mobile Bottom Navigation (visible on mobile screens) */}
      <div className="md:hidden">
        <BottomNav />
      </div>

      {renderToasts()}
      <LoginModal />
      <MobileRunModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
