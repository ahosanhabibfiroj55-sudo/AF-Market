/**
 * AF Market - Offline-First Local Storage Engine
 * Handles persistent offline data, audit logs, weighted average cost calculation,
 * cash drawer reconciliation, and sync queue.
 */

import {
  Product,
  ProductCategory,
  Customer,
  CustomerPayment,
  Supplier,
  SupplierPayment,
  Sale,
  Purchase,
  Expense,
  DailyCashSession,
  Employee,
  AuditLog,
  SyncMetadata,
  PaymentMethod,
} from '../types';

const STORAGE_KEYS = {
  PRODUCTS: 'afmarket_products_v1',
  CATEGORIES: 'afmarket_categories_v1',
  CUSTOMERS: 'afmarket_customers_v1',
  CUSTOMER_PAYMENTS: 'afmarket_customer_payments_v1',
  SUPPLIERS: 'afmarket_suppliers_v1',
  SUPPLIER_PAYMENTS: 'afmarket_supplier_payments_v1',
  SALES: 'afmarket_sales_v1',
  PURCHASES: 'afmarket_purchases_v1',
  EXPENSES: 'afmarket_expenses_v1',
  CASH_SESSIONS: 'afmarket_cash_sessions_v1',
  EMPLOYEES: 'afmarket_employees_v1',
  AUDIT_LOGS: 'afmarket_audit_logs_v1',
  SYNC_META: 'afmarket_sync_metadata_v1',
  ACTIVE_USER: 'afmarket_active_user_v1',
};

// Seed Categories
const initialCategories: ProductCategory[] = [
  { id: 'cat-grocery', nameBn: 'মুদি ও চাল-ডাল', nameEn: 'Grocery & Rice' },
  { id: 'cat-oil', nameBn: 'তেল ও ঘি', nameEn: 'Edible Oil & Ghee' },
  { id: 'cat-spices', nameBn: 'মসলা ও লবণ', nameEn: 'Spices & Salt' },
  { id: 'cat-dairy', nameBn: 'দুধ ও ডেইরি', nameEn: 'Dairy & Beverages' },
  { id: 'cat-snacks', nameBn: 'বিস্কুট ও চানাচুর', nameEn: 'Bakery & Snacks' },
  { id: 'cat-hygiene', nameBn: 'সাবান ও প্রসাধন', nameEn: 'Hygiene & Cleaning' },
];

// Seed Products for Wholesale/Retail Grocery Shop
const initialProducts: Product[] = [
  {
    id: 'prod-001',
    name: 'Miniket Rice Premium 25kg',
    nameBn: 'মিনিকেট চাল প্রিমিয়াম ২৫ কেজি বস্তা',
    category: 'cat-grocery',
    barcode: '8941100101',
    purchasePrice: 1750,
    sellingPrice: 1920,
    currentStock: 48,
    minStockLevel: 10,
    unit: 'box',
    description: 'উচ্চমানের সরু মিনিকেট চাল, ২৫ কেজি বস্তা',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod-002',
    name: 'Nazirshail Rice 50kg',
    nameBn: 'নাজিরশাইল চাল ৫০ কেজি বস্তা',
    category: 'cat-grocery',
    barcode: '8941100102',
    purchasePrice: 3400,
    sellingPrice: 3750,
    currentStock: 25,
    minStockLevel: 8,
    unit: 'box',
    description: 'খাঁটি নাজিরশাইল চাল ৫০ কেজি বস্তা',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod-003',
    name: 'Teer Fortified Soybean Oil 5L',
    nameBn: 'তীর সয়াবিন তেল ৫ লিটার',
    category: 'cat-oil',
    barcode: '8941100103',
    purchasePrice: 830,
    sellingPrice: 910,
    currentStock: 36,
    minStockLevel: 8,
    unit: 'box',
    description: 'তীর পরিশোধিত সয়াবিন তেল ৫ লিটার বোতল',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod-004',
    name: 'Rupchanda Soybean Oil 1L',
    nameBn: 'রূপচাঁদা সয়াবিন তেল ১ লিটার',
    category: 'cat-oil',
    barcode: '8941100104',
    purchasePrice: 172,
    sellingPrice: 190,
    currentStock: 60,
    minStockLevel: 15,
    unit: 'piece',
    description: 'রূপচাঁদা পুষ্টিসমৃদ্ধ সয়াবিন তেল ১ লিটার',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod-005',
    name: 'Fresh Refined Sugar 1kg',
    nameBn: 'ফ্রেশ পরিশোধিত সাদা চিনি ১ কেজি',
    category: 'cat-grocery',
    barcode: '8941100105',
    purchasePrice: 122,
    sellingPrice: 135,
    currentStock: 120,
    minStockLevel: 25,
    unit: 'kg',
    description: 'ফ্রেশ সাদা চিনি প্যাকেট ১ কেজি',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod-006',
    name: 'Red Lentils (Mosur Dal Deshi) 1kg',
    nameBn: 'দেশি মসুর ডাল ১ কেজি',
    category: 'cat-grocery',
    barcode: '8941100106',
    purchasePrice: 135,
    sellingPrice: 150,
    currentStock: 75,
    minStockLevel: 20,
    unit: 'kg',
    description: 'ছোট দানার দেশি মসুর ডাল',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod-007',
    name: 'Radhuni Turmeric Powder 500g',
    nameBn: 'রাধুনী হলুদ গুঁড়া ৫০০ গ্রাম',
    category: 'cat-spices',
    barcode: '8941100107',
    purchasePrice: 170,
    sellingPrice: 195,
    currentStock: 40,
    minStockLevel: 12,
    unit: 'packet',
    description: 'খাঁটি রাধুনী হলুদ গুঁড়া',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod-008',
    name: 'Radhuni Chilli Powder 500g',
    nameBn: 'রাধুনী মরিচ গুঁড়া ৫০০ গ্রাম',
    category: 'cat-spices',
    barcode: '8941100108',
    purchasePrice: 210,
    sellingPrice: 245,
    currentStock: 6, // Low stock on purpose for testing
    minStockLevel: 12,
    unit: 'packet',
    description: 'ঝাঁঝালো খাঁটি মরিচ গুঁড়া',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod-009',
    name: 'ACI Pure Iodized Salt 1kg',
    nameBn: 'এসিআই পিওর আয়োডিনযুক্ত লবণ ১ কেজি',
    category: 'cat-spices',
    barcode: '8941100109',
    purchasePrice: 34,
    sellingPrice: 42,
    currentStock: 95,
    minStockLevel: 25,
    unit: 'packet',
    description: 'ভ্যাকুয়াম ইভাপোরেটেড পিওর লবণ',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod-010',
    name: 'Aarong UHT Milk 1 Litre',
    nameBn: 'আড়ং ডেইরি তরল দুধ ১ লিটার',
    category: 'cat-dairy',
    barcode: '8941100110',
    purchasePrice: 88,
    sellingPrice: 100,
    currentStock: 5, // Low stock on purpose
    minStockLevel: 15,
    unit: 'litre',
    description: 'আড়ং খাঁটি গরুর তরল দুধ ১ লিটার টেট্রাপ্যাক',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod-011',
    name: 'Taaza Black Tea 400g',
    nameBn: 'তাজা ব্ল্যাক টি ৪০০ গ্রাম',
    category: 'cat-dairy',
    barcode: '8941100111',
    purchasePrice: 215,
    sellingPrice: 250,
    currentStock: 30,
    minStockLevel: 10,
    unit: 'packet',
    description: 'তাজা সতেজ দানাদার চা পাতা',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod-012',
    name: 'Wheel Washing Powder 1kg',
    nameBn: 'হুইল ওয়াশিং পাউডার ১ কেজি',
    category: 'cat-hygiene',
    barcode: '8941100112',
    purchasePrice: 140,
    sellingPrice: 160,
    currentStock: 45,
    minStockLevel: 12,
    unit: 'packet',
    description: 'লেবুর সুবাসযুক্ত ডিটারজেন্ট পাউডার',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

// Seed Customers with Due balances (বাকি খাতা)
const initialCustomers: Customer[] = [
  {
    id: 'cust-001',
    name: 'Rafiqul Islam (মুদি ব্যবসায়ী)',
    phone: '01712-345678',
    address: 'বাজার মোড়, দোকান নং ১২',
    totalPurchases: 45600,
    totalPaid: 38000,
    remainingDue: 7600,
    createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
  },
  {
    id: 'cust-002',
    name: 'Kamal Hossain (রেস্তোরাঁ)',
    phone: '01819-876543',
    address: 'স্টেশন রোড, আল মদিনা হোটেল',
    totalPurchases: 62400,
    totalPaid: 54000,
    remainingDue: 8400,
    createdAt: new Date(Date.now() - 45 * 86400000).toISOString(),
  },
  {
    id: 'cust-003',
    name: 'Nazmul Haque (খুচরা ক্রেতা)',
    phone: '01911-223344',
    address: 'কলেজ পাড়া, বাড়ি নং ৪',
    totalPurchases: 18500,
    totalPaid: 16200,
    remainingDue: 2300,
    createdAt: new Date(Date.now() - 20 * 86400000).toISOString(),
  },
  {
    id: 'cust-004',
    name: 'Abdur Rahim (চা দোকানি)',
    phone: '01615-998877',
    address: 'বাস স্ট্যান্ড মোড়',
    totalPurchases: 9800,
    totalPaid: 9800,
    remainingDue: 0,
    createdAt: new Date(Date.now() - 15 * 86400000).toISOString(),
  },
];

// Seed Suppliers (মহাজন / পাইকারি প্রতিষ্ঠান)
const initialSuppliers: Supplier[] = [
  {
    id: 'sup-001',
    name: 'City Group of Industries (তীর)',
    phone: '01711-002233',
    address: 'সিটি সেন্টার, দিলকুশা, ঢাকা',
    companyName: 'City Group (Teer Brand)',
    totalPurchases: 125000,
    totalPaid: 105000,
    remainingPayable: 20000,
    createdAt: new Date(Date.now() - 60 * 86400000).toISOString(),
  },
  {
    id: 'sup-002',
    name: 'Meghna Group (ফ্রেশ পণ্য)',
    phone: '01811-334455',
    address: 'মেগনা ঘাট, সোনারগাঁও',
    companyName: 'Meghna Group of Industries',
    totalPurchases: 94000,
    totalPaid: 79000,
    remainingPayable: 15000,
    createdAt: new Date(Date.now() - 40 * 86400000).toISOString(),
  },
  {
    id: 'sup-003',
    name: 'Square Consumer Products Ltd (রাধুনী/রুচি)',
    phone: '01912-778899',
    address: 'স্কয়ার সেন্টার, মহাখালী, ঢাকা',
    companyName: 'Square Group',
    totalPurchases: 68000,
    totalPaid: 68000,
    remainingPayable: 0,
    createdAt: new Date(Date.now() - 50 * 86400000).toISOString(),
  },
];

// Seed Employees
const initialEmployees: Employee[] = [
  {
    id: 'emp-admin',
    name: 'Ahosan Habib Firoj',
    phone: '01700-000000',
    email: 'ahosanhabibfiroj0@gmail.com',
    pin: '1234',
    role: 'ADMIN',
    isActive: true,
    joiningDate: '2025-01-01',
  },
  {
    id: 'emp-001',
    name: 'Shakil Ahmed (বিক্রয় সহকারী)',
    phone: '01822-112233',
    email: 'shakil@afmarket.com',
    pin: '2222',
    role: 'EMPLOYEE',
    isActive: true,
    joiningDate: '2025-06-15',
  },
  {
    id: 'emp-002',
    name: 'Tanvir Hasan (স্টক ইনচার্জ)',
    phone: '01933-445566',
    email: 'tanvir@afmarket.com',
    pin: '3333',
    role: 'EMPLOYEE',
    isActive: true,
    joiningDate: '2025-08-01',
  },
];

// Seed Expenses
const initialExpenses: Expense[] = [
  {
    id: 'exp-001',
    title: 'দোকান ভাড়া (চলতি মাস)',
    category: 'RENT',
    amount: 15000,
    paymentMethod: 'CASH',
    description: 'মালিক মো. আনোয়ার হোসেনকে অগ্রিম ভাড়া প্রদান',
    recordedBy: 'Ahosan Habib Firoj',
    date: new Date(Date.now() - 4 * 86400000).toISOString().split('T')[0],
    syncStatus: 'SYNCED',
  },
  {
    id: 'exp-002',
    title: 'পল্লি বিদ্যুৎ বিল',
    category: 'ELECTRICITY',
    amount: 3200,
    paymentMethod: 'BKASH',
    description: 'মিটার নং ৯৮৭৬৫',
    recordedBy: 'Ahosan Habib Firoj',
    date: new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0],
    syncStatus: 'SYNCED',
  },
  {
    id: 'exp-003',
    title: 'দোকানের কর্মচারীদের দুপুরের নাস্তা',
    category: 'FOOD',
    amount: 350,
    paymentMethod: 'CASH',
    description: 'চা ও বিস্কুট',
    recordedBy: 'Shakil Ahmed',
    date: new Date().toISOString().split('T')[0],
    syncStatus: 'SYNCED',
  },
];

// Helper to safe parse JSON
function getStorageItem<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (e) {
    console.error(`Error loading key ${key} from localStorage:`, e);
    return defaultValue;
  }
}

function setStorageItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`Error saving key ${key} to localStorage:`, e);
  }
}

export class AFMarketStorage {
  // Initialize default data if fresh
  static init(): void {
    if (!localStorage.getItem(STORAGE_KEYS.PRODUCTS)) {
      setStorageItem(STORAGE_KEYS.PRODUCTS, initialProducts);
    }
    if (!localStorage.getItem(STORAGE_KEYS.CATEGORIES)) {
      setStorageItem(STORAGE_KEYS.CATEGORIES, initialCategories);
    }
    if (!localStorage.getItem(STORAGE_KEYS.CUSTOMERS)) {
      setStorageItem(STORAGE_KEYS.CUSTOMERS, initialCustomers);
    }
    if (!localStorage.getItem(STORAGE_KEYS.SUPPLIERS)) {
      setStorageItem(STORAGE_KEYS.SUPPLIERS, initialSuppliers);
    }
    if (!localStorage.getItem(STORAGE_KEYS.EMPLOYEES)) {
      setStorageItem(STORAGE_KEYS.EMPLOYEES, initialEmployees);
    }
    if (!localStorage.getItem(STORAGE_KEYS.EXPENSES)) {
      setStorageItem(STORAGE_KEYS.EXPENSES, initialExpenses);
    }
    if (!localStorage.getItem(STORAGE_KEYS.SALES)) {
      setStorageItem(STORAGE_KEYS.SALES, []);
    }
    if (!localStorage.getItem(STORAGE_KEYS.PURCHASES)) {
      setStorageItem(STORAGE_KEYS.PURCHASES, []);
    }
    if (!localStorage.getItem(STORAGE_KEYS.CUSTOMER_PAYMENTS)) {
      setStorageItem(STORAGE_KEYS.CUSTOMER_PAYMENTS, []);
    }
    if (!localStorage.getItem(STORAGE_KEYS.SUPPLIER_PAYMENTS)) {
      setStorageItem(STORAGE_KEYS.SUPPLIER_PAYMENTS, []);
    }
    if (!localStorage.getItem(STORAGE_KEYS.CASH_SESSIONS)) {
      const today = new Date().toISOString().split('T')[0];
      const initialSession: DailyCashSession = {
        id: `cash-${today}`,
        date: today,
        openingCash: 12000,
        cashSales: 0,
        customerDueCollections: 0,
        otherCashReceived: 0,
        cashPurchases: 0,
        cashExpenses: 350,
        cashRefunds: 0,
        otherCashPaid: 0,
        expectedClosingCash: 11650,
        actualCountedCash: null,
        difference: null,
        status: 'OPEN',
        notes: 'আজকের প্রারম্ভিক ক্যাশ ১২,০০০ টাকা',
      };
      setStorageItem(STORAGE_KEYS.CASH_SESSIONS, [initialSession]);
    }
    if (!localStorage.getItem(STORAGE_KEYS.SYNC_META)) {
      const initialMeta: SyncMetadata = {
        lastSyncTime: new Date().toISOString(),
        pendingCount: 0,
        status: 'SYNCED',
      };
      setStorageItem(STORAGE_KEYS.SYNC_META, initialMeta);
    }
    if (!localStorage.getItem(STORAGE_KEYS.ACTIVE_USER)) {
      setStorageItem(STORAGE_KEYS.ACTIVE_USER, initialEmployees[0]);
    }
  }

  // Active User / Auth
  static getActiveUser(): Employee {
    const user = getStorageItem<Employee | null>(STORAGE_KEYS.ACTIVE_USER, null);
    if (!user) return initialEmployees[0];
    return user;
  }

  static setActiveUser(user: Employee): void {
    setStorageItem(STORAGE_KEYS.ACTIVE_USER, user);
    this.addAuditLog('AUTH', `লগইন করেছেন: ${user.name} (${user.role})`, user.name);
  }

  static getEmployees(): Employee[] {
    return getStorageItem<Employee[]>(STORAGE_KEYS.EMPLOYEES, initialEmployees);
  }

  static saveEmployee(employee: Employee): void {
    const list = this.getEmployees();
    const index = list.findIndex(e => e.id === employee.id);
    if (index >= 0) {
      list[index] = employee;
    } else {
      list.push(employee);
    }
    setStorageItem(STORAGE_KEYS.EMPLOYEES, list);
    this.addAuditLog('AUTH', `কর্মচারী আপডেট: ${employee.name}`, this.getActiveUser().name);
  }

  // Products
  static getProducts(): Product[] {
    return getStorageItem<Product[]>(STORAGE_KEYS.PRODUCTS, initialProducts);
  }

  static getCategories(): ProductCategory[] {
    return getStorageItem<ProductCategory[]>(STORAGE_KEYS.CATEGORIES, initialCategories);
  }

  static saveProduct(product: Product): void {
    const list = this.getProducts();
    const index = list.findIndex(p => p.id === product.id);
    if (index >= 0) {
      list[index] = { ...product, updatedAt: new Date().toISOString() };
    } else {
      list.unshift({ ...product, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
    setStorageItem(STORAGE_KEYS.PRODUCTS, list);
    this.addAuditLog('PRODUCT', `পণ্য সংরক্ষণ: ${product.nameBn} (স্টক: ${product.currentStock})`, this.getActiveUser().name);
    this.incrementPendingSync();
  }

  static deleteProduct(productId: string): void {
    const list = this.getProducts().filter(p => p.id !== productId);
    setStorageItem(STORAGE_KEYS.PRODUCTS, list);
    this.addAuditLog('PRODUCT', `পণ্য মুছে ফেলা হয়েছে (ID: ${productId})`, this.getActiveUser().name);
    this.incrementPendingSync();
  }

  // Customers & Dues (বাকি খাতা)
  static getCustomers(): Customer[] {
    return getStorageItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, initialCustomers);
  }

  static saveCustomer(customer: Customer): void {
    const list = this.getCustomers();
    const index = list.findIndex(c => c.id === customer.id);
    if (index >= 0) {
      list[index] = customer;
    } else {
      list.push(customer);
    }
    setStorageItem(STORAGE_KEYS.CUSTOMERS, list);
    this.addAuditLog('CUSTOMER', `কাস্টমার তথ্য সংরক্ষণ: ${customer.name}`, this.getActiveUser().name);
    this.incrementPendingSync();
  }

  // Collect Customer Due (বাকি আদায়)
  // CRITICAL RULE: Due collection is NOT counted as a new sale. It is a cash inflow that settles outstanding accounts receivable.
  static collectCustomerDue(
    customerId: string,
    amount: number,
    paymentMethod: PaymentMethod,
    note?: string
  ): CustomerPayment {
    const customers = this.getCustomers();
    const customer = customers.find(c => c.id === customerId);
    if (!customer) throw new Error('Customer not found');

    customer.totalPaid += amount;
    customer.remainingDue = Math.max(0, customer.remainingDue - amount);
    setStorageItem(STORAGE_KEYS.CUSTOMERS, customers);

    const payment: CustomerPayment = {
      id: `cpay-${Date.now()}`,
      customerId,
      customerName: customer.name,
      amount,
      paymentMethod,
      note,
      collectedBy: this.getActiveUser().name,
      date: new Date().toISOString(),
      syncStatus: 'PENDING',
    };

    const payments = getStorageItem<CustomerPayment[]>(STORAGE_KEYS.CUSTOMER_PAYMENTS, []);
    payments.unshift(payment);
    setStorageItem(STORAGE_KEYS.CUSTOMER_PAYMENTS, payments);

    // If collected in cash, record in today's cash session
    if (paymentMethod === 'CASH') {
      this.recordCashMovement('DUE_COLLECTION', amount);
    }

    this.addAuditLog(
      'CUSTOMER',
      `বাকি আদায়: ৳${amount} - ${customer.name} (${paymentMethod})`,
      this.getActiveUser().name
    );
    this.incrementPendingSync();

    return payment;
  }

  static getCustomerPayments(): CustomerPayment[] {
    return getStorageItem<CustomerPayment[]>(STORAGE_KEYS.CUSTOMER_PAYMENTS, []);
  }

  // Suppliers & Payables (মহাজন পাওনা)
  static getSuppliers(): Supplier[] {
    return getStorageItem<Supplier[]>(STORAGE_KEYS.SUPPLIERS, initialSuppliers);
  }

  static saveSupplier(supplier: Supplier): void {
    const list = this.getSuppliers();
    const index = list.findIndex(s => s.id === supplier.id);
    if (index >= 0) {
      list[index] = supplier;
    } else {
      list.push(supplier);
    }
    setStorageItem(STORAGE_KEYS.SUPPLIERS, list);
    this.addAuditLog('SUPPLIER', `সাপ্লায়ার সংরক্ষণ: ${supplier.name}`, this.getActiveUser().name);
    this.incrementPendingSync();
  }

  // Pay Supplier Due (মহাজন পাওনা পরিশোধ)
  // CRITICAL RULE: Supplier payment is NOT counted as a new purchase. It settles outstanding accounts payable.
  static paySupplier(
    supplierId: string,
    amount: number,
    paymentMethod: PaymentMethod,
    note?: string
  ): SupplierPayment {
    const suppliers = this.getSuppliers();
    const supplier = suppliers.find(s => s.id === supplierId);
    if (!supplier) throw new Error('Supplier not found');

    supplier.totalPaid += amount;
    supplier.remainingPayable = Math.max(0, supplier.remainingPayable - amount);
    setStorageItem(STORAGE_KEYS.SUPPLIERS, suppliers);

    const payment: SupplierPayment = {
      id: `spay-${Date.now()}`,
      supplierId,
      supplierName: supplier.name,
      amount,
      paymentMethod,
      note,
      paidBy: this.getActiveUser().name,
      date: new Date().toISOString(),
      syncStatus: 'PENDING',
    };

    const payments = getStorageItem<SupplierPayment[]>(STORAGE_KEYS.SUPPLIER_PAYMENTS, []);
    payments.unshift(payment);
    setStorageItem(STORAGE_KEYS.SUPPLIER_PAYMENTS, payments);

    if (paymentMethod === 'CASH') {
      this.recordCashMovement('SUPPLIER_PAYMENT', amount);
    }

    this.addAuditLog(
      'SUPPLIER',
      `মহাজন পাওনা পরিশোধ: ৳${amount} - ${supplier.name} (${paymentMethod})`,
      this.getActiveUser().name
    );
    this.incrementPendingSync();

    return payment;
  }

  static getSupplierPayments(): SupplierPayment[] {
    return getStorageItem<SupplierPayment[]>(STORAGE_KEYS.SUPPLIER_PAYMENTS, []);
  }

  // Sales (POS)
  static getSales(): Sale[] {
    return getStorageItem<Sale[]>(STORAGE_KEYS.SALES, []);
  }

  // Record a Sale
  // Automatically:
  // 1. Decrements stock for each item
  // 2. Calculates Cost of Goods Sold (COGS) based on current weighted average purchase price
  // 3. Calculates Gross Profit = finalAmount - COGS
  // 4. Updates customer balance if credit/partial payment
  // 5. If cash paid, updates cash drawer
  static recordSale(saleData: Omit<Sale, 'id' | 'invoiceNumber' | 'costOfGoodsSold' | 'grossProfit' | 'createdAt' | 'syncStatus'>): Sale {
    const products = this.getProducts();
    let totalCOGS = 0;

    // Validate and reduce stock, calculate COGS
    const updatedItems = saleData.items.map(item => {
      const prod = products.find(p => p.id === item.productId);
      const unitCost = prod ? prod.purchasePrice : item.purchaseUnitCost;
      totalCOGS += unitCost * item.quantity;

      if (prod) {
        prod.currentStock -= item.quantity;
      }

      return {
        ...item,
        purchaseUnitCost: unitCost,
      };
    });

    setStorageItem(STORAGE_KEYS.PRODUCTS, products);

    const grossProfit = saleData.finalAmount - totalCOGS;
    const invoiceNumber = `INV-${Date.now().toString().slice(-6)}`;
    const newSale: Sale = {
      ...saleData,
      id: `sale-${crypto.randomUUID ? crypto.randomUUID() : Date.now()}`,
      invoiceNumber,
      items: updatedItems,
      costOfGoodsSold: Math.round(totalCOGS),
      grossProfit: Math.round(grossProfit),
      createdAt: new Date().toISOString(),
      syncStatus: 'PENDING',
    };

    const sales = this.getSales();
    sales.unshift(newSale);
    setStorageItem(STORAGE_KEYS.SALES, sales);

    // If sale has due and customer is selected, update customer's ledger
    if (newSale.dueAmount > 0 && newSale.customerId) {
      const customers = this.getCustomers();
      const customer = customers.find(c => c.id === newSale.customerId);
      if (customer) {
        customer.totalPurchases += newSale.finalAmount;
        customer.totalPaid += newSale.amountPaid;
        customer.remainingDue += newSale.dueAmount;
        setStorageItem(STORAGE_KEYS.CUSTOMERS, customers);
      }
    } else if (newSale.customerId) {
      // Full payment customer update
      const customers = this.getCustomers();
      const customer = customers.find(c => c.id === newSale.customerId);
      if (customer) {
        customer.totalPurchases += newSale.finalAmount;
        customer.totalPaid += newSale.amountPaid;
        setStorageItem(STORAGE_KEYS.CUSTOMERS, customers);
      }
    }

    // Cash movement
    if (newSale.paymentMethod === 'CASH' && newSale.amountPaid > 0) {
      this.recordCashMovement('CASH_SALE', newSale.amountPaid);
    }

    this.addAuditLog(
      'SALE',
      `বিক্রয় সম্পন্ন: ${invoiceNumber} - ৳${newSale.finalAmount} (লাভ: ৳${grossProfit})`,
      saleData.employeeName
    );
    this.incrementPendingSync();

    return newSale;
  }

  // Purchases (পাইকারি ক্রয়)
  static getPurchases(): Purchase[] {
    return getStorageItem<Purchase[]>(STORAGE_KEYS.PURCHASES, []);
  }

  // Record Wholesale Purchase
  // Automatically:
  // 1. Increases stock
  // 2. Calculates WEIGHTED AVERAGE COST for each product:
  //    new_avg_cost = ((current_stock * old_cost) + (purchase_qty * unit_price)) / (current_stock + purchase_qty)
  // 3. Updates supplier balance (totalPurchases, totalPaid, remainingPayable)
  // 4. Updates cash drawer if paid in cash
  static recordPurchase(purchaseData: Omit<Purchase, 'id' | 'purchaseNumber' | 'syncStatus'>): Purchase {
    const products = this.getProducts();

    purchaseData.items.forEach(item => {
      const prod = products.find(p => p.id === item.productId);
      if (prod) {
        const oldStock = Math.max(0, prod.currentStock);
        const oldCost = prod.purchasePrice;
        const purchaseQty = item.quantity;
        const purchasePrice = item.unitPrice;

        const newStock = oldStock + purchaseQty;
        const newWeightedAverageCost =
          newStock > 0 ? (oldStock * oldCost + purchaseQty * purchasePrice) / newStock : purchasePrice;

        prod.currentStock = newStock;
        prod.purchasePrice = Math.round(newWeightedAverageCost * 10) / 10;
        prod.updatedAt = new Date().toISOString();
      }
    });

    setStorageItem(STORAGE_KEYS.PRODUCTS, products);

    const purchaseNumber = `PUR-${Date.now().toString().slice(-6)}`;
    const newPurchase: Purchase = {
      ...purchaseData,
      id: `pur-${Date.now()}`,
      purchaseNumber,
      syncStatus: 'PENDING',
    };

    const purchases = this.getPurchases();
    purchases.unshift(newPurchase);
    setStorageItem(STORAGE_KEYS.PURCHASES, purchases);

    // Update supplier ledger
    if (purchaseData.supplierId) {
      const suppliers = this.getSuppliers();
      const supplier = suppliers.find(s => s.id === purchaseData.supplierId);
      if (supplier) {
        supplier.totalPurchases += purchaseData.totalAmount;
        supplier.totalPaid += purchaseData.amountPaid;
        supplier.remainingPayable += purchaseData.remainingPayable;
        setStorageItem(STORAGE_KEYS.SUPPLIERS, suppliers);
      }
    }

    // Cash movement
    if (purchaseData.paymentMethod === 'CASH' && purchaseData.amountPaid > 0) {
      this.recordCashMovement('CASH_PURCHASE', purchaseData.amountPaid);
    }

    this.addAuditLog(
      'PURCHASE',
      `পাইকারি ক্রয় চালান: ${purchaseNumber} - ${purchaseData.supplierName} (৳${purchaseData.totalAmount})`,
      purchaseData.recordedBy
    );
    this.incrementPendingSync();

    return newPurchase;
  }

  // Expenses
  static getExpenses(): Expense[] {
    return getStorageItem<Expense[]>(STORAGE_KEYS.EXPENSES, initialExpenses);
  }

  static recordExpense(expenseData: Omit<Expense, 'id' | 'syncStatus'>): Expense {
    const newExpense: Expense = {
      ...expenseData,
      id: `exp-${Date.now()}`,
      syncStatus: 'PENDING',
    };

    const expenses = this.getExpenses();
    expenses.unshift(newExpense);
    setStorageItem(STORAGE_KEYS.EXPENSES, expenses);

    if (expenseData.paymentMethod === 'CASH') {
      this.recordCashMovement('CASH_EXPENSE', expenseData.amount);
    }

    this.addAuditLog('EXPENSE', `খরচ এন্ট্রি: ${expenseData.title} - ৳${expenseData.amount}`, expenseData.recordedBy);
    this.incrementPendingSync();

    return newExpense;
  }

  // Daily Cash Drawer Sessions
  static getCashSessions(): DailyCashSession[] {
    return getStorageItem<DailyCashSession[]>(STORAGE_KEYS.CASH_SESSIONS, []);
  }

  static getTodayCashSession(): DailyCashSession {
    const today = new Date().toISOString().split('T')[0];
    const sessions = this.getCashSessions();
    let session = sessions.find(s => s.date === today);

    if (!session) {
      // Find previous day's closing or default 10,000
      const prevSession = sessions[0];
      const opening = prevSession?.actualCountedCash ?? prevSession?.expectedClosingCash ?? 10000;
      session = {
        id: `cash-${today}`,
        date: today,
        openingCash: opening,
        cashSales: 0,
        customerDueCollections: 0,
        otherCashReceived: 0,
        cashPurchases: 0,
        cashExpenses: 0,
        cashRefunds: 0,
        otherCashPaid: 0,
        expectedClosingCash: opening,
        actualCountedCash: null,
        difference: null,
        status: 'OPEN',
      };
      sessions.unshift(session);
      setStorageItem(STORAGE_KEYS.CASH_SESSIONS, sessions);
    }

    return session;
  }

  static recordCashMovement(
    type: 'CASH_SALE' | 'DUE_COLLECTION' | 'CASH_PURCHASE' | 'CASH_EXPENSE' | 'SUPPLIER_PAYMENT' | 'OTHER_IN' | 'OTHER_OUT',
    amount: number
  ): void {
    const today = new Date().toISOString().split('T')[0];
    const sessions = this.getCashSessions();
    let session = sessions.find(s => s.date === today);

    if (!session) {
      session = this.getTodayCashSession();
    }

    if (type === 'CASH_SALE') session.cashSales += amount;
    if (type === 'DUE_COLLECTION') session.customerDueCollections += amount;
    if (type === 'OTHER_IN') session.otherCashReceived += amount;
    if (type === 'CASH_PURCHASE') session.cashPurchases += amount;
    if (type === 'CASH_EXPENSE') session.cashExpenses += amount;
    if (type === 'SUPPLIER_PAYMENT') session.otherCashPaid += amount;
    if (type === 'OTHER_OUT') session.otherCashPaid += amount;

    // Recalculate Expected Closing Cash
    session.expectedClosingCash =
      session.openingCash +
      session.cashSales +
      session.customerDueCollections +
      session.otherCashReceived -
      (session.cashPurchases + session.cashExpenses + session.cashRefunds + session.otherCashPaid);

    if (session.actualCountedCash !== null) {
      session.difference = session.actualCountedCash - session.expectedClosingCash;
    }

    setStorageItem(STORAGE_KEYS.CASH_SESSIONS, sessions);
  }

  static closeDailyCash(actualCounted: number, notes?: string): DailyCashSession {
    const session = this.getTodayCashSession();
    const sessions = this.getCashSessions();
    const index = sessions.findIndex(s => s.id === session.id);

    session.actualCountedCash = actualCounted;
    session.difference = actualCounted - session.expectedClosingCash;
    session.status = 'CLOSED';
    session.notes = notes;
    session.closedBy = this.getActiveUser().name;
    session.closedAt = new Date().toISOString();

    if (index >= 0) {
      sessions[index] = session;
    }
    setStorageItem(STORAGE_KEYS.CASH_SESSIONS, sessions);

    this.addAuditLog(
      'CASH',
      `ক্যাশ বাক্স বন্ধ: হিসাবমতে ৳${session.expectedClosingCash}, গুনে পাওয়া ৳${actualCounted} (পার্থক্য: ৳${session.difference})`,
      this.getActiveUser().name
    );

    return session;
  }

  // Audit Logs
  static getAuditLogs(): AuditLog[] {
    return getStorageItem<AuditLog[]>(STORAGE_KEYS.AUDIT_LOGS, []);
  }

  static addAuditLog(entityType: AuditLog['entityType'], details: string, performedBy: string): void {
    const logs = this.getAuditLogs();
    const newLog: AuditLog = {
      id: `log-${Date.now()}`,
      action: entityType,
      entityType,
      details,
      performedBy,
      timestamp: new Date().toISOString(),
    };
    logs.unshift(newLog);
    if (logs.length > 200) logs.pop(); // Keep recent 200 logs
    setStorageItem(STORAGE_KEYS.AUDIT_LOGS, logs);
  }

  // Sync Metadata
  static getSyncMetadata(): SyncMetadata {
    return getStorageItem<SyncMetadata>(STORAGE_KEYS.SYNC_META, {
      lastSyncTime: new Date().toISOString(),
      pendingCount: 0,
      status: 'SYNCED',
    });
  }

  static incrementPendingSync(): void {
    const meta = this.getSyncMetadata();
    meta.pendingCount += 1;
    meta.status = 'PENDING';
    setStorageItem(STORAGE_KEYS.SYNC_META, meta);
  }

  static markSynced(): void {
    const meta = this.getSyncMetadata();
    meta.pendingCount = 0;
    meta.status = 'SYNCED';
    meta.lastSyncTime = new Date().toISOString();
    setStorageItem(STORAGE_KEYS.SYNC_META, meta);
  }

  // Export full JSON backup
  static exportFullBackupJSON(): string {
    const data = {
      version: '1.0',
      appName: 'AF Market',
      exportedAt: new Date().toISOString(),
      products: this.getProducts(),
      categories: this.getCategories(),
      customers: this.getCustomers(),
      customerPayments: this.getCustomerPayments(),
      suppliers: this.getSuppliers(),
      supplierPayments: this.getSupplierPayments(),
      sales: this.getSales(),
      purchases: this.getPurchases(),
      expenses: this.getExpenses(),
      cashSessions: this.getCashSessions(),
      employees: this.getEmployees(),
      auditLogs: this.getAuditLogs(),
    };
    return JSON.stringify(data, null, 2);
  }

  // Restore full JSON backup
  static restoreFromJSON(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (data.products) setStorageItem(STORAGE_KEYS.PRODUCTS, data.products);
      if (data.categories) setStorageItem(STORAGE_KEYS.CATEGORIES, data.categories);
      if (data.customers) setStorageItem(STORAGE_KEYS.CUSTOMERS, data.customers);
      if (data.customerPayments) setStorageItem(STORAGE_KEYS.CUSTOMER_PAYMENTS, data.customerPayments);
      if (data.suppliers) setStorageItem(STORAGE_KEYS.SUPPLIERS, data.suppliers);
      if (data.supplierPayments) setStorageItem(STORAGE_KEYS.SUPPLIER_PAYMENTS, data.supplierPayments);
      if (data.sales) setStorageItem(STORAGE_KEYS.SALES, data.sales);
      if (data.purchases) setStorageItem(STORAGE_KEYS.PURCHASES, data.purchases);
      if (data.expenses) setStorageItem(STORAGE_KEYS.EXPENSES, data.expenses);
      if (data.cashSessions) setStorageItem(STORAGE_KEYS.CASH_SESSIONS, data.cashSessions);
      if (data.employees) setStorageItem(STORAGE_KEYS.EMPLOYEES, data.employees);
      this.addAuditLog('AUTH', 'সিস্টেম ডাটা ব্যাকআপ সফলভাবে রিস্টোর করা হয়েছে', 'Admin');
      return true;
    } catch (e) {
      console.error('Failed to parse and restore backup:', e);
      return false;
    }
  }

  // Financial Calculations & Formulas
  // As demanded by specification:
  // Gross Profit = Net Sales - COGS
  // Net Profit = Gross Profit - Operating Expenses
  // Inventory Value = Sum(Current Stock * Weighted Avg Cost)
  // Customer Due = Sum(remainingDue)
  // Supplier Payable = Sum(remainingPayable)
  static getFinancialOverview(startDate?: string, endDate?: string) {
    const sales = this.getSales().filter(s => {
      if (!startDate) return true;
      const sDate = s.createdAt.split('T')[0];
      return sDate >= startDate && (!endDate || sDate <= endDate);
    });

    const expenses = this.getExpenses().filter(e => {
      if (!startDate) return true;
      return e.date >= startDate && (!endDate || e.date <= endDate);
    });

    const products = this.getProducts();
    const customers = this.getCustomers();
    const suppliers = this.getSuppliers();

    const totalSales = sales.reduce((acc, s) => acc + s.finalAmount, 0);
    const totalCOGS = sales.reduce((acc, s) => acc + s.costOfGoodsSold, 0);
    const grossProfit = totalSales - totalCOGS;
    const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);
    const netProfit = grossProfit - totalExpenses;

    const totalCustomerDue = customers.reduce((acc, c) => acc + c.remainingDue, 0);
    const totalSupplierPayable = suppliers.reduce((acc, s) => acc + s.remainingPayable, 0);
    const totalInventoryValue = products.reduce((acc, p) => acc + Math.max(0, p.currentStock) * p.purchasePrice, 0);
    const lowStockCount = products.filter(p => p.currentStock <= p.minStockLevel).length;

    return {
      totalSales,
      totalCOGS,
      grossProfit,
      totalExpenses,
      netProfit,
      totalCustomerDue,
      totalSupplierPayable,
      totalInventoryValue,
      lowStockCount,
      totalProductsCount: products.length,
    };
  }
}
