/**
 * AF Market - Core Type Definitions
 * Smart Business Management System
 */

export type UserRole = 'ADMIN' | 'EMPLOYEE';

export interface Employee {
  id: string;
  name: string;
  phone: string;
  email: string;
  pin: string;
  role: UserRole;
  isActive: boolean;
  joiningDate: string;
}

export type UnitType = 'piece' | 'kg' | 'gram' | 'litre' | 'packet' | 'box' | 'dozen';

export interface ProductCategory {
  id: string;
  nameBn: string;
  nameEn: string;
  icon?: string;
}

export interface Product {
  id: string;
  name: string;
  nameBn: string;
  category: string;
  barcode?: string;
  image?: string;
  purchasePrice: number; // Weighted average unit cost
  sellingPrice: number;
  currentStock: number;
  minStockLevel: number;
  unit: UnitType;
  description?: string;
  isArchived?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address?: string;
  totalPurchases: number;
  totalPaid: number;
  remainingDue: number;
  createdAt: string;
}

export interface CustomerPayment {
  id: string;
  customerId: string;
  customerName: string;
  amount: number;
  paymentMethod: PaymentMethod;
  note?: string;
  collectedBy: string; // Employee ID or Admin
  date: string;
  syncStatus: SyncStatus;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  address?: string;
  companyName?: string;
  totalPurchases: number;
  totalPaid: number;
  remainingPayable: number;
  createdAt: string;
}

export interface SupplierPayment {
  id: string;
  supplierId: string;
  supplierName: string;
  amount: number;
  paymentMethod: PaymentMethod;
  note?: string;
  paidBy: string;
  date: string;
  syncStatus: SyncStatus;
}

export type PaymentMethod = 'CASH' | 'BKASH' | 'NAGAD' | 'ROCKET' | 'BANK' | 'CREDIT';

export interface SaleItem {
  productId: string;
  productName: string;
  productNameBn: string;
  unit: UnitType;
  quantity: number;
  unitPrice: number;
  purchaseUnitCost: number; // Used for COGS calculation
  subtotal: number;
}

export interface Sale {
  id: string; // UUID
  invoiceNumber: string;
  customerId?: string;
  customerName: string;
  customerPhone?: string;
  items: SaleItem[];
  subtotal: number;
  discount: number;
  finalAmount: number;
  amountPaid: number;
  dueAmount: number;
  paymentMethod: PaymentMethod;
  costOfGoodsSold: number; // Total purchase cost of sold items
  grossProfit: number; // finalAmount - costOfGoodsSold
  employeeId: string;
  employeeName: string;
  deviceId: string;
  createdAt: string;
  syncStatus: SyncStatus;
}

export interface PurchaseItem {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
}

export interface Purchase {
  id: string;
  purchaseNumber: string;
  supplierId: string;
  supplierName: string;
  supplierPhone?: string;
  items: PurchaseItem[];
  subtotal: number;
  discount: number;
  additionalCosts: number; // Transport/Labor
  totalAmount: number;
  amountPaid: number;
  remainingPayable: number;
  paymentMethod: PaymentMethod;
  date: string;
  recordedBy: string;
  syncStatus: SyncStatus;
}

export type ExpenseCategory =
  | 'RENT'
  | 'ELECTRICITY'
  | 'SALARY'
  | 'TRANSPORT'
  | 'FOOD'
  | 'MAINTENANCE'
  | 'PACKAGING'
  | 'OTHER';

export interface Expense {
  id: string;
  title: string;
  category: ExpenseCategory;
  amount: number;
  paymentMethod: PaymentMethod;
  description?: string;
  recordedBy: string;
  date: string;
  syncStatus: SyncStatus;
}

export interface DailyCashSession {
  id: string;
  date: string; // YYYY-MM-DD
  openingCash: number;
  cashSales: number;
  customerDueCollections: number;
  otherCashReceived: number;
  cashPurchases: number;
  cashExpenses: number;
  cashRefunds: number;
  otherCashPaid: number;
  expectedClosingCash: number;
  actualCountedCash: number | null;
  difference: number | null; // actual - expected
  status: 'OPEN' | 'CLOSED';
  notes?: string;
  closedBy?: string;
  closedAt?: string;
}

export type SyncStatus = 'SYNCED' | 'PENDING' | 'SYNCING' | 'FAILED';

export interface SyncMetadata {
  lastSyncTime: string | null;
  pendingCount: number;
  status: SyncStatus;
  lastErrorMessage?: string;
}

export interface BusinessProfile {
  name: string;
  taglineBn: string;
  taglineEn: string;
  phone: string;
  address: string;
  currency: string;
  currencySymbol: string;
  language: 'bn' | 'en';
}

export interface AuditLog {
  id: string;
  action: string;
  entityType: 'SALE' | 'PURCHASE' | 'PRODUCT' | 'CUSTOMER' | 'SUPPLIER' | 'EXPENSE' | 'CASH' | 'AUTH';
  details: string;
  performedBy: string;
  timestamp: string;
}
